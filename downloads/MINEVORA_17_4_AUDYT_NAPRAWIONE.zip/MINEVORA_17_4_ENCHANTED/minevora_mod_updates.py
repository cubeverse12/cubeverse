"""MINEVORA Mod Updates: safe Modrinth hash-based updates for local .jar mods.

No background daemon. User chooses Minecraft version + loader; updates only during
launcher operation, backups and verified SHA-512. No changes while game running.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import tempfile
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

API = 'https://api.modrinth.com/v2/version_files/update'
HEADERS = {'User-Agent': 'MINEVORA/10.5 (+https://discord.gg/8teEpYvzRd)',
           'Accept': 'application/json'}
MAX_MOD_BYTES = 100 * 1024 * 1024
MAX_MODS = 300


class ModUpdateError(Exception):
    pass


def jar_files(mc_dir):
    mods = Path(mc_dir) / 'mods'
    if not mods.is_dir():
        return []
    files = sorted(p for p in mods.iterdir() if p.is_file() and not p.is_symlink() and
                   p.suffix.lower() == '.jar' and p.stat().st_size <= MAX_MOD_BYTES)
    if len(files) > MAX_MODS:
        raise ModUpdateError(f'Za dużo modów w katalogu (maksymalnie {MAX_MODS}).')
    return files


def file_hash(path):
    digest = hashlib.sha512()
    with open(path, 'rb') as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def query_updates(hashes, game_version, loader, opener=None):
    if not re.fullmatch(r'\d+\.\d+(?:\.\d+)?', game_version):
        raise ModUpdateError('Nieprawidłowa wersja Minecraft.')
    if loader not in ('fabric', 'forge', 'neoforge', 'quilt'):
        raise ModUpdateError('Wybierz loader Fabric, Forge, NeoForge lub Quilt.')
    if not hashes:
        return {}
    result = {}
    for start in range(0, len(hashes), 50):
        batch = hashes[start:start + 50]
        payload = json.dumps({'hashes': batch, 'algorithm': 'sha512',
                              'loaders': [loader], 'game_versions': [game_version],
                              'version_types': ['release']}).encode('utf-8')
        req = urllib.request.Request(API, data=payload, method='POST',
                                     headers={**HEADERS, 'Content-Type': 'application/json'})
        with (opener or urllib.request.urlopen)(req, timeout=30) as response:
            data = json.load(response)
        if not isinstance(data, dict):
            raise ModUpdateError('Nieprawidłowa odpowiedź Modrinth.')
        result.update(data)
    return result


def is_safe_filename(name):
    return bool(isinstance(name, str) and re.fullmatch(r'[a-zA-Z0-9_.+()\[\] -]{1,180}\.jar', name, re.I)
                and name not in ('.', '..'))


def parse_candidates(local_paths, versions, hashes, version, loader):
    candidates = []
    for path in local_paths:
        old_hash = hashes[path]
        info = versions.get(old_hash)
        if not isinstance(info, dict):
            continue
        if version not in info.get('game_versions', []) or loader not in info.get('loaders', []):
            continue
        files = info.get('files') or []
        chosen = next((f for f in files if f.get('primary') and is_safe_filename(f.get('filename'))), None)
        if chosen is None:
            chosen = next((f for f in files if is_safe_filename(f.get('filename')) and
                           f.get('file_type') not in ('sources-jar', 'dev-jar', 'javadoc-jar')), None)
        if not chosen:
            continue
        new_hash = (chosen.get('hashes') or {}).get('sha512', '').lower()
        url = chosen.get('url', '')
        parsed = urllib.parse.urlparse(url)
        if not re.fullmatch(r'[0-9a-f]{128}', new_hash) or parsed.scheme != 'https' or \
                parsed.hostname != 'cdn.modrinth.com' or parsed.username or parsed.password:
            continue
        if old_hash.lower() == new_hash:
            continue
        if not isinstance(chosen.get('size'), int) or not 1 <= chosen['size'] <= MAX_MOD_BYTES:
            continue
        candidates.append({'path': str(path), 'old_sha512': old_hash,
                           'filename': chosen['filename'], 'url': url,
                           'sha512': new_hash, 'size': chosen['size'],
                           'name': info.get('name', chosen['filename']),
                           'version': info.get('version_number', '?'),
                           'project_id': info.get('project_id', ''),
                           'dependencies': [d for d in info.get('dependencies', []) if d.get('dependency_type') == 'required']})
    return candidates


def scan_updates(mc_dir, version, loader, opener=None):
    paths = jar_files(mc_dir)
    hashes = {path: file_hash(path) for path in paths}
    versions = query_updates(list(hashes.values()), version, loader, opener=opener)
    return parse_candidates(paths, versions, hashes, version, loader), len(paths)


def download_verified(candidate, target_dir, opener=None):
    url = candidate['url']
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != 'https' or parsed.hostname != 'cdn.modrinth.com' or \
            parsed.username or parsed.password:
        raise ModUpdateError('Źródło pobierania nie jest oficjalnym CDN Modrinth.')
    name = candidate['filename']
    if not is_safe_filename(name):
        raise ModUpdateError('Nieprawidłowa nazwa pliku moda.')
    with tempfile.NamedTemporaryFile(dir=target_dir, suffix='.download', delete=False) as out:
        temp = Path(out.name)
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            digest = hashlib.sha512()
            total = 0
            with (opener or urllib.request.urlopen)(req, timeout=60) as response:
                # Reject redirect to a different origin.
                final = urllib.parse.urlparse(response.geturl())
                if final.scheme != 'https' or final.hostname != 'cdn.modrinth.com':
                    raise ModUpdateError('Nieprawidłowe przekierowanie pobierania.')
                while chunk := response.read(1024 * 1024):
                    total += len(chunk)
                    if total > MAX_MOD_BYTES:
                        raise ModUpdateError('Mod przekroczył limit 100 MB.')
                    digest.update(chunk)
                    out.write(chunk)
            if total != candidate['size'] or digest.hexdigest() != candidate['sha512']:
                raise ModUpdateError('Rozmiar lub suma SHA-512 nie zgadza się — aktualizacja przerwana.')
            return temp
        except Exception:
            temp.unlink(missing_ok=True)
            raise


def install_update(candidate, mc_dir, backup_root=None, opener=None):
    """Download, verify, backup original, then replace; rollback on any error."""
    folder = Path(mc_dir) / 'mods'
    path = Path(candidate['path'])
    if path.parent.resolve() != folder.resolve() or not path.is_file() or path.is_symlink():
        raise ModUpdateError('Mod nie znajduje się już w prawidłowym folderze.')
    if file_hash(path) != candidate['old_sha512']:
        raise ModUpdateError('Plik moda zmienił się od sprawdzenia aktualizacji.')
    dest = folder / candidate['filename']
    if dest != path and dest.exists():
        raise ModUpdateError('Nowa nazwa moda koliduje z istniejącym plikiem: ' + dest.name)
    backup_dir = Path(backup_root) if backup_root else Path.home() / '.minevora' / 'mod_backups'
    backup_dir = backup_dir / datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    temp = download_verified(candidate, folder, opener=opener)
    original_moved = False
    backup = backup_dir / path.name
    try:
        backup_dir.mkdir(parents=True, exist_ok=False)
        # copy2 preserves original on disk until ready; original must remain recoverable
        shutil.copy2(path, backup)
        if file_hash(backup) != candidate['old_sha512']:
            raise ModUpdateError('Kopia zapasowa moda nie przeszła weryfikacji.')
        path.unlink()
        original_moved = True
        try:
            temp.replace(dest)
        except Exception:
            shutil.copy2(backup, path)
            raise
        return str(backup)
    finally:
        temp.unlink(missing_ok=True)


def run_updates(candidates, mc_dir, backup_root=None, opener=None, progress=None):
    completed, errors = [], []
    for index, candidate in enumerate(candidates, 1):
        if progress:
            progress(f'{index}/{len(candidates)}: {candidate["name"]}')
        try:
            backup = install_update(candidate, mc_dir, backup_root, opener=opener)
            completed.append((candidate['filename'], backup))
        except Exception as exc:
            errors.append((candidate['filename'], str(exc)))
    return completed, errors
