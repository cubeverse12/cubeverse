MINEVORA 9.3 — PVP ARENA
=========================

NOWOŚCI
- Nowa zakładka "⚔ PvP Arena" w przewijanym menu po lewej stronie.
- 6 trybów: Sword PvP, Crystal PvP, Axe PvP, UHC, BedWars, SkyWars.
- Własna lista serwerów Minecraft Java: dodaj, edytuj, usuń.
- Status serwerów Java: pomiar czasu odpowiedzi (ping), liczby graczy i wersji.
- Kopiowanie adresu i uruchomienie zwykłej instancji Minecraft.
- Lokalny dziennik treningu: licznik czasu, wygrane, przegrane, eliminacje, zgony, K/D, skuteczność.
- Cofanie ostatniego ręcznego wpisu.
- 5 lokalnych rang treningowych za zapisane wygrane (bez MVC / nagród pieniężnych).
- Wszystkie statystyki i serwery zapisywane w %USERPROFILE%\.minevora\pvp_training.json.
- Poprawiona widoczność menu w mniejszym oknie; korekta referencji do animowanego tła.

INSTALACJA WINDOWS 11
1. Rozpakuj paczkę do NOWEGO folderu, nie uruchamiaj skryptów z ZIP.
2. W folderze uruchom INSTALUJ_ZALEZNOSCI.bat (jeśli nie instalowałeś wymaganych bibliotek).
3. Następnie uruchom URUCHOM_MINEVORA.bat.
4. W MINEVORA otwórz "⚔ PvP Arena" (może być konieczne przewinięcie menu).

OBSŁUGA PVP
- Wybierz tryb walki.
- Kliknij "+ Dodaj" i podaj adres własnego serwera Minecraft Java, np. play.example.net:25565.
  (To tylko przykład formatu, nie lista polecanych serwerów.)
- Kliknij "Sprawdź ping", by pobrać informacje o serwerze.
- Kliknij "Kopiuj adres i uruchom Minecraft": adres zostanie skopiowany do schowka.
- W Minecraft: Multiplayer -> Połącz bezpośrednio -> wklej adres (Ctrl+V).
- "Rozpocznij trening" / "Zakończ trening" mierzy łączny czas.
- Zapisuj wyniki przyciskami +1 — gra NIE przesyła danych meczowych do launchera.

WAŻNE
- Do połączenia z serwerem nadal potrzebujesz uruchomionego Minecraft i konta Microsoft z odpowiednią licencją.
- Nie ma automatycznego dołączania do serwera, auto-zliczania zabójstw ani modyfikacji gry.
- Lokalna ranga PvP to wyłącznie demonstracyjny system osobistych postępów.
- Ten system nie przyznaje MVC; poziomy i nagrody twórcy z wersji 9.2 pozostają niezależne.
- Przechowywanie danych: lokalnie na Twoim komputerze. Ping wysyła standardowe zapytanie do dodanego serwera.
- Zmiana ZIP nie modyfikuje starej instalacji; ustawienia i statystyki z folderu .minevora są współdzielone.
- Kod sprawdzony statycznie i testami logiki backendu, ale GUI wymaga testu Windows (PySide6 niedostępne w środowisku testowym).
