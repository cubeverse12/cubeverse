@echo off
cd /d "%~dp0"
python TESTUJ_MINEVORA_14.py
pause
