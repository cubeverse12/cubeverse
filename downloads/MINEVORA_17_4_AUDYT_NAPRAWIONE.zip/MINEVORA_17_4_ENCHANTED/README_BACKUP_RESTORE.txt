MINEVORA 10.1 - BACKUP & RESTORE
================================

WAZNE: PRZED KOPIA ZAMKNIJ MINEVORA I MINECRAFT.

STARY KOMPUTER
1. Otworz folder programu MINEVORA 10.1.
2. Kliknij URUCHOM_BACKUP_RESTORE.bat.
3. W zakladce "Utworz kopie" zaznacz co przeniesc.
4. Opcjonalnie: dodaj foldery Blender / Blockbench / HTML / serwery.
5. Kliknij "UTWORZ KOPIE ZIP" i zapisz na pendrivie lub dysku zewnetrznym.
6. Sprawdz, ze ZIP jest na dysku zewnetrznym. Zrob druga kopie, jesli mozesz.

NOWY KOMPUTER
1. Zainstaluj Python 3 (z tkinter). Skopiuj ten folder programu na nowy komputer.
2. Kliknij URUCHOM_BACKUP_RESTORE.bat.
3. W zakladce "Przywroc kopie" wybierz archiwum ZIP z pendrive'a.
4. Kliknij "Sprawdz zawartosc kopii".
5. Zalecamy przywracac do czystej instalacji; domyslnie istniejace pliki sa pomijane.
6. Kliknij "PRZYWROC PLIKI".
7. Launcher pojawi sie w Pobrane/MINEVORA_ODZYSKANA.
8. Wejdz do tego folderu, uruchom INSTALUJ_ZALEZNOSCI.bat i URUCHOM_MINEVORA.bat.
9. Zaloguj sie ponownie do Microsoft/Discord; sprawdz profile i sciezki Minecraft.

CO JEST PRZENOSZONE
- Pliki launchera z folderu tego programu.
- %USERPROFILE%\.minevora (projekty, profile, rangi, MVC, statystyki, reklamy).
- %APPDATA%\.minecraft (saves, mods, config, resourcepacks, shaderpacks i inne).
- Opcjonalnie caly folder .minecraft.
- Opcjonalne wskazane foldery projektow.
- Z konfiguracji logowania: tylko publiczny Client ID.

BEZPIECZENSTWO
- Kopia nie zawiera tokenow, haseł, poufnych plikow sesji ani danych logowania.
- ZIP NIE JEST SZYFROWANY. Nie udostepniaj publicznie: zawiera swiaty, projekty,
  ustawienia, liste serwerow i dane prywatne. Przechowuj w bezpiecznym miejscu.
- Nie usuwaj starego komputera/danych zanim nie sprawdzisz przywracania.
- Przy trybie nadpisywania stare pliki sa zapisywane w Dokumenty/MINEVORA_OCHRONA...
- Narzedzie dziala lokalnie i nie wysyla danych do internetu.
- Dla danych Windows poza standardowymi lokalizacjami uzyj opcji "Dodaj folder".
- Ponowna instalacja Python/PySide6 i bibliotek moze byc konieczna.
- Przywracanie plikow serwera Minecraft nalezy wykonywac tylko po zatrzymaniu serwera.
- W pelnej kopii .minecraft moga znajdowac sie ogromne pliki — sprawdz miejsce.
- Publiczny kod launchera nie powinien przechowywac sekretow.

Najnowszy pakiet zawiera MINEVORA 10.0 Ads Manager plus Backup & Restore 10.1.
