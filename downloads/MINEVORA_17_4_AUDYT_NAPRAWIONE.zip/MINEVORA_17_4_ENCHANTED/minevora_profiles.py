"""Separate game folders for Minecraft profiles; base assets and versions remain shared."""
import json, re
from pathlib import Path
from minevora_engine import MC_DIR
STORE=Path.home()/'.minevora'/'profiles.json'
ROOT=Path.home()/'.minevora'/'instances'
def load():
    try:
        data=json.loads(STORE.read_text(encoding='utf-8'))
        if not isinstance(data,list):return []
        # Ignore malformed entries without modifying the user's original file.
        return [item for item in data if isinstance(item,dict)
                and all(isinstance(item.get(k),str) and item[k].strip()
                        for k in ('id','name','version','game_dir'))]
    except (OSError,ValueError):return []
def save(profiles):
    STORE.parent.mkdir(parents=True,exist_ok=True)
    staging=STORE.with_suffix('.tmp')
    staging.write_text(json.dumps(profiles,ensure_ascii=False,indent=2),encoding='utf-8')
    staging.replace(STORE)
def create(name,version):
    name=name.strip()
    if not name or len(name)>40:raise ValueError('Nazwa profilu musi mieć 1–40 znaków.')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+',version):raise ValueError('Nieprawidłowa wersja Minecraft.')
    profiles=load()
    if any(p['name'].casefold()==name.casefold() for p in profiles):raise ValueError('Profil o tej nazwie już istnieje.')
    import uuid
    key=uuid.uuid4().hex[:12]
    folder=ROOT/key;folder.mkdir(parents=True,exist_ok=False)
    profile={'id':key,'name':name,'version':version,'game_dir':str(folder)}
    profiles.append(profile);save(profiles)
    return profile


def register_from_staging(name,version,staging):
    """Atomically publish a finished modpack folder and matching profile."""
    import uuid
    name=str(name).strip()
    if not name or len(name)>40:raise ValueError('Nieprawidłowa nazwa profilu.')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+',version):raise ValueError('Nieprawidłowa wersja Minecraft.')
    profiles=load()
    if any(p['name'].casefold()==name.casefold() for p in profiles):
        raise ValueError('Profil o tej nazwie już istnieje.')
    stage=Path(staging).resolve()
    ROOT.mkdir(parents=True,exist_ok=True)
    if stage.parent!=ROOT.resolve() or not stage.name.startswith('.inprogress-'):
        raise ValueError('Nieprawidłowy folder tymczasowy profilu.')
    key=uuid.uuid4().hex[:12]
    folder=ROOT/key
    stage.rename(folder)
    profile={'id':key,'name':name,'version':version,'game_dir':str(folder)}
    try:
        profiles.append(profile)
        save(profiles)
    except Exception:
        folder.rename(stage)
        raise
    return profile
