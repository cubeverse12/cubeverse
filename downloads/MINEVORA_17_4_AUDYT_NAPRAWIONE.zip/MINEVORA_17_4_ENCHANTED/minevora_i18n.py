"""Polish / English language pack for MINEVORA 10.5.

Translated main navigation, landing view, settings and Modrinth catalog. Other
advanced modules may retain Polish labels until translated in future releases.
"""
PL_EN = {
 # Simplified MINEVORA 10.7 interface
 '⌂  Start':'⌂  Home',
 '▶  Graj / Wersje':'▶  Play / Versions',
 '◈  Mody i dodatki':'◈  Mods and add-ons',
 '▣  Marketplace':'▣  Marketplace',
 '⚔  PvP':'⚔  PvP',
 '◉  Discord':'◉  Discord',
 '💬  DOŁĄCZ NA DISCORD':'💬  JOIN OUR DISCORD',
 '✦  Wszystkie funkcje':'✦  All features',
 '⚙  Ustawienia':'⚙  Settings',
 '◉  Zaloguj Microsoft':'◉  Microsoft sign in',
 '☏ Pokaż czat':'☏ Show chat',
 '☏ Ukryj czat':'☏ Hide chat',
 '⌕ Znajdź funkcję… (Ctrl+K)':'⌕ Find a feature… (Ctrl+K)',
 'MINECRAFT JEDNYM KLIKNIĘCIEM':'MINECRAFT MADE EASY',
 'Wybierz wersję, zaloguj konto Microsoft i graj.':'Choose a version, sign in and play.',
 '3 KROKI DO GRY':'3 STEPS TO PLAY',
 '1  Zaloguj':'1  Sign in',
 '2  Instaluj Minecraft':'2  Install Minecraft',
 '3  Graj':'3  Play',
 'NAJCZĘŚCIEJ UŻYWANE':'POPULAR ACTIONS',
 '◈ Mody':'◈ Mods',
 'Modrinth i aktualizacje':'Modrinth and updates',
 'Mapy, rigi i modele':'Maps, rigs and models',
 '🏆 Moje rangi':'🏆 Creator ranks',
 'Poziomy i bonusy XP':'Levels and XP boosts',
 '⚔ PvP Arena':'⚔ PvP Arena',
 'Serwery i trening':'Servers and training',
 '✧ Pomoc AI':'✧ AI assistant',
 'Porady i rozwiązywanie błędów':'Help and troubleshooting',
 '✦ Pozostałe':'✦ More',
 'Znajdź dowolną funkcję':'Find any feature',
 'Wszystkie funkcje MINEVORA →':'All MINEVORA features →',
 'WSZYSTKIE FUNKCJE':'ALL FEATURES',
 'Zamiast szukać w długim menu: wpisz nazwę funkcji lub wybierz kategorię.':
  'Instead of searching through a long menu, type a feature name or choose a category.',
 'Szukaj: skiny, rangi, konto, tickety…':'Search: skins, ranks, account, tickets…',
 'Otwórz  →':'Open  →',
 'Nie znaleziono funkcji. Wpisz inną nazwę.':'No matches. Try a different search.',
 'Moja biblioteka':'My library',
 '＋ Dodaj projekt':'＋ Add project',
 '⚙ Więcej opcji Marketplace  ▾':'⚙ More Marketplace tools  ▾',
 '⌕ Zaawansowane filtry  ▾':'⌕ Advanced filters  ▾',
 '⚙ Dodatkowe informacje (opcjonalne) ▾':'⚙ More details (optional) ▾',
 '✧  MINEVORA AI':'✧  MINEVORA AI',
 '✧  MINEVORA AI  ·  Pomoc z modami i Minecraft':'✧  MINEVORA AI  ·  Minecraft and mod help',
 '🏠  Strona główna':'🏠  Home',
 '🧱  Instancje':'🧱  Instances',
 '🧩  Mody':'🧩  Mods',
 '📦  Modpacki':'📦  Modpacks',
 '👤  Skiny 3D':'👤  3D Skins',
 '🌐  Serwery':'🌐  Servers',
 '🛒  Marketplace':'🛒  Marketplace',
 '💬  Globalny czat':'💬  Global Chat',
 '📊  Statystyki':'📊  Statistics',
 '⚙️  Ustawienia':'⚙️  Settings',
 '🎮  Nakładka':'🎮  Overlay',
 '🔗  Discord':'🔗  Discord',
 '🛠  Diagnostyka':'🛠  Diagnostics',
 '🏆  Rangi twórcy':'🏆  Creator Ranks',
 '⚔  PvP Arena':'⚔  PvP Arena',
 '🛡  Fair Play':'🛡  Fair Play',
 '📢  Reklamy / Ads':'📢  Ads',
 '💾  Kopia danych':'💾  Backup',
 '◉  Microsoft / Zaloguj':'◉  Microsoft / Sign in',
 '✦  KONTO GRACZA':'✦  PLAYER ACCOUNT',
 'Otwórz portal do swojej przygody.':'Open the portal to your next adventure.',
 'Witaj w MINEVORA':'Welcome to MINEVORA',
 '↻ Odśwież':'↻ Refresh',
 'Dziennik / narzędzia':'Logs / tools',
 '✧  TWOJA PRZYGODA ZACZYNA SIĘ TUTAJ':'✧  YOUR ADVENTURE BEGINS HERE',
 'ODKRYJ\nMAGICZNY ŚWIAT':'DISCOVER THE\nMAGICAL WORLD',
 'Przejdź przez portal i rozpocznij nową przygodę w Minecraft Java.':'Step through the portal and begin a new Minecraft Java adventure.',
 '▶  GRAJ W MINECRAFT':'▶  PLAY MINECRAFT',
 '＋  Instaluj wersję':'＋  Install version',
 '🏆  TWÓJ PROFIL TWÓRCY  ·  Poziomy, rangi i odbiór MVC':'🏆  CREATOR PROFILE  ·  Levels, ranks and MVC rewards',
 '⚔  PVP ARENA  ·  Tryby walki, serwery i statystyki treningowe':'⚔  PVP ARENA  ·  Game modes, servers and training stats',
 '🛡  FAIR PLAY  ·  Import antycheat, raporty i bany':'🛡  FAIR PLAY  ·  Anticheat import, reports and bans',
 '◈  DISCORD HUB  ·  Aktywność, status i społeczność':'◈  DISCORD HUB  ·  Activity, status and community',
 '📢  MINEVORA ADS  ·  Banery, kampanie, moderacja':'📢  MINEVORA ADS  ·  Banners, campaigns, moderation',
 '💾  KOPIA DANYCH  ·  Przeniesienie na nowy komputer':'💾  BACKUP  ·  Move to a new computer',
 '✦  WYBIERZ SWOJĄ ŚCIEŻKĘ':'✦  CHOOSE YOUR PATH',
 'Wszystkie narzędzia Minecraft w jednym magicznym miejscu.':'All your Minecraft tools in one magical place.',
 '▣  BIBLIOTEKA ŚWIATÓW':'▣  GAME LIBRARY',
 'Wybierz zainstalowaną wersję. Uruchomisz ją przyciskiem GRAJ.':'Choose an installed version and launch it with PLAY.',
 '＋ Instaluj wersję Minecraft':'＋ Install Minecraft version',
 '＋ Utwórz profil':'＋ Create profile',
 '✧  TWOJE WERSJE I PROFILE':'✧  YOUR VERSIONS AND PROFILES',
 '✦  AKTYWNA INSTANCJA':'✦  ACTIVE INSTANCE',
 '▶  WEJDŹ DO GRY':'▶  PLAY',
 '⚔  Otwórz listę serwerów PvP':'⚔  Open PvP server list',
 '🌐  SERWERY MINECRAFT':'🌐  MINECRAFT SERVERS',
 'Wybierz tryb i przeglądaj zapisane serwery w PvP Arena. Ogólnodostępny katalog MINEVORA Network jest planowany.':
    'Browse saved servers in PvP Arena. A public MINEVORA Network directory is planned.',
 'Instancje':'Instances',
 'Wybieraj zainstalowane wersje Minecraft.':'Choose installed Minecraft versions.',
 'Modrinth':'Modrinth',
 'Przeglądaj mody i modpacki.':'Browse mods and modpacks.',
 'Edytor skinów 3D':'3D Skin Editor',
 'Edytuj skiny i przeglądaj pelerynki.':'Edit skins and view capes.',
 'Serwery':'Servers',
 'Zarządzaj ulubionymi serwerami.':'Manage favorite servers.',
 'Sklep MineCoins':'MineCoins Shop',
 'Mapy, budowle, rigi Minecraft i modele 3D.':'Maps, builds, Minecraft rigs and 3D models.',
 'Globalny czat':'Global Chat',
 'Rozmawiaj z użytkownikami MINEVORA.':'Chat with MINEVORA users.',
 'OTWÓRZ   ↗':'OPEN   ↗',
 # Modrinth discovery dialog
 '✦  MINEVORA  /  ODKRYWAJ':'✦  MINEVORA  /  DISCOVER',
 '⌕  Szukaj':'⌕  Search',
 'Mody':'Mods', 'Modpacki':'Modpacks', 'Tekstury':'Resource packs',
 'Shadery':'Shaders', 'Datapacki':'Datapacks', 'Pluginy':'Plugins',
 'Sortowanie:':'Sort by:', 'Popularne':'Popular', 'Trafność':'Relevance',
 'Najnowsze':'Newest', 'Ostatnio aktualizowane':'Recently updated',
 'Wybierz kategorię i wyszukaj projekty':'Choose a category and search projects',
 'Źródło: Modrinth API • Instalowanie plików obsługiwane dla modów • Pozostałe kategorie: przeglądanie':
    'Source: Modrinth API • Direct installation for mods • Other categories: browsing',
 '⬇  Instaluj':'⬇  Install', '↗  Otwórz':'↗  Open',
 'Szukaj modów, modpacków, shaderów i dodatków…':'Search mods, modpacks, shaders and add-ons…',
 'Wersja MC':'MC version', 'dowolny':'any',
 # Settings dialog
 '⚙  PERSONALIZACJA MINEVORA':'⚙  MINEVORA PERSONALIZATION',
 'Dostosuj wygląd, animacje i sklep. Ustawienia zapisują się na tym komputerze.':
    'Customize appearance, animations and the shop. Settings are saved on this computer.',
 'Kolor motywu:':'Theme color:', 'Wielkość tekstu:':'Text size:',
 'Włącz animowane tło':'Enable animated background', 'Animacje:':'Animations:',
 'Odświeżanie czatu:':'Chat refresh:', 'Styl ikon sklepu:':'Shop icon style:',
 'Ikonę każdej oferty można też wybrać przy jej dodawaniu.':'You can also choose a custom icon for each listing.',
 '▤ Ustawienia nakładki Minecraft':'▤ Minecraft overlay settings',
 '◈ Połącz z Discordem':'◈ Connect to Discord',
 'Zapisz ustawienia':'Save settings',
 'MINEVORA • Ustawienia':'MINEVORA • Settings',
 'Ustawienia zostały zapisane.':'Settings saved.',
 'Język interfejsu:':'Interface language:',
 'Aktualizacje modów:':'Mod updates:',
 'Automatycznie sprawdzaj i aktualizuj mody po otwarciu katalogu Modrinth':
   'Automatically check and update mods when opening Modrinth',
 '🔄  Aktualizacje modów':'🔄  Mod updates',
 '🔄  Sprawdź aktualizacje modów':'🔄  Check mod updates',
}


def translate(text, language='pl'):
    return PL_EN.get(text, text) if language == 'en' else text


def translate_widget_tree(root, language):
    """Use remembered source text to allow switching both directions without restart."""
    from PySide6.QtWidgets import QLabel, QAbstractButton, QLineEdit
    from PySide6.QtCore import QObject
    for obj in [root, *root.findChildren(QObject)]:
        if isinstance(obj, (QLabel, QAbstractButton)):
            original = obj.property('_minevora_pl_text')
            if original is None:
                original = obj.text()
                obj.setProperty('_minevora_pl_text', original)
            new_value = translate(original, language)
            if obj.text() != new_value:
                obj.setText(new_value)
        if isinstance(obj, QLineEdit):
            original = obj.property('_minevora_pl_placeholder')
            if original is None:
                original = obj.placeholderText()
                obj.setProperty('_minevora_pl_placeholder', original)
            translated = translate(original, language)
            if obj.placeholderText() != translated:
                obj.setPlaceholderText(translated)

