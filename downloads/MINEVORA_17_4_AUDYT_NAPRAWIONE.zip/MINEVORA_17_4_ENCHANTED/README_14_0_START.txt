MINEVORA 14.0 • JEDEN STYL WE WSZYSTKICH FUNKCJACH
================================================

Ta paczka to prawdziwy projekt Python/PySide6 do Windows, NIE tylko obraz.
Bazą jest przesłany minevora_qt(10).py z MINEVORA 13.0.

ZMIANY:
• Ekran Start został zbudowany jako prawdziwy interfejs Qt (nie bitmapa z niewidzialnymi przyciskami).
• 9 kart z działającymi przejściami: Graj/Wersje, Mody, Minigry, Marketplace,
  Ranking, Discord, Ustawienia, Together, PvP.
• Wspólny granatowo-fioletowy styl: przyciski, formularze, tabele, nawigacja,
  dialogi, okna pobierania, podstrony, banner i boczny czat.
• Minigry mają osobne ilustracje i nadal wybierają odpowiednie komendy.
• Zachowano moduły starszej wersji, integrację Microsoft, uruchamianie Minecraft,
  edytor skinów, Modrinth, Marketplace, PvP, Ranking, Discord oraz Together.

JAK URUCHOMIĆ:
1. Wypakuj cały ZIP na Windows 11. Nie wyjmuj samego minevora_qt.py.
2. Otwórz INSTALUJ_ZALEZNOSCI.bat (wymagany Python 3.11+ i internet podczas instalacji).
3. Uruchom URUCHOM_MINEVORA.bat.
4. Jeśli jest błąd, uruchom SPRAWDZ_LAUNCHER.bat i przeczytaj raport.

WAŻNE:
• Główne funkcje sieciowe wymagają zewnętrznych kont, API lub hostingu.
• Sama zmiana wyglądu nie dodaje hostingu minigier ani nie naprawia błędów usług zewnętrznych.
• Nie wpisuj loginów, haseł ani kluczy API do czatu.
• Pliki graficzne pokazują styl Enchanted i są używane jako tła, nie jako atrapowe przyciski.
• Pełen test interfejsu w środowisku Windows jest nadal zalecany.

TESTOWANIE:
Uruchom TESTUJ_MINEVORA_14.bat. Test sprawdza kod i komplet plików.
Jeśli aplikacja podczas startu wyświetli błąd, sprawdź %USERPROFILE%\.minevora\ostatni_blad.txt.
Status: kod nie był uruchamiany na Windows w tym środowisku — to wydanie do przetestowania.
