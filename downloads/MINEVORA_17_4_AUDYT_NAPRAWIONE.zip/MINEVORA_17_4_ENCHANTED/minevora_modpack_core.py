"""Explicit modpack-only update policy; never touch global .minecraft/mods."""
import json, re
from pathlib import Path
ROOT = Path.home() / '.minevora' / 'modpacks'
MANIFEST = 'minevora_modpack.json'

class PackError(ValueError):pass

def create_pack(name, version, loader, root=ROOT):
    name=name.strip()
    if not re.fullmatch(r'[A-Za-z0-9 _-]{1,36}',name):
        raise PackError('Nazwa paczki: 1–36 znaków, litery, cyfry, spacje, _ lub -.')
    if not re.fullmatch(r'\d+\.\d+(?:\.\d+)?',version):
        raise PackError('Podaj wersję Minecraft, np. 1.21.1.')
    if loader not in ('fabric','forge','neoforge','quilt'):
        raise PackError('Wybierz loader Fabric, Forge, NeoForge lub Quilt.')
    slug=re.sub(r'[^a-z0-9_-]+','-',name.lower()).strip('-')
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    folder=root/slug
    if folder.exists():raise PackError('Paczka o tej nazwie już istnieje.')
    folder.mkdir();(folder/'mods').mkdir()
    info={'name':name,'minecraft_version':version,'loader':loader,'version':1}
    (folder/MANIFEST).write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf8')
    return folder

def list_packs(root=ROOT):
    root=Path(root)
    if not root.exists():return []
    found=[]
    for folder in root.iterdir():
        try:
            if not folder.is_dir() or folder.is_symlink():continue
            info=check_pack(folder,root)
            found.append((folder,info))
        except (OSError,ValueError,TypeError,KeyError):continue
    return sorted(found,key=lambda pair:pair[1]['name'].casefold())

def check_pack(folder, root=ROOT):
    root=Path(root).resolve(); folder=Path(folder).resolve()
    if folder.parent!=root or not (folder/'mods').is_dir() or (folder/'mods').is_symlink():
        raise PackError('Aktualizacje są możliwe wyłącznie wewnątrz zarejestrowanej paczki MINEVORA.')
    info=json.loads((folder/MANIFEST).read_text(encoding='utf8'))
    if not isinstance(info,dict) or not isinstance(info.get('name'),str):raise PackError('Błędny manifest paczki.')
    if not re.fullmatch(r'\d+\.\d+(?:\.\d+)?',str(info.get('minecraft_version',''))):raise PackError('Błędna wersja paczki.')
    if info.get('loader') not in ('fabric','forge','neoforge','quilt'):raise PackError('Błędny loader paczki.')
    return info
