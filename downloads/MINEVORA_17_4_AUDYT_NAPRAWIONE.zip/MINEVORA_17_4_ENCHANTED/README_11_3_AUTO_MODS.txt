MINEVORA 11.3 — AUTOMATYCZNE WYMAGANE MODY
==========================================

INSTALACJA (Windows 11)
1. Rozpakuj caly ZIP do nowego folderu (nie mieszaj wersji launchera).
2. Zamknij Minecraft. Zrob kopie swoich swiatow i folderow mods.
3. Uruchom INSTALUJ_ZALEZNOSCI.bat, jesli trzeba doinstalowac PySide6.
4. Uruchom URUCHOM_MINEVORA.bat.

JAK DZIALA
- W Ustawienia -> Zaawansowane -> Mody zaznaczona jest opcja automatycznego
  instalowania brakujacych zaleznosci modow (Modrinth). Mozesz ja wylaczyc.
- Zainstaluj mod w Mody i dodatki (Modrinth). MINEVORA sprawdzi, jakie biblioteki
  ten mod wymaga i pobierze je sama, a takze kolejne wymagane biblioteki.
- Po nacisnieciu GRAJ z uruchomiona wersja loadera Fabric/Forge/NeoForge/Quilt
  MINEVORA sprawdzi folder mods wybranej instancji przed uruchomieniem gry.
- Pobiera tylko wymagane zaleznosci o zgodnej wersji Minecraft i loaderze.
- Automatycznie pomija opcjonalne dodatki. Nie aktualizuje samodzielnie starych modow.
- Nie usuwa i nie nadpisuje lokalnych .jar. Jesli wystapi konflikt, wyswietli blad.
- Pliki sa pobierane wyłącznie z oficjalnego CDN Modrinth i weryfikowane przez SHA-512.
- Po bledzie przed uruchomieniem gry uzytkownik decyduje, czy grac bez zaleznosci.
- Instalacja zaleznosci dziala TYLKO wtedy, gdy wersja Minecraft zawiera loader
  oraz prawidlowa wersje gry. Np. "fabric-loader-0.16.4-1.21.1".
- Nieznane mody spoza Modrinth (lub nieindeksowane przez API) sa pomijane.
- Gdy brak internetu lub autor nie podal zaleznosci w metadanych, automatyczna
  instalacja moze nie zadzialac. Nie jest to narzedzie naprawiajace kazdy mod.
- Obowiazujaca starsza zasada jest zachowana: automatyczne AKTUALIZACJE modow
  nie dzialaja w zwyklym globalnym .minecraft/mods i sa sterowane osobno.

TESTY
- python -m unittest discover -s tests -v
- python -m compileall -q .
- Automatyczne testy zaleznosci nie potrzebuja polaczenia internetowego.
- Na komputerze Windows sprawdz GUI, instalacje rzeczywistego moda i start gry.

BEZPIECZENSTWO
Mod .jar jest wykonywalnym kodem. Instaluj tylko dodatki od autorow, ktorym ufasz.
Przed wieksza instalacja stworz kopie profilu gry.
