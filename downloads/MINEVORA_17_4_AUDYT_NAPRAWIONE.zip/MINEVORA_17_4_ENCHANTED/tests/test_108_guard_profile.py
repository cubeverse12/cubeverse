import tempfile
import unittest
from pathlib import Path

from minevora_fairplay_core import (empty_data, new_player, add_record,
    update_record_status, review_queue, save_data, load_data, summary)
from minevora_guard_presets import PRESETS, render_preset
from minevora_player_profile_core import profile_snapshot


class TestReviewedReports(unittest.TestCase):
    def setUp(self):
        self.data = empty_data()
        self.player = new_player(self.data, 'SamplePlayer', 'b'*32)

    def test_close_alert_changes_queue_but_not_bans(self):
        alert = add_record(self.player, 'alert', 'MyServer', detail='speed spike')
        self.assertEqual(len(review_queue(self.data)), 1)
        self.assertTrue(update_record_status(self.player, alert['id'], 'wyjaśniony', 'Lag during teleport'))
        self.assertEqual(review_queue(self.data), [])
        self.assertEqual(summary(self.player)['bans_total'], 0)
        self.assertEqual(len(alert['review_history']), 1)
        self.assertEqual(alert['review_history'][0]['note'], 'Lag during teleport')
        self.assertEqual(profile_snapshot(self.player)['stats']['alerts_open'], 0)

    def test_pending_link_never_becomes_verified_without_review(self):
        linked = add_record(self.player, 'linked', 'OurServer', account='AnotherUser')
        self.assertEqual(len(review_queue(self.data)), 1)
        self.assertEqual(linked['status'], 'zgłoszone')
        update_record_status(self.player, linked['id'], 'odrzucone')
        self.assertEqual(review_queue(self.data), [])
        self.assertEqual(summary(self.player)['linked_reports'], 0)

    def test_invalid_status_and_missing_record_does_not_modify(self):
        report = add_record(self.player, 'ban', 'MyServer')
        with self.assertRaises(ValueError):update_record_status(self.player, report['id'], 'confirmed cheat')
        with self.assertRaises(ValueError):update_record_status(self.player, 'missing', 'wygasły')
        self.assertEqual(report['status'], 'aktywny')
        self.assertEqual(report['review_history'], [])

    def test_invalid_note_rejected(self):
        report = add_record(self.player, 'alert', 'MyServer')
        with self.assertRaises(ValueError):update_record_status(self.player, report['id'], 'zamknięty', 'x'*181)
        self.assertEqual(report['status'], 'do sprawdzenia')

    def test_audit_roundtrip_and_limit(self):
        r = add_record(self.player, 'alert', 'MyServer')
        for i in range(35):
            status = 'wyjaśniony' if i % 2 == 0 else 'do sprawdzenia'
            update_record_status(self.player, r['id'], status)
        self.assertEqual(len(r['review_history']), 25)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'fairplay.json'
            save_data(self.data, path)
            restored = load_data(path)
            rr = restored['players'][0]['records'][0]
            self.assertEqual(len(rr['review_history']), 25)
            self.assertEqual(rr['status'], r['status'])
            self.assertTrue(rr['updated_at'])

    def test_old_data_without_history_is_supported(self):
        item = add_record(self.player, 'ban', 'MyServer')
        item.pop('review_history')
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'fairplay.json'
            save_data(self.data,path)
            restored = load_data(path)
            self.assertEqual(restored['players'][0]['records'][0]['review_history'], [])


class TestGuardPresets(unittest.TestCase):
    def test_has_safe_standard(self):
        self.assertIn('safe', PRESETS)
        self.assertIn('normal', PRESETS)
        self.assertGreater(PRESETS['safe']['reach'], PRESETS['normal']['reach'])
        self.assertGreater(PRESETS['safe']['clicks'], PRESETS['normal']['clicks'])

    def test_valid_yaml_indicators(self):
        for name in PRESETS:
            raw = render_preset(name)
            self.assertIn('max-distance:', raw)
            self.assertIn('retention-days: 30', raw)
            self.assertNotIn('password', raw)
            self.assertNotIn('autoban', raw.casefold())

    def test_reject_bad_server_name(self):
        with self.assertRaises(ValueError):render_preset('safe', 'one: other')
        with self.assertRaises(ValueError):render_preset('missing')


if __name__ == '__main__':unittest.main()
