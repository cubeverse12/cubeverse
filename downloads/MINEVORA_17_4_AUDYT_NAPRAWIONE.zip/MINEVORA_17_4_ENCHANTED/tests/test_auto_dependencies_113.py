"""Offline tests; no network, Microsoft account or Qt required."""
import hashlib
import io
import json
import sys
import tempfile
import unittest
import urllib.error
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from minevora_auto_dependencies import (DependencyError, detect_loader_and_version,
    plan_missing_dependencies, install_missing_dependencies)


class MockResponse(io.BytesIO):
    def __init__(self, value, url):
        super().__init__(value)
        self.url = url
    def geturl(self):
        return self.url
    def __enter__(self):
        return self
    def __exit__(self, *_):
        self.close()


class TestAutoDependencies(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.game = Path(self.tmp.name)
        self.mods = self.game / 'mods'
        self.mods.mkdir()
        self.primary = b'primary'
        self.child = b'dependency'
        self.leaf = b'leaf'
        self.mods.joinpath('primary.jar').write_bytes(self.primary)
        self.h = hashlib.sha512(self.primary).hexdigest()
        self.childhash = hashlib.sha512(self.child).hexdigest()
        self.leafhash = hashlib.sha512(self.leaf).hexdigest()
        self.api = 'https://api.modrinth.com/v2'
        self.cdn = 'https://cdn.modrinth.com/data/child/ver/dependency.jar'
        self.child_version = self.version('child', 'vchild', 'dependency.jar', self.child,
                                          deps=[{'dependency_type':'required','project_id':'leaf'}])
        self.leaf_version = self.version('leaf', 'vleaf', 'leaf.jar', self.leaf)
        self.original_version = self.version('primary', 'vprimary', 'primary.jar', self.primary,
                                deps=[{'dependency_type':'required','project_id':'child'}])
        self.requests = []
        self.payloads = {
            '/version_file/' + self.h: self.original_version,
            '/version_file/' + self.childhash: self.child_version,
            '/version_file/' + self.leafhash: self.leaf_version,
            '/project/child/version': [self.child_version],
            '/project/leaf/version': [self.leaf_version],
        }
        self.downloads = {'dependency.jar': self.child, 'leaf.jar': self.leaf}

    def version(self, project, version, filename, content, deps=None):
        return {'project_id':project, 'id':version, 'game_versions':['1.21.1'],
                'loaders':['fabric'], 'version_type':'release', 'name': project,
                'dependencies': deps or [],
                'files':[{'filename':filename, 'primary':True, 'size':len(content),
                          'hashes':{'sha512':hashlib.sha512(content).hexdigest()},
                          'url':'https://cdn.modrinth.com/data/'+project+'/test/'+filename}]}

    def opener(self, request, timeout=None):
        from urllib.parse import urlparse
        url = request.full_url
        self.requests.append(url)
        if url.startswith(self.api):
            path = urlparse(url).path.removeprefix('/v2')
            if path not in self.payloads:
                raise urllib.error.HTTPError(url,404,'missing',{},None)
            return MockResponse(json.dumps(self.payloads[path]).encode(), url)
        assert url.startswith('https://cdn.modrinth.com/')
        file = urlparse(url).path.split('/')[-1]
        return MockResponse(self.downloads[file], url)

    def tearDown(self):
        self.tmp.cleanup()

    def test_detect_loader(self):
        self.assertEqual(detect_loader_and_version('fabric-loader-0.16.4-1.21.1'), ('1.21.1','fabric'))
        self.assertEqual(detect_loader_and_version('1.21.1-NeoForge-21.1.0'), ('1.21.1','neoforge'))
        self.assertEqual(detect_loader_and_version('1.21.1'), ('1.21.1',''))

    def test_recursive_dependencies(self):
        result = install_missing_dependencies(self.game, '1.21.1','fabric', opener=self.opener)
        self.assertEqual(result['installed'], ['dependency.jar','leaf.jar'])
        self.assertEqual((self.mods/'dependency.jar').read_bytes(),self.child)
        self.assertEqual((self.mods/'leaf.jar').read_bytes(),self.leaf)
        second = install_missing_dependencies(self.game, '1.21.1','fabric', opener=self.opener)
        self.assertEqual(second['installed'], [])

    def test_existing_dependency_not_changed(self):
        (self.mods/'dependency.jar').write_bytes(self.child)
        result = install_missing_dependencies(self.game,'1.21.1','fabric',opener=self.opener)
        self.assertEqual(result['installed'],['leaf.jar'])
        self.assertEqual((self.mods/'dependency.jar').read_bytes(),self.child)

    def test_optional_dependency_skipped(self):
        self.original_version['dependencies'][0]['dependency_type'] = 'optional'
        result = install_missing_dependencies(self.game,'1.21.1','fabric',opener=self.opener)
        self.assertEqual(result['installed'],[])

    def test_unrecognized_jar_is_preserved(self):
        (self.mods/'mystery.jar').write_bytes(b'unknown')
        result = install_missing_dependencies(self.game,'1.21.1','fabric',opener=self.opener)
        self.assertEqual(result['unrecognized'],1)
        self.assertEqual((self.mods/'mystery.jar').read_bytes(),b'unknown')

    def test_no_compatible_version(self):
        self.payloads['/project/child/version'] = []
        with self.assertRaisesRegex(DependencyError, 'Brak zgodnego'):
            install_missing_dependencies(self.game,'1.21.1','fabric',opener=self.opener)
        self.assertEqual(sorted(p.name for p in self.mods.iterdir()),['primary.jar'])

    def test_reject_wrong_cdn(self):
        self.child_version['files'][0]['url']='https://example.com/bad.jar'
        with self.assertRaisesRegex(DependencyError, 'CDN'):
            install_missing_dependencies(self.game,'1.21.1','fabric',opener=self.opener)
        self.assertEqual(sorted(p.name for p in self.mods.iterdir()),['primary.jar'])

    def test_download_corruption_rolls_back(self):
        self.downloads['leaf.jar'] = b'changed'
        with self.assertRaisesRegex(DependencyError, 'SHA-512|rozmiar'):
            install_missing_dependencies(self.game,'1.21.1','fabric',opener=self.opener)
        self.assertEqual(sorted(p.name for p in self.mods.iterdir()),['primary.jar'])

    def test_filename_collision_refuses_overwrite(self):
        (self.mods/'dependency.jar').write_bytes(b'not the mod from Modrinth')
        with self.assertRaisesRegex(DependencyError,'już istnieje'):
            plan_missing_dependencies(self.game,'1.21.1','fabric',opener=self.opener)
        self.assertEqual((self.mods/'dependency.jar').read_bytes(),b'not the mod from Modrinth')

    def test_incompatible_pinned_ref(self):
        self.original_version['dependencies'] = [{'dependency_type':'required', 'version_id':'vchild', 'project_id':'child'}]
        self.payloads['/version/vchild'] = dict(self.child_version, loaders=['forge'])
        with self.assertRaisesRegex(DependencyError,'niezgodna'):
            plan_missing_dependencies(self.game,'1.21.1','fabric',opener=self.opener)

if __name__ == '__main__':
    unittest.main()
