"""Tests for Skin Creator's pure UV and template engine."""
import unittest
from minevora_skin_core import (
    AREAS, LAYER_NAMES, PRESETS, allowed_pixel, rects_for_layer,
    generate_preset, flood_fill_points, pixels_on_line, safe_preset_name,
)

class SkinCreatorTests(unittest.TestCase):
    def test_preset_sizes_and_distinct_styles(self):
        images = {name: generate_preset(name) for name in PRESETS}
        self.assertEqual(len(set(images.values())), 3)
        for pixels in images.values():
            self.assertEqual(len(pixels), 64 * 64 * 4)
            self.assertGreater(sum(pixels[3::4]), 255*450)
            self.assertEqual(pixels[(20*64 + 11)*4 + 3], 255)
            self.assertEqual(pixels[(7*64 + 60)*4 + 3], 0)

    def test_accent_color_applied(self):
        one=generate_preset('Cyber Wilk','#123456')
        two=generate_preset('Cyber Wilk','#abcdef')
        self.assertNotEqual(one,two)
        self.assertEqual(tuple(one[(21*64+23)*4:(21*64+23)*4+3]), (18,52,86))

    def test_layer_islands(self):
        self.assertTrue(allowed_pixel('Kapelusz',40,8))
        self.assertFalse(allowed_pixel('Kapelusz',8,8))
        self.assertTrue(allowed_pixel('Kurtka',20,36))
        self.assertFalse(allowed_pixel('Kurtka',44,36))
        self.assertTrue(allowed_pixel('Rękawy',44,36))
        self.assertTrue(allowed_pixel('Rękawy',52,52))
        self.assertFalse(allowed_pixel('Rękawy',20,36))
        self.assertTrue(allowed_pixel('Nogawki',4,52))
        self.assertFalse(allowed_pixel('Nakładki',12,12))
        self.assertTrue(allowed_pixel('Baza',12,12))
        self.assertFalse(allowed_pixel('Baza',40,8))

    def test_legacy_height_limits(self):
        self.assertFalse(allowed_pixel('Wszystko',5,50,height=32))
        self.assertFalse(allowed_pixel('Kurtka',22,36,height=32))
        self.assertTrue(allowed_pixel('Kapelusz',44,10,height=32))

    def test_layer_boxes_within_64(self):
        for name in LAYER_NAMES:
            self.assertTrue(rects_for_layer(name))
            for l,t,r,b in rects_for_layer(name):
                self.assertTrue(0 <= l < r <= 64)
                self.assertTrue(0 <= t < b <= 64)

    def test_layer_constrained_flood(self):
        get=lambda x,y:(0,0,0,0)
        jacket=flood_fill_points(get,20,36,(255,0,0,255),'Kurtka')
        self.assertEqual(len(jacket),24*16)
        self.assertNotIn((44,36),jacket)
        self.assertEqual(flood_fill_points(get,10,10,(255,0,0,255),'Kurtka'),[])
        self.assertEqual(flood_fill_points(get,0,0,(0,0,0,0),'Wszystko'),[])

    def test_flood_respects_barrier(self):
        get=lambda x,y:(1,1,1,255) if x==4 else (0,0,0,0)
        points=flood_fill_points(get,2,3,(99,2,3,255),'Wszystko')
        self.assertEqual(len(points),4*64)
        self.assertNotIn((5,3),points)

    def test_lines_no_gaps(self):
        points=list(pixels_on_line(2,2,20,11))
        self.assertEqual(points[0],(2,2))
        self.assertEqual(points[-1],(20,11))
        for (x,y),(nx,ny) in zip(points,points[1:]):
            self.assertLessEqual(abs(x-nx),1)
            self.assertLessEqual(abs(y-ny),1)

    def test_preset_names_safe(self):
        self.assertEqual(safe_preset_name('../../CON'), 'my_skin')
        self.assertEqual(safe_preset_name(''), 'my_skin')
        self.assertNotIn('/',safe_preset_name('skin / test'))
        with self.assertRaises(ValueError):generate_preset('unknown')
        with self.assertRaises(ValueError):generate_preset('Cyber Wilk',accent='bad-color')

if __name__=='__main__':unittest.main()
