import unittest
from minevora_rewards import award_project, ensure


class CreatorXp3DTest(unittest.TestCase):
    def test_new_types_and_duplicate_protection(self):
        for category,points in [('Rigi Minecraft',25),('Modele Blender',20),('Modele Blockbench',20)]:
            state={'balance':100,'listings':[]}
            listing={'local_owner':True,'category':category,'title':'Projekt A','author':'Autor'}
            self.assertEqual(award_project(state,listing),points)
            self.assertEqual(award_project(state,listing),0)
            self.assertEqual(ensure(state)['xp'],points)


if __name__ == '__main__':unittest.main()
