import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError, URLError
from minevora_discord_announcements_core import (
    normalize_webhook, validate_download_url, build_announcement,
    announcement_fingerprint, record_sent, already_posted, post_webhook, read_history)

WEBHOOK='https://discord.com/api/webhooks/123456789012345678/AbCdE_fghIJKlmnOPQRST_uvWXyZ1234567'

class FakeResponse:
    def __init__(self, code=200, body=b'{"id":"123123123"}'):
        self.code=code
        self.body=body
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def getcode(self): return self.code
    def read(self,n): return self.body

class TestAnnouncements(unittest.TestCase):
    def test_normalize_valid(self):
        self.assertEqual(normalize_webhook(WEBHOOK),WEBHOOK)
    def test_reject_invite(self):
        with self.assertRaises(ValueError): normalize_webhook('https://discord.gg/8teEpYvzRd')
    def test_reject_lookalike(self):
        for url in ['https://discord.com.evil.com/api/webhooks/123/abc', 'http://'+WEBHOOK[8:],
                    WEBHOOK+'?redirect=1',WEBHOOK+'#foo',WEBHOOK.replace('discord.com','example.com')]:
            with self.subTest(url=url), self.assertRaises(ValueError):normalize_webhook(url)
    def test_build_valid(self):
        payload=build_announcement('10.4','Nowe ogłoszenia','Bot i webhook','https://github.com/example/minevora/releases/tag/v10.4')
        self.assertEqual(payload['allowed_mentions'],{'parse':[]})
        self.assertIn('10.4',payload['embeds'][0]['title'])
        self.assertEqual(payload['embeds'][0]['fields'][0]['inline'],False)
    def test_reject_bad_download(self):
        for link in ['http://example.com','file:///tmp/a','http://127.0.0.1','https://localhost/a']:
            with self.subTest(link=link),self.assertRaises(ValueError):validate_download_url(link)
    def test_reject_long_notes(self):
        with self.assertRaises(ValueError):build_announcement('1.0','Nowości','x'*3700)
    def test_duplicate_fingerprint_ignores_timestamp(self):
        a=build_announcement('10.4','Nowości','Lista zmian')
        b=build_announcement('10.4','Nowości','Lista zmian')
        b['embeds'][0]['timestamp']='2000-01-01T00:00:00+00:00'
        self.assertEqual(announcement_fingerprint(a),announcement_fingerprint(b))
    def test_record_sent_no_webhook(self):
        payload=build_announcement('10.4','Ogłoszenia','Działają')
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'state.json'
            record_sent(payload,'123456789',f)
            self.assertTrue(already_posted(payload,f))
            self.assertEqual(read_history(f)[0]['message_id'],'123456789')
            self.assertNotIn('webhook',f.read_text().lower())
    def test_fake_transport(self):
        captured=[]
        def fake(req,timeout):
            captured.append((req,timeout))
            return FakeResponse()
        payload=build_announcement('10.4','Nowości','Działają')
        self.assertEqual(post_webhook(WEBHOOK,payload,transport=fake),'123123123')
        self.assertEqual(captured[0][0].get_method(),'POST')
        self.assertIn('?wait=true',captured[0][0].full_url)
        body=json.loads(captured[0][0].data)
        self.assertEqual(body['allowed_mentions']['parse'],[])
    def test_unauthorized_masked(self):
        def fake(req, timeout):
            raise HTTPError(req.full_url,404,'gone',{},None)
        with self.assertRaisesRegex(RuntimeError,'404') as ctx:
            post_webhook(WEBHOOK,build_announcement('1.0','Test','A'),transport=fake)
        self.assertNotIn('AbCdE',str(ctx.exception))
    def test_network_error_masked(self):
        def fake(req, timeout):
            raise URLError('Failed '+WEBHOOK)
        with self.assertRaisesRegex(RuntimeError,'Nie udało się') as ctx:
            post_webhook(WEBHOOK,build_announcement('1.0','Test','A'),transport=fake)
        self.assertNotIn(WEBHOOK,str(ctx.exception))

if __name__=='__main__':unittest.main()
