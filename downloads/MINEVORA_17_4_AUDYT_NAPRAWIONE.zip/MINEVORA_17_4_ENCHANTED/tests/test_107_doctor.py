import tempfile,unittest
from pathlib import Path
from minevora_doctor import diagnose

class TestDoctor(unittest.TestCase):
 def test_detect_missing_files_and_dependencies_safely(self):
  with tempfile.TemporaryDirectory() as folder:
   errors,report=diagnose(base=folder,home=folder)
   self.assertGreaterEqual(errors,7)
   self.assertTrue(any('minevora_qt.py' in text for _,text in report))
 def test_does_not_disclose_preferences(self):
  with tempfile.TemporaryDirectory() as folder:
   p=Path(folder)/'.minevora'/'preferences.json';p.parent.mkdir()
   p.write_text('{"discord_secret":"do_not_echo"}',encoding='utf-8')
   _,report=diagnose(home=folder)
   self.assertNotIn('do_not_echo',str(report))
if __name__=='__main__':unittest.main()
