"""Regression tests for local project import. Run: python -m unittest discover -s tests"""
import json
import tempfile
import unittest
import uuid
import zipfile
from pathlib import Path
from unittest.mock import patch

import minevora_assets as assets


class AssetTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.patch_dir = patch.object(assets, 'ASSETS_DIR', self.base / 'market')
        self.patch_dir.start()
        self.addCleanup(self.patch_dir.stop)

    def test_category_format_matching(self):
        self.assertIn('.blend', assets.accepted_suffixes('Modele Blender'))
        self.assertIn('.bbmodel', assets.accepted_suffixes('Modele Blockbench'))
        self.assertIn('.bbmodel', assets.accepted_suffixes('Rigi Minecraft'))
        self.assertNotIn('.blend', assets.accepted_suffixes('Modele Blockbench'))

    def test_valid_blockbench_and_copy_survives_original_removal(self):
        original = self.base / 'avatar.bbmodel'
        original.write_text(json.dumps({'meta': {'model_format': 'free'}, 'elements': []}), encoding='utf-8')
        uid = str(uuid.uuid4())
        stored = assets.store_project_asset(uid, str(original), '', 'Rigi Minecraft')
        original.unlink()
        self.assertTrue(Path(stored['file']).is_file())
        self.assertIn('avatar', 'avatar')
        assets.remove_project_asset(uid)
        self.assertFalse(Path(stored['file']).exists())

    def test_blender_header(self):
        file = self.base / 'figure.blend'
        file.write_bytes(b'BLENDER-v300'+b'\0'*64)
        self.assertEqual(assets.validate_asset(file, 'Modele Blender'), '.blend')
        with self.assertRaises(ValueError):assets.validate_asset(file, 'Modele Blockbench')

    def test_reject_fake_blend_and_empty_files(self):
        f = self.base / 'bad.blend'
        f.write_bytes(b'not a blender project')
        with self.assertRaisesRegex(ValueError, 'Nie rozpoznano'):assets.validate_asset(f, 'Modele Blender')
        f.write_bytes(b'')
        with self.assertRaisesRegex(ValueError, 'pusty'):assets.validate_asset(f, 'Modele Blender')

    def test_gltf_and_bbmodel_json_content(self):
        f = self.base / 'rig.gltf'
        f.write_text('{"asset":{"version":"2.0"},"scenes":[]}', encoding='utf-8')
        self.assertEqual(assets.validate_asset(f, 'Modele Blender'), '.gltf')
        f.write_text('{"hello":"world"}', encoding='utf-8')
        with self.assertRaises(ValueError):assets.validate_asset(f, 'Modele Blender')

    def test_zip_with_unsafe_filename_is_rejected(self):
        z = self.base / 'content.zip'
        with zipfile.ZipFile(z,'w') as arc:
            arc.writestr('../unwanted.txt', 'hello')
        with self.assertRaisesRegex(ValueError, 'niebezpieczną'):assets.validate_asset(z,'Rigi Minecraft')

    def test_asset_and_preview_copied(self):
        model = self.base / 'dragon.obj'
        model.write_bytes(b'v 0.0 0.0 0.0\n')
        picture = self.base / 'preview.png'
        picture.write_bytes(b'\x89PNG\r\n\x1a\n'+b'test')
        uid = str(uuid.uuid4())
        stored = assets.store_project_asset(uid, str(model), str(picture), 'Modele Blender')
        self.assertEqual(Path(stored['file']).suffix, '.obj')
        self.assertTrue(Path(stored['image']).is_file())

    def test_no_deletion_outside_managed_folder(self):
        untouched = self.base / 'important.txt'
        untouched.write_text('keep')
        assets.remove_project_asset('../important.txt')
        self.assertEqual(untouched.read_text(), 'keep')


if __name__ == '__main__':
    unittest.main()
