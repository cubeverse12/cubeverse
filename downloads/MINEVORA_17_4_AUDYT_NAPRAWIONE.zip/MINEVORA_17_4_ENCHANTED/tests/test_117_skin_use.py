"""Offline tests of Minecraft Java skin upload. Never contact a live account."""
import io
import struct
import urllib.error
import zlib

import pytest

from minevora_skin_upload import (
    SKIN_API_URL, SkinUploadError, build_multipart, upload_skin, validate_skin_png,
)


def png_chunk(kind, payload):
    return (struct.pack('>I', len(payload)) + kind + payload
            + struct.pack('>I', zlib.crc32(kind+payload) & 0xffffffff))


def fake_skin(width=64,height=64):
    data=b''.join(b'\x00'+bytes([60,80,240,255])*width for _ in range(height))
    return (b'\x89PNG\r\n\x1a\n'+
            png_chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,6,0,0,0))+
            png_chunk(b'IDAT',zlib.compress(data))+
            png_chunk(b'IEND',b''))


def test_valid_skin_dimensions_and_legacy():
    assert validate_skin_png(fake_skin())==(64,64)
    assert validate_skin_png(fake_skin(64,32))==(64,32)


@pytest.mark.parametrize('wrong', [b'',b'not png',fake_skin(32,32),fake_skin(128,128),b'\x89PNG\r\n\x1a\n'])
def test_reject_invalid_skin(wrong):
    with pytest.raises(SkinUploadError):validate_skin_png(wrong)


def test_multipart_contains_png_and_variant():
    png=fake_skin()
    data=build_multipart(png,'slim','AbC123')
    assert b'name="variant"\r\n\r\nslim' in data
    assert b'filename="minevora_skin.png"' in data
    assert b'Content-Type: image/png' in data
    assert png in data
    assert data.endswith(b'--AbC123--\r\n')


@pytest.mark.parametrize('value',['Slim','alex','', 'steve'])
def test_disallow_other_variants(value):
    with pytest.raises(SkinUploadError):build_multipart(fake_skin(),value,'AbC123')


def test_upload_calls_only_official_url_and_uses_session_token():
    calls=[]
    class Response:
        def __enter__(self): return self
        def __exit__(self,*_): return False
        def getcode(self): return 200
    def opener(request,timeout):
        calls.append((request,timeout))
        return Response()
    upload_skin(fake_skin(),'mock_mc_token','classic',urlopen=opener)
    assert len(calls)==1
    req, timeout = calls[0]
    assert req.full_url==SKIN_API_URL
    assert req.get_method()=='POST'
    assert req.get_header('Authorization')=='Bearer mock_mc_token'
    assert req.get_header('Content-type').startswith('multipart/form-data; boundary=')
    assert b'name="variant"\r\n\r\nclassic' in req.data
    assert timeout==30


def test_expired_session_does_not_expose_token():
    def opener(request,timeout):
        raise urllib.error.HTTPError(SKIN_API_URL,401,'secret_token_in_server_reason',{},None)
    with pytest.raises(SkinUploadError,match='wygasła') as exc:
        upload_skin(fake_skin(),'SECRET_MINECRAFT_TOKEN',urlopen=opener)
    assert 'SECRET' not in str(exc.value)
    assert 'secret_token' not in str(exc.value)


def test_network_failure_has_safe_message():
    def opener(request,timeout):
        raise urllib.error.URLError('TOKEN_SHOULD_NEVER_BE_LOGGED')
    with pytest.raises(SkinUploadError) as exc:
        upload_skin(fake_skin(),'SECRET_TOKEN',urlopen=opener)
    assert 'TOKEN' not in str(exc.value)


def test_missing_login_aborts_without_network():
    called=[]
    def opener(*a,**k): called.append(1)
    with pytest.raises(SkinUploadError,match='zaloguj'):
        upload_skin(fake_skin(),'',urlopen=opener)
    assert not called


def test_rate_limiting_message():
    def opener(request,timeout):
        raise urllib.error.HTTPError(SKIN_API_URL,429,'no',{},None)
    with pytest.raises(SkinUploadError,match='Odczekaj'):
        upload_skin(fake_skin(),'FAKE',urlopen=opener)
