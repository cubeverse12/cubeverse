"""MINEVORA Backup & Restore 1.0.

Portable archive format, no external dependencies, Windows-friendly.
No authentication secrets are exported. Archives are not encrypted.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
import threading
import zipfile
from pathlib import Path, PurePosixPath
from typing import Callable

SCHEMA = 'minevora-backup-v1'
MAX_ITEMS = 250_000
MAX_RESTORE_BYTES = 250 * 1024**3
CHUNK = 1024 * 1024
NEVER_PARTS = {'__pycache__', '.git', '.venv', 'venv', 'node_modules', '.idea', '.vs', '$recycle.bin', 'system volume information'}
PRIVATE_WORDS = ('token', 'credential', 'password', 'passwd', 'secret', 'cookie', '.env', 'launcher_accounts', 'launcher_profiles', 'msa_', 'authentication', 'auth_', 'oauth', 'private_key', 'keyring', 'msal', 'login_cache', 'id_rsa')
SKIP_NAMES = {'thumbs.db', 'desktop.ini', '.ds_store'}
MC_SELECTED = ('saves', 'mods', 'config', 'resourcepacks', 'shaderpacks', 'screenshots', 'datapacks', 'servers.dat', 'options.txt', 'optionsof.txt', 'servers.dat_old')


def roots(base: Path | None = None, home: Path | None = None, appdata: Path | None = None) -> dict[str, Path]:
    home = Path(home or Path.home())
    appdata = Path(appdata or os.environ.get('APPDATA') or home / 'AppData' / 'Roaming')
    base = Path(base or Path(__file__).resolve().parent)
    return {
        'launcher': base,
        'minevora': home / '.minevora',
        'minecraft': appdata / '.minecraft',
        'appconfig': appdata / 'MINEVORA',
        'projects': home / 'Documents' / 'MINEVORA_Projekty_Odzyskane'
    }


def is_private_name(filename: str) -> bool:
    low = filename.lower()
    return low in SKIP_NAMES or any(word in low for word in PRIVATE_WORDS) or (low.startswith('.minevora_backup_') and low.endswith('.tmp')) or low.endswith('.minevora-backup.zip')


def should_skip(path: Path, root: Path) -> bool:
    try:
        rel = path.relative_to(root)
    except ValueError:
        return True
    if path.is_symlink():
        return True
    if any(p.lower() in NEVER_PARTS for p in rel.parts):
        return True
    if is_private_name(path.name):
        return True
    if rel.parts and rel.parts[0].lower() in {'logs', 'crash-reports', 'cache', 'caches', 'temp', 'tmp'}:
        return True
    return False


def walk_files(folder: Path):
    """Never follow symlinked directories; skip known cache/private files."""
    if not folder.is_dir() or folder.is_symlink():
        return
    for directory, dirs, files in os.walk(folder, followlinks=False):
        directory = Path(directory)
        dirs[:] = sorted(d for d in dirs if not should_skip(directory / d, folder))
        for f in sorted(files):
            p = directory / f
            if p.is_file() and not should_skip(p, folder):
                yield p, p.relative_to(folder)


def plan_sources(include: dict, env: dict[str, Path]) -> list[tuple[Path, str]]:
    chosen: list[tuple[Path, str]] = []
    if include.get('launcher'):
        for file, rel in walk_files(env['launcher']):
            chosen.append((file, 'launcher/' + rel.as_posix()))
    if include.get('minevora'):
        for file, rel in walk_files(env['minevora']):
            chosen.append((file, 'minevora/' + rel.as_posix()))
    if include.get('minecraft'):
        mc = env['minecraft']
        if include.get('minecraft_full'):
            candidates = list(walk_files(mc))
        else:
            candidates = []
            for name in MC_SELECTED:
                part = mc / name
                if part.is_file() and not part.is_symlink() and not is_private_name(part.name):
                    candidates.append((part, Path(name)))
                elif part.is_dir():
                    candidates.extend((p, Path(name) / r) for p, r in walk_files(part))
        for file, rel in candidates:
            chosen.append((file, 'minecraft/' + rel.as_posix()))
    # Explicitly save only the public Client ID (never credentials/tokens/session state).
    for i, directory in enumerate(include.get('projects', []), 1):
        directory = Path(directory).expanduser().resolve()
        if not directory.is_dir() or directory.is_symlink():
            continue
        for file, rel in walk_files(directory):
            chosen.append((file, f'projects/{i:02d}/' + rel.as_posix()))
    paths = [n for _, n in chosen]
    if len(paths) != len(set(paths)):
        raise ValueError('Wykryto powtarzające się ścieżki w kopii.')
    if len(paths) > MAX_ITEMS:
        raise ValueError(f'Za dużo plików: {len(paths)}.')
    return chosen


def read_public_config(env: dict[str, Path]) -> bytes | None:
    file = env['appconfig'] / 'config.json'
    try:
        data = json.loads(file.read_text(encoding='utf-8'))
        cid = data.get('client_id', '')
        if isinstance(cid, str) and re.fullmatch(r'[a-fA-F0-9-]{36}', cid):
            return json.dumps({'client_id': cid}, ensure_ascii=False, indent=2).encode('utf-8')
    except (OSError, UnicodeError, ValueError, AttributeError):
        pass
    return None


def _check_not_cancelled(cancel: threading.Event | None):
    if cancel and cancel.is_set():
        raise InterruptedError('Przerwano na żądanie użytkownika.')


def create_backup(destination: Path, include: dict, env: dict[str, Path] | None = None,
                  report: Callable[[str], None] | None = None,
                  progress: Callable[[int, int], None] | None = None,
                  cancel: threading.Event | None = None) -> dict:
    env = env or roots()
    destination = Path(destination).expanduser()
    if destination.suffix.lower() != '.zip':
        raise ValueError('Kopia musi mieć rozszerzenie .zip.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError('W tym miejscu już istnieje plik o takiej nazwie.')
    planned = plan_sources(include, env)
    config = read_public_config(env) if include.get('config') else None
    total = sum(p.stat().st_size for p, _ in planned) + (len(config) if config else 0)
    if total > MAX_RESTORE_BYTES:
        raise ValueError('Kopia przekracza maksymalny rozmiar 250 GB.')
    if not planned and not config:
        raise ValueError('Nie znaleziono plików do zapisania. Wybierz co najmniej jeden istniejący folder.')
    fd, temp_path = tempfile.mkstemp(prefix='.minevora_backup_', suffix='.tmp', dir=str(destination.parent))
    os.close(fd)
    temp = Path(temp_path)
    manifest = {'schema': SCHEMA, 'created_at': dt.datetime.now(dt.timezone.utc).isoformat(),
                'contents': {k: bool(include.get(k)) for k in ('launcher', 'minevora', 'minecraft', 'minecraft_full', 'config')},
                'project_names': [Path(x).name for x in include.get('projects', [])],
                'files': []}
    copied = 0
    try:
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=5, allowZip64=True) as z:
            for i, (file, name) in enumerate(planned):
                _check_not_cancelled(cancel)
                if report and (i % 15 == 0 or i == len(planned) - 1):
                    report(f'Pakowanie {i + 1}/{len(planned)}: {file.name}')
                size_expected = file.stat().st_size
                sha = hashlib.sha256()
                with file.open('rb') as src, z.open(name, 'w', force_zip64=True) as dst:
                    while True:
                        _check_not_cancelled(cancel)
                        block = src.read(CHUNK)
                        if not block: break
                        sha.update(block)
                        dst.write(block)
                        copied += len(block)
                        if progress: progress(copied, total)
                manifest['files'].append({'path': name, 'bytes': size_expected, 'sha256': sha.hexdigest()})
            if config is not None:
                name = 'appconfig/config.json'
                z.writestr(name, config)
                copied += len(config)
                manifest['files'].append({'path': name, 'bytes': len(config), 'sha256': hashlib.sha256(config).hexdigest()})
            z.writestr('MINEVORA_MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2))
        _check_not_cancelled(cancel)
        temp.replace(destination)
        if progress: progress(total, total)
        if report: report(f'Gotowe: {len(manifest["files"])} plików, {destination}')
        return manifest
    except BaseException:
        temp.unlink(missing_ok=True)
        raise


def _check_archive_path(name: str) -> tuple[str, str]:
    p = PurePosixPath(name)
    if not name or '\\' in name or name.startswith('/') or name.startswith('~') or ':' in name or any(x in ('', '.', '..') for x in name.split('/')):
        raise ValueError('Niebezpieczna ścieżka w archiwum: ' + name[:160])
    if len(p.parts) < 2 or p.parts[0] not in {'launcher', 'minevora', 'minecraft', 'appconfig', 'projects'}:
        raise ValueError('Nieznana lokalizacja docelowa w archiwum: ' + name[:160])
    if p.parts[0] == 'appconfig' and p.as_posix() != 'appconfig/config.json':
        raise ValueError('Niedozwolony plik konfiguracji.')
    if p.parts[0] == 'projects' and (len(p.parts) < 3 or not re.fullmatch(r'\d{2}', p.parts[1])):
        raise ValueError('Nieprawidłowa ścieżka dodatkowego projektu.')
    return p.parts[0], '/'.join(p.parts[1:])


def validate_backup(archive: Path) -> dict:
    archive = Path(archive)
    with zipfile.ZipFile(archive, 'r') as z:
        info_manifest = z.getinfo('MINEVORA_MANIFEST.json')
        if info_manifest.file_size > 50 * 1024 * 1024:
            raise ValueError('Manifest kopii jest zbyt duży.')
        manifest = json.loads(z.read('MINEVORA_MANIFEST.json'))
        if manifest.get('schema') != SCHEMA or not isinstance(manifest.get('files'), list):
            raise ValueError('Nieobsługiwany format kopii MINEVORA.')
        files = manifest['files']
        if len(files) > MAX_ITEMS:
            raise ValueError('Archiwum zawiera za dużo plików.')
        zip_entries = {i.filename: i for i in z.infolist()}
        if len(zip_entries) != len(z.infolist()):
            raise ValueError('Archiwum zawiera zduplikowane nazwy.')
        if set(zip_entries) != {x['path'] for x in files} | {'MINEVORA_MANIFEST.json'}:
            raise ValueError('Niezgodna lista plików w kopii.')
        total = 0
        for item in files:
            name = item['path']
            _check_archive_path(name)
            info = zip_entries[name]
            if info.is_dir() or stat.S_ISLNK(info.external_attr >> 16):
                raise ValueError('Niedozwolony typ pliku w archiwum: ' + name)
            if not isinstance(item.get('bytes'), int) or item['bytes'] < 0 or item['bytes'] != info.file_size:
                raise ValueError('Nieprawidłowy rozmiar pliku: ' + name)
            if not isinstance(item.get('sha256'), str) or not re.fullmatch('[0-9a-f]{64}', item['sha256']):
                raise ValueError('Brakuje sumy kontrolnej: ' + name)
            if info.file_size > 1024*1024 and info.file_size > max(1, info.compress_size) * 1000:
                raise ValueError('Podejrzany stopień kompresji pliku: ' + name)
            total += info.file_size
            if total > MAX_RESTORE_BYTES:
                raise ValueError('Kopia jest zbyt duża (maks. 250 GB).')
        manifest['total_bytes'] = total
        return manifest


def restore_path(name: str, target: dict[str, Path], project_names: list[str]) -> Path:
    cat, rel = _check_archive_path(name)
    if cat == 'projects':
        p = PurePosixPath(rel)
        idx = int(p.parts[0]) - 1
        folder = project_names[idx] if idx < len(project_names) else f'Projekt_{idx+1}'
        folder = re.sub(r'[^\w.\- ]', '_', str(folder), flags=re.UNICODE).strip(' .')[:80] or f'Projekt_{idx+1}'
        return target['projects'] / f'{idx+1:02d}_{folder}' / Path(*p.parts[1:])
    return target[cat] / Path(*PurePosixPath(rel).parts)


def restore_backup(archive: Path, target: dict[str, Path] | None = None, overwrite: bool = False,
                   report: Callable[[str], None] | None = None,
                   progress: Callable[[int, int], None] | None = None,
                   cancel: threading.Event | None = None) -> dict:
    """If overwrite=True, copy old files to private rescue folder before atomic replacement."""
    target = target or roots()
    manifest = validate_backup(archive)
    items = manifest['files']
    total = manifest['total_bytes']
    processed = 0
    restored = 0
    skipped = 0
    rescue = Path.home() / 'Documents' / ('MINEVORA_OCHRONA_PRZED_NADPISANIEM_' + dt.datetime.now().strftime('%Y%m%d_%H%M%S'))
    for key, path in target.items():
        if path.is_symlink():
            raise ValueError(f'Lokalizacja docelowa jest dowiązaniem: {key}')
    with zipfile.ZipFile(archive, 'r') as z:
        for i, item in enumerate(items):
            _check_not_cancelled(cancel)
            name = item['path']
            dest = restore_path(name, target, manifest.get('project_names', []))
            root_name = PurePosixPath(name).parts[0]
            if root_name == 'appconfig':
                # This file contains only a public client ID. Avoid overwriting existing settings.
                pass
            # Reject symlinked parent folders, even in the restored path.
            ancestor = dest.parent
            while ancestor != ancestor.parent:
                if ancestor.is_symlink():
                    raise ValueError('Wykryto dowiązanie w ścieżce przywracania: ' + str(ancestor))
                ancestor = ancestor.parent
            if dest.exists() and not overwrite:
                processed += item['bytes']
                skipped += 1
                if progress: progress(processed, total)
                continue
            if dest.is_symlink() or (dest.exists() and not dest.is_file()):
                raise ValueError('Cel nie jest zwykłym plikiem: ' + str(dest))
            dest.parent.mkdir(parents=True, exist_ok=True)
            sha = hashlib.sha256()
            fd, tmpname = tempfile.mkstemp(prefix='.minevora-restore-', dir=str(dest.parent))
            os.close(fd)
            tmp = Path(tmpname)
            try:
                with z.open(name, 'r') as src, tmp.open('wb') as out:
                    while True:
                        _check_not_cancelled(cancel)
                        block = src.read(CHUNK)
                        if not block: break
                        out.write(block)
                        sha.update(block)
                        processed += len(block)
                        if progress: progress(processed, total)
                if sha.hexdigest() != item['sha256']:
                    raise ValueError('Uszkodzony plik w kopii (SHA-256): ' + name)
                if dest.exists():
                    protected = rescue / Path(name)
                    protected.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dest, protected)
                os.replace(tmp, dest)
                restored += 1
                if report and (i % 15 == 0 or i == len(items) - 1):
                    report(f'Przywrócono {i+1}/{len(items)}: {dest.name}')
            finally:
                tmp.unlink(missing_ok=True)
    if report:
        report(f'Przywrócono: {restored}; pominięto istniejące: {skipped}.')
        if overwrite and rescue.exists(): report(f'Poprzednie pliki zapisano w: {rescue}')
    return {'restored': restored, 'skipped': skipped, 'safety_folder': str(rescue) if rescue.exists() else None}
