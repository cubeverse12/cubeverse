@echo off
cd /d "%~dp0"
python TESTUJ_MOTYW.py
pause
