"""Offline regression tests for MINEVORA Together: python TESTY_TOGETHER.py"""
from __future__ import annotations
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from minevora_together_core import (
    normalize_server_address, load_bookmarks, save_bookmarks,
    get_essential_release, existing_essential_files, install_essential,
)
from minevora_auto_dependencies import DependencyError

class TogetherTests(unittest.TestCase):
    def test_addresses(self):
        self.assertEqual(normalize_server_address('EXAMPLE.COM:25565'),'example.com:25565')
        self.assertEqual(normalize_server_address(' [2001:db8::1]:25565 '),'[2001:db8::1]:25565')
        self.assertEqual(normalize_server_address('localhost'),'localhost')
        for invalid in ('','https://a.test','a.test:65536','a.test:0','a.test/abc','user@host', 'some host', 'bad_&host','2001:db8::1'):
            with self.subTest(invalid=invalid):
                with self.assertRaises(ValueError):normalize_server_address(invalid)

    def test_local_bookmark_persistence(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'settings'/'friends.json'
            data=[{'name':'Testowy znajomy','address':'play.example.com:25565'}]
            save_bookmarks(data,path)
            self.assertEqual(load_bookmarks(path),data)
            with self.assertRaises(ValueError):save_bookmarks(data+data,path)
            self.assertEqual(load_bookmarks(path),data)

    def test_essential_detection(self):
        with tempfile.TemporaryDirectory() as folder:
            mods=Path(folder)/'mods';mods.mkdir()
            (mods/'Essential-fabric-1.21.1.jar').write_bytes(b'a')
            (mods/'sodium.jar').write_bytes(b'b')
            self.assertEqual(existing_essential_files(folder),['Essential-fabric-1.21.1.jar'])

    def test_version_filter_rejects_wrong_release(self):
        project={'id':'project12','slug':'essential','project_type':'mod'}
        versions=[{'project_id':'project12','id':'wrong', 'version_type':'release',
                  'game_versions':['1.20.1'],'loaders':['fabric'],'files':[]}]
        with patch('minevora_together_core._get_json',side_effect=[project,versions]):
            with self.assertRaises(DependencyError):get_essential_release('1.21.1','fabric')
        with self.assertRaises(DependencyError):get_essential_release('1.21.1','quilt')

    def test_release_provides_verified_info(self):
        project={'id':'AB12','slug':'essential','project_type':'mod'}
        modbytes=b'safe test archive bytes'
        version={'id':'ver12','project_id':'AB12','name':'Essential','version_type':'release',
                 'game_versions':['1.21.1'],'loaders':['fabric'],
                 'files':[{'primary':True,'filename':'essential-fabric.jar',
                           'hashes':{'sha512':hashlib.sha512(modbytes).hexdigest()},
                           'url':'https://cdn.modrinth.com/data/AB12/versions/ver12/essential-fabric.jar',
                           'size':len(modbytes)}]}
        with patch('minevora_together_core._get_json',side_effect=[project,[version]]):
            release=get_essential_release('1.21.1','fabric')
        self.assertEqual(release['project_id'],'AB12')
        self.assertEqual(release['filename'],'essential-fabric.jar')

    def test_install_rollback_if_dependency_fails(self):
        with tempfile.TemporaryDirectory() as folder:
            tmp=Path(folder)/'stage';tmp.write_bytes(b'good-data')
            payload={'filename':'essential-fabric.jar'}
            with (patch('minevora_together_core.get_essential_release',return_value=payload),
                  patch('minevora_together_core._download_verified',return_value=tmp),
                  patch('minevora_together_core.install_missing_dependencies',side_effect=DependencyError('dependency missing'))):
                with self.assertRaises(DependencyError):install_essential(folder,'1.21.1','fabric')
            self.assertFalse((Path(folder)/'mods'/'essential-fabric.jar').exists())

    def test_install_success_and_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            first=Path(folder)/'stage';first.write_bytes(b'good-data')
            with (patch('minevora_together_core.get_essential_release',return_value={'filename':'essential-fabric.jar'}),
                  patch('minevora_together_core._download_verified',return_value=first),
                  patch('minevora_together_core.install_missing_dependencies',return_value={'installed':['api.jar']})):
                result=install_essential(folder,'1.21.1','fabric')
            self.assertEqual(result['status'],'installed')
            self.assertEqual(result['dependencies'],['api.jar'])
            self.assertEqual((Path(folder)/'mods'/'essential-fabric.jar').read_bytes(),b'good-data')
            self.assertEqual(install_essential(folder,'1.21.1','fabric')['status'],'already_installed')

if __name__=='__main__': unittest.main(verbosity=2)
