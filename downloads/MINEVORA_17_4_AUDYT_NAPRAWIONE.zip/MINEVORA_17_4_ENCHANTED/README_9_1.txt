MINEVORA 9.1 — CREATOR RANKS

Rozpakuj caly ZIP do nowego folderu; uruchom INSTALUJ_ZALEZNOSCI.bat, a potem URUCHOM_MINEVORA.bat.
Aby zaktualizowac istniejacy folder MINEVORA 9.0, skopiuj wszystkie pliki, nadpisz starsze wersje, zachowaj folder rank_icons.

System TWORCA I RANGI: osobna zakladka Rangi twórcy, sześć kolorowych logo (PNG 320x320), pasek XP, poziomy, statystyki projektow, dzienna nagroda 50 MVC, nagrody MVC za kazdy zdobyty poziom.
XP: +120 za Mape, +80 za Budowle, +15 za pozostale kategorie. XP przyznawane jest tylko raz za taka sama kombinacje kategorii, nicku autora i nazwy projektu. Usuniecie oraz ponowne dodanie projektu nie daje ponownie XP. Wczesniej dodane wlasne projekty sa rozpoznawane przy pierwszym uruchomieniu.
Konieczne jest zapisanie projektu przez Marketplace -> Dodaj projekt. To jest demo lokalne, bez serwera i weryfikacji publikacji; MVC nie mozna wymienic na prawdziwe pieniadze.
Dzienna nagroda odnawia sie wedlug daty UTC. Postep zapisuje sie w ~/.minevora/market_demo.json wraz z portfelem i projektami.
Nie usuwaj market_demo.json, jesli chcesz zachowac postepy.
Pozostale funkcje (HUD, Discord RPC, Modrinth) pozostaja w pakiecie; nadal moga wymagac konfiguracji i testow Windows.
