"""MINEVORA Together — in-launcher companion for multiplayer social play.

The panel does not create its own P2P transport. Optional user-authorized
Essential installation provides in-game hosting/friends through Essential.
"""
from __future__ import annotations

from pathlib import Path
from PySide6.QtCore import QThread, Signal, Qt, QUrl
from PySide6.QtGui import QDesktopServices, QPixmap
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QFrame, QLabel, QPushButton,
    QListWidget, QLineEdit, QGridLayout, QScrollArea, QMessageBox,
)
from minevora_auto_dependencies import detect_loader_and_version
from minevora_together_core import (
    existing_essential_files, install_essential, load_bookmarks, save_bookmarks,
    normalize_server_address,
)


class EssentialInstallWorker(QThread):
    progress = Signal(str)
    done = Signal(object)
    error = Signal(str)

    def __init__(self, game_dir: str, mc_version: str, loader: str, parent=None):
        super().__init__(parent)
        self.game_dir=game_dir;self.mc_version=mc_version;self.loader=loader

    def run(self):
        try:
            result=install_essential(self.game_dir,self.mc_version,self.loader,progress=self.progress.emit)
            self.done.emit(result)
        except Exception as exc:
            self.error.emit(str(exc))


class TogetherPage(QWidget):
    def __init__(self, game_dir, get_version, game_running, launch_game,
                 open_chat, open_skins, parent=None):
        super().__init__(parent)
        self.game_dir=game_dir
        self.get_version=get_version
        self.game_running=game_running
        self.launch_game=launch_game
        self.open_chat=open_chat
        self.open_skins=open_skins
        self.worker=None
        self.servers=[]
        root=QVBoxLayout(self)
        root.setContentsMargins(26,22,26,16)
        root.setSpacing(15)

        header=QFrame();header.setObjectName('hero')
        h=QVBoxLayout(header);h.setContentsMargins(30,26,30,26);h.setSpacing(10)
        tag=QLabel('MINEVORA  /  TOGETHER  ✦  11.4')
        tag.setStyleSheet('color:#d9b9ff;font-size:12px;font-weight:800;letter-spacing:2px;background:transparent')
        h.addWidget(tag)
        title=QLabel('RAZEM W JEDNYM ŚWIECIE')
        title.setStyleSheet('font-size:26px;font-weight:900;background:transparent;color:white')
        h.addWidget(title)
        subtitle=QLabel('Zaproś znajomych do Minecrafta. Instalator Essential, ulubione serwery, czat MINEVORA i galeria screenów w jednym miejscu.')
        subtitle.setWordWrap(True);subtitle.setStyleSheet('font-size:13px;color:#d2c7e7;background:transparent')
        h.addWidget(subtitle)
        row=QHBoxLayout()
        self.install_btn=self.make_button('✦  WŁĄCZ GRĘ ZE ZNAJOMYMI',self.install,True)
        row.addWidget(self.install_btn)
        row.addWidget(self.make_button('▶  Uruchom Minecraft',self.launch_game))
        row.addStretch()
        h.addLayout(row)
        self.status=QLabel('Sprawdzam aktywną instancję…')
        self.status.setWordWrap(True)
        self.status.setStyleSheet('color:#decfff;font-size:12px;background:transparent')
        h.addWidget(self.status)
        root.addWidget(header)

        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.NoFrame)
        body=QWidget();grid=QGridLayout(body);grid.setHorizontalSpacing(15);grid.setVerticalSpacing(15);grid.setContentsMargins(0,0,0,8)

        info=self.panel('01  HOSTUJ ŚWIAT MINECRAFT')
        i=info.layout()
        self.version_info=QLabel('')
        self.version_info.setWordWrap(True);i.addWidget(self.version_info)
        host_expl=QLabel('Po instalacji uruchom grę, wejdź do swojego świata i użyj menu Essential, aby zaprosić znajomych. Hosting i lista znajomych działają przez oficjalną usługę Essential, nie przez serwery MINEVORA.')
        host_expl.setWordWrap(True);host_expl.setStyleSheet('color:#bbc9e0');i.addWidget(host_expl)
        info_link=self.make_button('↗  Otwórz oficjalne informacje o modzie',lambda:QDesktopServices.openUrl(QUrl('https://modrinth.com/mod/essential')))
        i.addWidget(info_link)
        i.addStretch();grid.addWidget(info,0,0)

        social=self.panel('02  ZNAJOMI I CZAT')
        s=social.layout()
        friends_info=QLabel('Czat społecznościowy MINEVORA otworzysz w launcherze. Czat i zaproszenia wewnątrz gry udostępnia Essential po jego zainstalowaniu.')
        friends_info.setWordWrap(True);friends_info.setStyleSheet('color:#bbc9e0');s.addWidget(friends_info)
        s.addWidget(self.make_button('☏  Otwórz czat MINEVORA',self.open_chat))
        s.addWidget(self.make_button('✧  Zmień skin Minecraft',self.open_skins))
        s.addStretch();grid.addWidget(social,0,1)

        server=self.panel('03  TWOJE SERWERY I ZNAJOMI (LOKALNIE)')
        sv=server.layout()
        help_label=QLabel('Zapisuj adresy serwerów otrzymane od znajomych. Są przechowywane tylko na tym komputerze. To nie jest lista graczy online.')
        help_label.setWordWrap(True);help_label.setStyleSheet('color:#bbc9e0');sv.addWidget(help_label)
        addr_row=QHBoxLayout()
        self.friend_name=QLineEdit();self.friend_name.setPlaceholderText('Nazwa / znajomy')
        self.friend_address=QLineEdit();self.friend_address.setPlaceholderText('play.example.com:25565')
        addr_row.addWidget(self.friend_name,1);addr_row.addWidget(self.friend_address,2)
        sv.addLayout(addr_row)
        sv.addWidget(self.make_button('＋  Zapisz serwer',self.add_server))
        self.server_list=QListWidget();self.server_list.setMinimumHeight(124);sv.addWidget(self.server_list)
        actions=QHBoxLayout()
        actions.addWidget(self.make_button('⧉  Kopiuj adres',self.copy_server))
        actions.addWidget(self.make_button('−  Usuń',self.remove_server))
        sv.addLayout(actions)
        sv.addStretch();grid.addWidget(server,1,0)

        images=self.panel('04  TWOJE SCREENSHOTY')
        im=images.layout()
        im.addWidget(QLabel('Zdjęcia z katalogu screenshots Twojej instancji Minecraft.'))
        image_actions=QHBoxLayout()
        image_actions.addWidget(self.make_button('↻  Odśwież',self.refresh_screenshots))
        image_actions.addWidget(self.make_button('📁  Otwórz folder',self.open_screenshots))
        im.addLayout(image_actions)
        self.images_grid=QGridLayout();self.images_grid.setSpacing(6)
        im.addLayout(self.images_grid)
        im.addStretch();grid.addWidget(images,1,1)
        grid.setColumnStretch(0,1);grid.setColumnStretch(1,1)
        scroll.setWidget(body);root.addWidget(scroll,1)
        root.addWidget(self.note('Prywatność: nigdy nie wklejaj tokenów logowania. Adresy prywatnych serwerów udostępniaj wyłącznie osobom, którym ufasz.'))
        self.load_servers()
        self.refresh_status()
        self.refresh_screenshots()

    @staticmethod
    def note(message):
        label=QLabel(message);label.setWordWrap(True)
        label.setStyleSheet('color:#abb9d5;font-size:11px;')
        return label

    @staticmethod
    def make_button(label,fn,primary=False):
        button=QPushButton(label)
        if primary:button.setObjectName('primary')
        button.setCursor(Qt.PointingHandCursor)
        button.clicked.connect(fn)
        return button

    @staticmethod
    def panel(title):
        frame=QFrame();frame.setObjectName('panel')
        layout=QVBoxLayout(frame);layout.setContentsMargins(19,18,19,20);layout.setSpacing(12)
        label=QLabel(title);label.setStyleSheet('font-size:14px;font-weight:800;color:#ebd7ff')
        layout.addWidget(label)
        return frame

    def refresh_status(self):
        version=self.get_version()
        mc_version,loader=detect_loader_and_version(version)
        self.version_info.setText(f'Wybrana wersja: {version or "brak"}\nLoader: {loader or "nie wykryto"}')
        if not mc_version or loader not in ('fabric','forge','neoforge'):
            self.status.setText('Wybierz instalację Minecraft z Fabric, Forge lub NeoForge. Dla zwykłej wersji bez loadera nie można zainstalować moda.')
            return
        try:found=existing_essential_files(self.game_dir())
        except Exception as exc:
            self.status.setText('Błąd katalogu gry: '+str(exc));return
        self.status.setText(('✓ Essential jest w mods: '+', '.join(found[:2])) if found else
                            'Essential nie jest zainstalowany • gotowy do pobrania zgodnej wersji z Modrinth.')

    def install(self):
        if self.worker is not None and self.worker.isRunning():return
        if self.game_running():
            QMessageBox.warning(self,'MINEVORA Together','Zamknij Minecraft przed instalacją moda.');return
        mc_version,loader=detect_loader_and_version(self.get_version())
        if not mc_version or loader not in ('fabric','forge','neoforge'):
            QMessageBox.information(self,'MINEVORA Together',
                'Najpierw wybierz profil Fabric, Forge lub NeoForge w zakładce Graj / Wersje. Vanilla nie obsługuje modów.');return
        folder=self.game_dir()
        try:existing=existing_essential_files(folder)
        except Exception as exc:
            QMessageBox.warning(self,'MINEVORA Together',str(exc));return
        if existing:
            QMessageBox.information(self,'MINEVORA Together','Essential jest już zainstalowany:\n'+', '.join(existing)+'\n\nUruchom grę, aby korzystać z jego funkcji.');return
        question=(f'Zainstalować oficjalny Essential Mod z Modrinth dla Minecraft {mc_version} / {loader}?\n\n'
                  'Mod działa jako produkt zewnętrzny. Będzie pobrany po Twojej zgodzie, a pliki sprawdzone SHA-512. '
                  'MINEVORA nie tworzy własnego tunelu ani nie prowadzi kont Essential.\n\n'
                  'Pamiętaj, że Essential oferuje usługi sieciowe według swoich warunków.')
        if QMessageBox.question(self,'Pobieranie dodatku Essential',question,QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        self.install_btn.setEnabled(False)
        self.status.setText('Rozpoczynam pobieranie…')
        self.worker=EssentialInstallWorker(str(folder),mc_version,loader,self)
        self.worker.progress.connect(self.status.setText)
        self.worker.done.connect(self.installed)
        self.worker.error.connect(self.failed)
        self.worker.finished.connect(lambda:self.install_btn.setEnabled(True))
        self.worker.start()

    def installed(self,result):
        self.refresh_status()
        deps=result.get('dependencies',[])
        QMessageBox.information(self,'MINEVORA Together',
          'Zainstalowano oficjalny Essential: '+', '.join(result.get('files',[]))+f'\nDodatkowe biblioteki: {len(deps)}\n\n'
          'Otwórz Minecraft i zaproś znajomych z menu Essential.')

    def failed(self,error):
        self.status.setText('Nie udało się zainstalować: '+error)
        QMessageBox.warning(self,'MINEVORA Together',error)

    def load_servers(self):
        self.servers=load_bookmarks()
        self.render_servers()

    def render_servers(self):
        self.server_list.clear()
        for item in self.servers:self.server_list.addItem(item['name']+'   •   '+item['address'])

    def add_server(self):
        try:address=normalize_server_address(self.friend_address.text())
        except ValueError as exc:
            QMessageBox.warning(self,'Adres serwera',str(exc));return
        name=self.friend_name.text().strip()[:48] or address
        if any(x['address']==address for x in self.servers):
            QMessageBox.information(self,'MINEVORA Together','Ten adres jest już zapisany.');return
        try:save_bookmarks(self.servers+[{'name':name,'address':address}])
        except (OSError,ValueError) as exc:
            QMessageBox.warning(self,'MINEVORA Together',str(exc));return
        self.load_servers();self.friend_address.clear();self.friend_name.clear()

    def copy_server(self):
        index=self.server_list.currentRow()
        if not 0<=index<len(self.servers):
            QMessageBox.information(self,'MINEVORA Together','Najpierw wybierz serwer z listy.');return
        QApplication.clipboard().setText(self.servers[index]['address'])
        self.status.setText('Adres skopiowany. Minecraft → Multiplayer → Dodaj serwer / Połącz bezpośrednio.')

    def remove_server(self):
        index=self.server_list.currentRow()
        if not 0<=index<len(self.servers):return
        try:save_bookmarks(self.servers[:index]+self.servers[index+1:])
        except (OSError,ValueError) as exc:
            QMessageBox.warning(self,'MINEVORA Together',str(exc));return
        self.load_servers()

    def screenshots_dir(self):
        return Path(self.game_dir())/'screenshots'

    def open_screenshots(self):
        folder=self.screenshots_dir()
        folder.mkdir(parents=True,exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder.resolve())))

    def refresh_screenshots(self):
        while self.images_grid.count():
            cell=self.images_grid.takeAt(0)
            if cell.widget():cell.widget().deleteLater()
        folder=self.screenshots_dir()
        pictures=[]
        if folder.exists() and folder.is_dir() and not folder.is_symlink():
            pictures=sorted((p for p in folder.iterdir() if p.is_file() and not p.is_symlink()
                             and p.suffix.lower() in ('.png','.jpg','.jpeg') and p.stat().st_size<15*1024*1024),
                             key=lambda p:p.stat().st_mtime,reverse=True)[:6]
        if not pictures:
            self.images_grid.addWidget(self.note('Brak screenshotów. W grze naciśnij F2.'),0,0)
        for index,path in enumerate(pictures):
            button=QPushButton();button.setToolTip(path.name)
            photo=QPixmap(str(path))
            button.setIconSize(__import__('PySide6.QtCore',fromlist=['QSize']).QSize(150,80))
            if not photo.isNull():
                from PySide6.QtGui import QIcon
                button.setIcon(QIcon(photo.scaled(150,80,Qt.KeepAspectRatio,Qt.SmoothTransformation)))
            else:button.setText(path.name[:16])
            button.clicked.connect(lambda checked=False,p=path:QDesktopServices.openUrl(QUrl.fromLocalFile(str(p))))
            self.images_grid.addWidget(button,index//3,index%3)

    def closeEvent(self,event):
        if self.worker is not None and self.worker.isRunning():
            event.ignore();return
        super().closeEvent(event)
