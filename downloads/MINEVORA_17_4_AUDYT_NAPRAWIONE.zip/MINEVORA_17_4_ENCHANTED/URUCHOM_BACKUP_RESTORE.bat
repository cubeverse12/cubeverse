@echo off
cd /d "%~dp0"
title MINEVORA Backup and Restore 10.1
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 MINEVORA_BACKUP_RESTORE.py
) else (
    python MINEVORA_BACKUP_RESTORE.py
)
if errorlevel 1 (
    echo.
    echo Nie mozna uruchomic narzedzia. Zainstaluj Python 3 z tkinter.
    pause
)
