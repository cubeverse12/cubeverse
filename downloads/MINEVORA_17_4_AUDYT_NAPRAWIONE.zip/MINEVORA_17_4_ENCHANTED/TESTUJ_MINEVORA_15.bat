@echo off
cd /d "%~dp0"
python TESTUJ_MINEVORA_15.py
pause
