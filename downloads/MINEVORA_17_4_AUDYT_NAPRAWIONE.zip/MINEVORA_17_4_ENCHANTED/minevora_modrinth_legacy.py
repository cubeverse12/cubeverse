"""Modrinth API v2 search and verified single-file mod downloads."""
import hashlib
import json
import re
import urllib.parse
import urllib.request
from pathlib import Path
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QComboBox, QPushButton, QListWidget, QListWidgetItem, QMessageBox)

API = 'https://api.modrinth.com/v2'
HEADERS = {'User-Agent': 'MINEVORA/7.4 (Minecraft launcher)', 'Accept': 'application/json'}

def request_json(path, params=None):
    url = API + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=20) as response:
        return json.load(response)

class ModrinthWorker(QThread):
    done = Signal(object)
    error = Signal(str)
    def __init__(self, action, **kwargs):
        super().__init__()
        self.action, self.kwargs = action, kwargs
    def run(self):
        try:
            if self.action == 'search':
                facets = [['project_type:mod'], ['versions:' + self.kwargs['version']],
                          ['categories:' + self.kwargs['loader']]]
                data = request_json('/search', {'query': self.kwargs['query'],
                    'limit': 30, 'facets': json.dumps(facets)})
                self.done.emit(data.get('hits', []))
            else:
                project = self.kwargs['project']
                version = self.kwargs['version']
                loader = self.kwargs['loader']
                versions = request_json('/project/' + urllib.parse.quote(project, safe='') + '/version',
                    {'loaders': json.dumps([loader]), 'game_versions': json.dumps([version])})
                if not versions:
                    raise ValueError('Nie znaleziono zgodnego wydania tego moda.')
                files = versions[0].get('files', [])
                file = next((f for f in files if f.get('primary')), files[0] if files else None)
                if not file:
                    raise ValueError('Brak pliku do pobrania.')
                name = file.get('filename', '')
                if not re.fullmatch(r'[A-Za-z0-9_.+()\[\] -]+\.jar', name, re.I):
                    raise ValueError('Nieprawidłowa nazwa pliku moda.')
                url = file.get('url', '')
                if not url.startswith('https://'):
                    raise ValueError('Niebezpieczny adres pobierania.')
                folder = Path(self.kwargs['mc_dir']) / 'mods'
                folder.mkdir(parents=True, exist_ok=True)
                dest = folder / name
                if dest.exists():
                    raise FileExistsError('Plik już istnieje: ' + name)
                tmp = folder / (name + '.minevora-part')
                try:
                    req = urllib.request.Request(url, headers={'User-Agent': HEADERS['User-Agent']})
                    digest = hashlib.sha512()
                    total = 0
                    with urllib.request.urlopen(req, timeout=45) as response, tmp.open('wb') as out:
                        while True:
                            chunk = response.read(65536)
                            if not chunk: break
                            total += len(chunk)
                            if total > 100 * 1024 * 1024:
                                raise ValueError('Plik przekracza limit 100 MB.')
                            digest.update(chunk)
                            out.write(chunk)
                    expected = file.get('hashes', {}).get('sha512')
                    if expected and digest.hexdigest().lower() != expected.lower():
                        raise ValueError('Suma kontrolna SHA-512 nie zgadza się.')
                    tmp.replace(dest)
                finally:
                    tmp.unlink(missing_ok=True)
                self.done.emit(str(dest))
        except Exception as exc:
            self.error.emit(str(exc))

class ModrinthDialog(QDialog):
    def __init__(self, mc_dir, selected_version=None, parent=None):
        super().__init__(parent)
        self.mc_dir = mc_dir
        self.worker = None
        self.hits = []
        self.setWindowTitle('MINEVORA • Modrinth')
        self.resize(760, 620)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel('MODRINTH  •  KATALOG MODÓW'))
        layout.addWidget(QLabel('Wybierz wersję Minecraft i loader zgodny z Twoją instalacją.'))
        row = QHBoxLayout()
        self.search_text = QLineEdit()
        self.search_text.setPlaceholderText('Szukaj modów, np. Sodium')
        self.version = QLineEdit()
        self.version.setPlaceholderText('np. 1.21.1')
        match = re.search(r'\d+\.\d+(?:\.\d+)?', selected_version or '')
        self.version.setText(match.group() if match else '')
        self.loader = QComboBox()
        self.loader.addItems(['fabric', 'forge', 'neoforge', 'quilt'])
        if selected_version:
            for i in range(self.loader.count()):
                if self.loader.itemText(i) in selected_version.lower():
                    self.loader.setCurrentIndex(i)
                    break
        self.search_button = QPushButton('Szukaj')
        self.search_button.clicked.connect(self.search)
        row.addWidget(self.search_text, 3)
        row.addWidget(self.version, 1)
        row.addWidget(self.loader, 1)
        row.addWidget(self.search_button)
        layout.addLayout(row)
        self.results = QListWidget()
        layout.addWidget(self.results)
        self.description = QLabel('Wybierz mod z listy, aby zobaczyć opis.')
        self.description.setWordWrap(True)
        layout.addWidget(self.description)
        self.install_button = QPushButton('Pobierz mod do folderu wybranej instancji')
        self.install_button.clicked.connect(self.install)
        layout.addWidget(self.install_button)
        self.status = QLabel('Źródło: Modrinth API. Instalacja zależności nie jest jeszcze automatyczna.')
        layout.addWidget(self.status)
        self.results.currentRowChanged.connect(self.describe)
        self.search_text.returnPressed.connect(self.search)
    def busy(self, busy):
        self.search_button.setEnabled(not busy)
        self.install_button.setEnabled(not busy)
    def search(self):
        version = self.version.text().strip()
        if not re.fullmatch(r'\d+\.\d+(?:\.\d+)?', version):
            QMessageBox.warning(self, 'Modrinth', 'Podaj wersję Minecraft, np. 1.21.1.')
            return
        self.busy(True)
        self.status.setText('Wyszukiwanie w Modrinth…')
        self.worker = ModrinthWorker('search', query=self.search_text.text().strip(),
            version=version, loader=self.loader.currentText())
        self.worker.done.connect(self.search_done)
        self.worker.error.connect(self.failed)
        self.worker.finished.connect(lambda: self.busy(False))
        self.worker.start()
    def search_done(self, hits):
        self.hits = hits
        self.results.clear()
        for hit in hits:
            self.results.addItem(QListWidgetItem(hit.get('title', 'Bez nazwy') +
                '  •  ' + hit.get('author', '')))
        self.status.setText(f'Znaleziono {len(hits)} wyników.')
    def describe(self, index):
        if 0 <= index < len(self.hits):
            hit = self.hits[index]
            self.description.setText(hit.get('description', '')[:550])
    def install(self):
        idx = self.results.currentRow()
        if not 0 <= idx < len(self.hits):
            QMessageBox.information(self, 'Modrinth', 'Najpierw wybierz mod.')
            return
        hit = self.hits[idx]
        if QMessageBox.question(self, 'Pobieranie',
                'Pobrać „' + hit.get('title', 'mod') + '” do folderu mods wybranej instancji?\n'
                'Upewnij się, że loader jest zgodny z wybraną wersją gry.') != QMessageBox.Yes:
            return
        self.busy(True)
        self.status.setText('Pobieranie moda…')
        self.worker = ModrinthWorker('install', project=hit['project_id'],
            version=self.version.text().strip(), loader=self.loader.currentText(), mc_dir=self.mc_dir)
        self.worker.done.connect(self.installed)
        self.worker.error.connect(self.failed)
        self.worker.finished.connect(lambda: self.busy(False))
        self.worker.start()
    def installed(self, path):
        self.status.setText('Pobrano: ' + Path(path).name)
        QMessageBox.information(self, 'Modrinth', 'Zapisano plik:\n' + path +
            '\n\nSprawdź wymagane zależności moda przed uruchomieniem gry.')
    def failed(self, message):
        self.status.setText('Błąd: ' + message)
        QMessageBox.warning(self, 'Modrinth', message)
