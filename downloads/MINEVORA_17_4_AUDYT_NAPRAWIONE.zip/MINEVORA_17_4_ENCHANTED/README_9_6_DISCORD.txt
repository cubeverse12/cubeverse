MINEVORA 9.6 — DISCORD HUB
=========================

NOWOŚCI
- Pełna zakładka „Discord” w lewym menu launchera i przycisk na stronie głównej.
- Discord Rich Presence: status „Gra w Minecraft Java” podczas gry lub „Przegląda launcher MINEVORA”.
- Opcja „Pokazuj aktywność tylko podczas grania”.
- Opcjonalne udostępnianie numeru wersji Minecraft (bez IP serwera).
- Panel ze statusem połączenia, testem i ponawianiem połączenia.
- Podgląd informacji wysyłanej do aplikacji Discord.
- Pole z linkiem zaproszenia do serwera Discord społeczności i przyciski otwierania/kopiowania.
- Walidacja identyfikatora aplikacji i adresów zaproszeń.
- Integracja nie odczytuje listy znajomych, wiadomości prywatnych ani hasła Discord.

INSTALACJA
1. Rozpakuj całe archiwum do NOWEGO folderu.
2. Uruchom INSTALUJ_ZALEZNOSCI.bat.
3. Uruchom URUCHOM_MINEVORA.bat.
4. W menu po lewej kliknij „🔗 Discord”.

KONFIGURACJA RICH PRESENCE
1. Uruchom aplikację Discord na komputerze Windows i zaloguj się w niej normalnie.
2. Otwórz https://discord.com/developers/applications
3. Utwórz aplikację, np. „MINEVORA”, i skopiuj jej Application ID z sekcji General Information.
4. W MINEVORA otwórz zakładkę Discord i wklej Application ID (same cyfry).
5. Zaznacz „Włącz Discord Rich Presence”. Opcjonalnie zaznacz „Pokazuj aktywność tylko podczas grania”.
6. Kliknij „Zapisz ustawienia”, a następnie „Połącz / Sprawdź”.
7. W ustawieniach prywatności Discorda sprawdź wyświetlanie aktywności aplikacji.

UWAGI
- Jest to Discord Rich Presence przez oficjalnie uruchomioną aplikację Discord i lokalny IPC, a NIE logowanie do konta Discord w launcherze.
- Nie ma wbudowanego odczytu wiadomości/znajomych czy pełnego klienta Discord.
- Oficjalny link społeczności MINEVORA jest wbudowany w MINEVORA 9.7: https://discord.gg/8teEpYvzRd. Opcjonalny inny link nadal można skonfigurować.
- Połączenie może nie działać, jeżeli Discord jest wyłączony albo pypresence nie jest zainstalowane.
- Wszystkie ustawienia są zapisywane lokalnie w ~/.minevora/preferences.json.
- Zachowano moduły MINEVORA 9.5, w tym Guard Anticheat oraz Fair Play.
- Przeszły testy składni Pythona i funkcji walidacji; interfejs GUI i połączenie IPC należy sprawdzić w Windows.
