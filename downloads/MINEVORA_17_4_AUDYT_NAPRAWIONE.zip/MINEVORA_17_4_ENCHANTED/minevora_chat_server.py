"""MINEVORA Chat Plus 10.3: local demo server with server-authorized moderation.

No user authentication: nickname bans/mutes can be bypassed by choosing a different name.
Deploy publicly ONLY behind HTTPS with real account authentication and reverse proxy controls.
"""
import hmac
from minevora_chat_guard import DEFAULT_RULES, validate_rules, check_text, normalized
import json
import os
import re
import secrets
import sqlite3
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

DB = Path(os.environ.get('MINEVORA_CHAT_DB', str(Path(__file__).with_name('minevora_chat.sqlite3'))))
HOST = os.environ.get('MINEVORA_CHAT_HOST', '127.0.0.1')
PORT = int(os.environ.get('MINEVORA_CHAT_PORT', '8766'))
TOKEN = os.environ.get('MINEVORA_CHAT_ADMIN_TOKEN') or secrets.token_urlsafe(32)
LOCK = threading.RLock()
RECENT = {}
RECENT_REPORT = {}
ACTIVE = {}
BOT_NAME = 'MINEVORA BOT'
BOT_WELCOME = '🛡 Cześć! Jestem MINEVORA Guard Bot. Dbam o porządek na czacie. Pisz /zasady, aby zobaczyć regulamin.'
COUNTRIES = {'Polska','Niemcy','Wielka Brytania','USA','Ukraina','Francja','Hiszpania','Inny'}

def stamp():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def initialize(db=None):
    db=db or DB
    db.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db) as c:
        c.execute('PRAGMA journal_mode=WAL')
        c.execute('CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, country TEXT, body TEXT, stamp TEXT)')
        columns={row[1] for row in c.execute('PRAGMA table_info(messages)')}
        if 'deleted' not in columns:
            c.execute('ALTER TABLE messages ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0')
        if 'sent_at' not in columns:
            c.execute('ALTER TABLE messages ADD COLUMN sent_at INTEGER')
        if 'kind' not in columns:
            c.execute("ALTER TABLE messages ADD COLUMN kind TEXT NOT NULL DEFAULT 'user'")
        c.execute('CREATE INDEX IF NOT EXISTS idx_messages_author_time ON messages(name, sent_at)')
        c.execute('CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY AUTOINCREMENT, message_id INTEGER, reason TEXT, stamp TEXT)')
        columns={row[1] for row in c.execute('PRAGMA table_info(reports)')}
        if 'status' not in columns:
            c.execute("ALTER TABLE reports ADD COLUMN status TEXT NOT NULL DEFAULT 'nowe'")
        c.execute('CREATE TABLE IF NOT EXISTS sanctions(name_key TEXT PRIMARY KEY, display_name TEXT NOT NULL, mute_until INTEGER NOT NULL DEFAULT 0, banned INTEGER NOT NULL DEFAULT 0)')
        c.execute('CREATE TABLE IF NOT EXISTS mod_audit(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, target TEXT NOT NULL, stamp TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS bot_settings(id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL)')
        c.execute('INSERT OR IGNORE INTO bot_settings(id,data) VALUES(1,?)', (json.dumps(DEFAULT_RULES, ensure_ascii=False),))
        c.execute('CREATE TABLE IF NOT EXISTS bot_events(id INTEGER PRIMARY KEY AUTOINCREMENT, name_key TEXT NOT NULL, display_name TEXT NOT NULL, reason TEXT NOT NULL, rule TEXT NOT NULL, action TEXT NOT NULL, preview TEXT, created_at INTEGER NOT NULL)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_bot_events_user_time ON bot_events(name_key,created_at)')
        # A system message has a distinct kind and cannot be impersonated by a user.
        if not c.execute("SELECT 1 FROM messages WHERE kind='bot' LIMIT 1").fetchone():
            c.execute('INSERT INTO messages(name,country,body,stamp,sent_at,kind) VALUES(?,?,?,?,?,?)', (BOT_NAME,'Inny',BOT_WELCOME,datetime.now().strftime('%H:%M'),int(time.time()),'bot'))

def validate_message(data):
    name = str(data.get('name','')).strip()
    country = str(data.get('country','')).strip()
    body = str(data.get('body','')).strip()
    if not re.fullmatch(r'[^<>&\r\n]{1,24}', name) or not body or len(body)>300 or any(ord(c)<32 and c!='\t' for c in body):
        raise ValueError('Nieprawidłowy nick lub treść wiadomości')
    if name.casefold()==BOT_NAME.casefold():
        raise ValueError('Nazwa zarezerwowana dla bota MINEVORA')
    if country not in COUNTRIES:
        raise ValueError('Nieprawidłowy kraj')
    return name,country,body

def get_bot_rules(c):
    row=c.execute('SELECT data FROM bot_settings WHERE id=1').fetchone()
    return validate_rules(json.loads(row[0]) if row else {})


def record_bot_event(c, key, name, rule, reason, body, now, rules):
    window=now-rules['warning_window_minutes']*60
    strikes=c.execute('SELECT COUNT(*) FROM bot_events WHERE name_key=? AND created_at>=?',(key,window)).fetchone()[0]+1
    if strikes>=rules['mute_after']:
        duration=rules['mute_minutes']*(6 if strikes>=rules['mute_after']+2 else 1)
        duration=min(duration,1440)
        c.execute('INSERT OR IGNORE INTO sanctions(name_key,display_name) VALUES(?,?)',(key,name))
        c.execute('UPDATE sanctions SET mute_until=MAX(mute_until,?),display_name=? WHERE name_key=?',(now+duration*60,name,key))
        action=f'auto_mute_{duration}m'
        feedback=f'🛡 MINEVORA Guard Bot: {reason}. Automatyczne wyciszenie na {duration} minut. Moderator może cofnąć karę.'
    else:
        action='warning'
        feedback=f'🛡 MINEVORA Guard Bot: {reason}. Ostrzeżenie {strikes}/{rules["mute_after"]}. Wiadomość nie została opublikowana.'
    c.execute('INSERT INTO bot_events(name_key,display_name,reason,rule,action,preview,created_at) VALUES(?,?,?,?,?,?,?)',
              (key,name,reason,rule,action,body[:120],now))
    c.execute('DELETE FROM bot_events WHERE created_at<?',(now-30*86400,))
    return {'error':feedback,'rule':rule,'strikes':strikes,'action':action}


def canonical_name(name):
    name = str(name).strip()
    if not re.fullmatch(r'[^<>&\r\n]{1,24}',name):
        raise ValueError('Podaj prawidłowy nick')
    return name.casefold(),name

def is_admin(header):
    value=header or ''
    return value.startswith('Bearer ') and hmac.compare_digest(value[7:].encode(),TOKEN.encode())

class Handler(BaseHTTPRequestHandler):
    server_version='MINEVORAChat/10.3'
    def _reply(self,code,payload):
        raw=json.dumps(payload,ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.end_headers()
        try:self.wfile.write(raw)
        except (BrokenPipeError,ConnectionResetError):pass
    def _authorized(self):
        if not is_admin(self.headers.get('Authorization')):
            self._reply(403,{'error':'Brak uprawnień moderatora — sprawdź token serwera'})
            return False
        return True
    def do_GET(self):
        path=urlsplit(self.path).path
        if path=='/health':
            return self._reply(200,{'ok':True,'version':'10.3','auth':'moderation-token','bot':True})
        if path=='/messages':
            with LOCK,sqlite3.connect(DB) as c:
                rows=c.execute('SELECT id,name,country,body,stamp,kind FROM messages WHERE deleted=0 ORDER BY id DESC LIMIT 80').fetchall()
                total=c.execute('SELECT COUNT(*) FROM messages WHERE deleted=0').fetchone()[0]
                online=sum(time.time()-v<120 for v in ACTIVE.values())
                bot_enabled=get_bot_rules(c)['enabled']
            return self._reply(200,{'messages':[dict(zip(('id','name','country','body','time','kind'),r)) for r in reversed(rows)],'total':total,'online':online,'bot_enabled':bot_enabled})
        if path=='/admin/status':
            if not self._authorized():return
            return self._reply(200,{'ok':True,'role':'admin'})
        if path=='/admin/bot':
            if not self._authorized():return
            with LOCK,sqlite3.connect(DB) as c:
                rules=get_bot_rules(c)
                rows=c.execute('SELECT id,display_name,reason,rule,action,preview,created_at FROM bot_events ORDER BY id DESC LIMIT 80').fetchall()
            return self._reply(200,{'rules':rules,'events':[dict(zip(('id','name','reason','rule','action','preview','timestamp'),r)) for r in rows]})
        if path=='/admin/reports':
            if not self._authorized():return
            with LOCK,sqlite3.connect(DB) as c:
                rows=c.execute('SELECT r.id,r.message_id,r.reason,r.stamp,r.status,COALESCE(m.name,\'\'),COALESCE(m.body,\'\') FROM reports r LEFT JOIN messages m ON m.id=r.message_id ORDER BY r.id DESC LIMIT 100').fetchall()
            return self._reply(200,{'reports':[dict(zip(('id','message_id','reason','time','status','name','body'),r)) for r in rows]})
        return self._reply(404,{'error':'Nieznana ścieżka'})
    def do_POST(self):
        path=urlsplit(self.path).path
        if path not in {'/send','/report','/admin/delete','/admin/mute','/admin/unmute','/admin/ban','/admin/unban','/admin/resolve','/admin/bot/settings','/admin/bot/clear'}:
            return self._reply(404,{'error':'Nieznana ścieżka'})
        if path.startswith('/admin/') and not self._authorized():return
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size<2 or size>4096:raise ValueError('Zbyt duże dane')
            data=json.loads(self.rfile.read(size))
            if not isinstance(data,dict):raise ValueError('Nieprawidłowe dane')
            if path=='/send':
                name,country,body=validate_message(data)
                key=name.casefold();now=time.time()
                with LOCK,sqlite3.connect(DB) as c:
                    sanction=c.execute('SELECT mute_until,banned FROM sanctions WHERE name_key=?',(key,)).fetchone()
                    if sanction and sanction[1]:return self._reply(403,{'error':'Ten nick został zablokowany na czacie'})
                    if sanction and sanction[0]>now:return self._reply(403,{'error':'Nick jest wyciszony — spróbuj później'})
                    address=self.client_address[0]
                    if now-RECENT.get(address,0)<2:return self._reply(429,{'error':'Odczekaj 2 sekundy przed kolejną wiadomością'})
                    RECENT[address]=now
                    rules=get_bot_rules(c)
                    if body.casefold() in ('/zasady','/pomoc','/bot'):
                        c.execute('INSERT INTO messages(name,country,body,stamp,sent_at,kind) VALUES(?,?,?,?,?,?)',
                                  (BOT_NAME,'Inny','🛡 Zasady czatu: bez spamu, nękania, nadmiaru linków i floodu. Decyzje bota możesz zgłosić moderatorowi.',datetime.now().strftime('%H:%M'),int(now),'bot'))
                        return self._reply(200,{'ok':True,'bot_reply':True})
                    detected=check_text(body,rules)
                    if not detected and rules['enabled']:
                        # Use accepted messages from this author only; old messages without sent_at do not count.
                        history=c.execute("SELECT body,sent_at FROM messages WHERE name=? COLLATE NOCASE AND kind='user' AND sent_at>=? ORDER BY id DESC LIMIT 30",
                                          (name,int(now-max(rules['flood_seconds'],rules['repeat_seconds'])))).fetchall()
                        flood_history=[(text,ts) for text,ts in history if ts >= now-rules['flood_seconds']]
                        repeat_history=[(text,ts) for text,ts in history if ts >= now-rules['repeat_seconds']]
                        if len(flood_history)>=rules['max_messages']-1:detected=('flood','Zbyt dużo wiadomości w krótkim czasie')
                        elif sum(1 for text,_ in repeat_history if normalized(text)==normalized(body)) >= rules['max_repeats']:
                            detected=('repeat','Powtarzanie tej samej wiadomości')
                    if detected:
                        rule,reason=detected
                        result=record_bot_event(c,key,name,rule,reason,body,int(now),rules)
                        return self._reply(429,result)
                    ACTIVE[key]=now
                    c.execute('INSERT INTO messages(name,country,body,stamp,sent_at,kind) VALUES(?,?,?,?,?,?)',(name,country,body,datetime.now().strftime('%H:%M'),int(now),'user'))
                return self._reply(200,{'ok':True})
            if path=='/report':
                mid=int(data.get('message_id',0));reason=str(data.get('reason','Inne')).strip()[:120]
                if mid<1 or not reason:raise ValueError('Nieprawidłowe zgłoszenie')
                with LOCK,sqlite3.connect(DB) as c:
                    address=self.client_address[0]
                    now=time.time()
                    if now-RECENT_REPORT.get(address,0)<10:return self._reply(429,{'error':'Odczekaj 10 sekund przed następnym zgłoszeniem'})
                    if not c.execute('SELECT 1 FROM messages WHERE id=?',(mid,)).fetchone():return self._reply(404,{'error':'Nie znaleziono wiadomości'})
                    c.execute('INSERT INTO reports(message_id,reason,stamp) VALUES(?,?,?)',(mid,reason,stamp()))
                    RECENT_REPORT[address]=now
                return self._reply(200,{'ok':True})
            with LOCK,sqlite3.connect(DB) as c:
                if path=='/admin/bot/settings':
                    rules=validate_rules(data)
                    c.execute('UPDATE bot_settings SET data=? WHERE id=1',(json.dumps(rules,ensure_ascii=False),))
                    c.execute('INSERT INTO mod_audit(action,target,stamp) VALUES(?,?,?)',('bot_settings','bot',stamp()))
                    return self._reply(200,{'ok':True,'rules':rules})
                if path=='/admin/bot/clear':
                    key,target=canonical_name(data.get('name',''))
                    c.execute('DELETE FROM bot_events WHERE name_key=?',(key,))
                    c.execute('INSERT INTO mod_audit(action,target,stamp) VALUES(?,?,?)',('bot_clear',target,stamp()))
                    return self._reply(200,{'ok':True})
                if path=='/admin/delete':
                    mid=int(data.get('message_id',0))
                    updated=c.execute('UPDATE messages SET deleted=1 WHERE id=? AND deleted=0',(mid,)).rowcount
                    if not updated:return self._reply(404,{'error':'Wiadomości nie znaleziono'})
                    target=str(mid)
                elif path=='/admin/resolve':
                    report_id=int(data.get('report_id',0))
                    updated=c.execute("UPDATE reports SET status='rozpatrzone' WHERE id=?",(report_id,)).rowcount
                    if not updated:return self._reply(404,{'error':'Nie znaleziono zgłoszenia'})
                    target=str(report_id)
                else:
                    key,target=canonical_name(data.get('name',''))
                    c.execute('INSERT OR IGNORE INTO sanctions(name_key,display_name) VALUES(?,?)',(key,target))
                    if path=='/admin/mute':
                        minutes=int(data.get('minutes',10))
                        if minutes not in (10,60,1440):raise ValueError('Wyciszenie: 10, 60 lub 1440 minut')
                        c.execute('UPDATE sanctions SET mute_until=?,display_name=? WHERE name_key=?',(int(time.time())+minutes*60,target,key))
                    elif path=='/admin/unmute':c.execute('UPDATE sanctions SET mute_until=0 WHERE name_key=?',(key,))
                    elif path=='/admin/ban':c.execute('UPDATE sanctions SET banned=1,display_name=? WHERE name_key=?',(target,key))
                    elif path=='/admin/unban':c.execute('UPDATE sanctions SET banned=0 WHERE name_key=?',(key,))
                c.execute('INSERT INTO mod_audit(action,target,stamp) VALUES(?,?,?)',(path.split('/')[-1],target,stamp()))
            return self._reply(200,{'ok':True})
        except (TypeError,ValueError,OverflowError) as exc:
            return self._reply(400,{'error':str(exc)[:160]})
        except sqlite3.DatabaseError:
            return self._reply(500,{'error':'Błąd bazy danych'})

if __name__=='__main__':
    initialize()
    print('MINEVORA CHAT PLUS • lokalny czat 10.3 • Guard Bot')
    print(f'Adres: http://{HOST}:{PORT}')
    if HOST not in ('127.0.0.1','localhost','::1'):
        raise SystemExit('Odmowa nasłuchiwania na publicznym adresie: najpierw potrzebny jest backend z HTTPS i uwierzytelnianiem.')
    if not os.environ.get('MINEVORA_CHAT_ADMIN_TOKEN'):
        print('TOKEN MODERATORA NA TĘ SESJĘ (NIE UDOSTĘPNIAJ): '+TOKEN)
    else:print('Token moderatora wczytany z MINEVORA_CHAT_ADMIN_TOKEN')
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
