@echo off
cd /d "%~dp0"
py -3 minevora_chat_server.py
pause
