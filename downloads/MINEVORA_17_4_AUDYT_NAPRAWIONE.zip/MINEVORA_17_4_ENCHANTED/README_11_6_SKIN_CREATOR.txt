MINEVORA 11.6 — SKIN CREATOR EDITION

Nowe funkcje:
- malowanie piksel po pikselu na UV skina Minecraft Java Edition 64x64
- pędzel, gumka, pipeta, wiaderko, cofanie / ponawianie zmian
- wybieranie koloru i paleta MINEVORA
- filtr edycji warstw: baza, nakładki, kapelusz, kurtka, rękawy, nogawki
- przełączanie widoczności nakładek na podglądzie 3D
- generowanie oryginalnych presetów: Cyber Wilk, Strażnik Lasu, Portalowy Mag
- własny kolor akcentu, zapisywanie presetów na dysk, ponowne wczytywanie
- import PNG (64x64 / starsze 64x32), eksport bez kompresji stratnej
- automatyczna kopia źródła nie jest nadpisywana bez wyraźnego eksportu

Instrukcja:
1) Uruchom URUCHOM_MINEVORA.bat
2) Otwórz „Skiny / Skin Studio”
3) Wczytaj skin lub wygeneruj własny preset
4) Edytuj piksele pędzlem, wybierz warstwę i zapisz plik PNG

Uwaga: edytor zapisuje plik skinu do PNG. Nie zmienia skina na koncie Minecraft
bezpośrednio i nie zastępuje plików w sieci. Poprzednie funkcje launchera
pozostały w paczce, ale trzeba je sprawdzić również na Windows 11.

AKTUALIZACJA 11.7: Możesz także przypisać skin do konta Minecraft Java. Zobacz README_11_7_SKIN_W_MINECRAFT.txt.
