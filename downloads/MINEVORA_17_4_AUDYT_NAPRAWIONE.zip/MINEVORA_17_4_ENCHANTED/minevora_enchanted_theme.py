"""MINEVORA Enchanted: one reusable theme for every functional Qt page.

No buttons are painted into screenshots on secondary pages. All pages use
real Qt controls and retain their original callbacks.
"""
from pathlib import Path
from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QPainter, QColor, QLinearGradient, QPainterPath, QPen, QPixmap, QBrush
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel

ROOT = Path(__file__).resolve().parent

ENCHANTED_QSS = r"""
QMainWindow,QWidget,QDialog,QScrollArea {background:#091226;color:#f5eeff;font-family:'Segoe UI';font-size:13px}
QFrame#sidebar {background:#0b1730;border-right:1px solid #5843ad}
QFrame#topbar {background:#0b1630;border-bottom:1px solid #6042b2}
QFrame#chatSidebar {background:#0b1731;border-left:1px solid #8650e5}
QFrame#footer {background:#0b1934;border-top:2px solid #9a54ee}
QFrame#panel,QFrame#card,QFrame#stats {background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #111d3b,stop:1 #161a39);border:1px solid #564091;border-radius:16px}
QFrame#panel:hover,QFrame#card:hover {border:1px solid #bd80ff;background:#192246}
QFrame#hero {background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #211047,stop:.65 #17163b,stop:1 #101b3b);border:2px solid #a75aff;border-radius:19px}
QLabel {background:transparent;color:#f7f3ff}
QLabel#eyebrow {color:#d6a7ff;font-size:11px;font-weight:800}
QLabel#pageTitle {font-size:26px;font-weight:850;color:#fff}
QPushButton {background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #182f57,stop:1 #16213f);border:1px solid #405c9e;border-radius:11px;padding:10px 15px;color:#f9f6ff;font-weight:700}
QPushButton:hover {background:#372069;border:1px solid #c58aff;color:white}
QPushButton:pressed {background:#5626a7;border:1px solid #e2c2ff}
QPushButton:focus {border:2px solid #d9a2ff}
QPushButton:disabled {background:#182139;color:#8896b3;border-color:#304166}
QPushButton#primary,QPushButton#discordJoin {background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #7831ed,stop:.48 #a448f1,stop:1 #6e35df);border:1px solid #d6a1ff;color:white;font-size:14px;font-weight:800;padding:12px 18px}
QPushButton#primary:hover,QPushButton#discordJoin:hover {background:#a152ff;border:1px solid #f2d6ff}
QPushButton#nav {background:transparent;border:0;border-left:4px solid transparent;text-align:left;padding:12px 13px;color:#bac6e9;border-radius:9px;font-size:13px}
QPushButton#nav:hover {background:#231846;color:#fff;border-left-color:#7550ba}
QPushButton#nav[active="true"] {background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #6732b2,stop:1 #432584);border-left:4px solid #e3c4ff;color:white}
QPushButton#nav[clicked="true"] {background:#513392;border-left:4px solid #f2caff}
QLineEdit,QTextEdit,QListWidget,QComboBox,QSpinBox {background:#101d3a;border:1px solid #405e9e;border-radius:10px;color:#f6f1ff;padding:9px;selection-background-color:#8544dd}
QLineEdit:focus,QTextEdit:focus,QComboBox:focus,QSpinBox:focus {border:1px solid #c58bff}
QLineEdit:disabled,QComboBox:disabled {color:#8997b3;border-color:#2c3e62}
QComboBox::drop-down {border:0;width:20px}
QComboBox QAbstractItemView {background:#132040;color:#f6efff;selection-background-color:#6633b2;border:1px solid #b277f9}
QCheckBox {background:transparent;color:#e9deff;spacing:8px}
QCheckBox::indicator {width:16px;height:16px;border:1px solid #8664ce;background:#111e3a;border-radius:4px}
QCheckBox::indicator:checked {background:#8543ee;border:1px solid #d9b6ff}
QTabWidget::pane {border:1px solid #7653ae;border-radius:12px;background:#0d1933}
QTabBar::tab {background:#142347;color:#d4c5f8;padding:9px 16px;margin:2px;border-radius:8px}
QTabBar::tab:selected {background:#703ac6;color:#fff;border:1px solid #d4a1fc}
QProgressBar {background:#0f1a34;color:white;border:1px solid #6846ac;border-radius:8px;text-align:center}
QProgressBar::chunk {background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #703cf4,stop:1 #c270f3);border-radius:7px}
QScrollArea,QScrollArea>QWidget>QWidget {border:0}
QScrollBar:vertical {background:#0d1832;width:10px}
QScrollBar::handle:vertical {background:#6c43b7;border-radius:5px;min-height:22px}
QScrollBar::handle:vertical:hover {background:#a578ed}
QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical {height:0}
QScrollBar:horizontal {background:#0d1832;height:9px}
QScrollBar::handle:horizontal {background:#6640a8;border-radius:4px}
QToolTip {background:#1a2446;color:#fff;border:1px solid #ac76e8;padding:6px}
QMenu {background:#111b37;border:1px solid #8855d4;color:#f7f1ff}
QMenu::item:selected {background:#6a36bf}
QDialogButtonBox {background:transparent}

/* App-wide coherent styling across each functional module and popup */
QDialog,QMessageBox {background:#09152d;color:#f4ecff}
QFrame#featureCard {background:#111a38;border:1px solid #8051c8;border-radius:15px}
QFrame#featureCard:hover {border:2px solid #c88aff}
QPushButton#enchantedOutline {background:rgba(28,28,71,200);border:1px solid #a86cff;border-radius:9px;color:#f7eaff;font-size:12px;padding:7px 12px}
QPushButton#enchantedOutline:hover {background:#7831cd;border-color:#dbb1ff}
QTableView,QTableWidget,QTreeView,QTreeWidget {background:#101c39;alternate-background-color:#172143;gridline-color:#573e92;color:#f9f4ff;border:1px solid #6742a7;border-radius:9px;selection-background-color:#6935b7}
QHeaderView::section {background:#211a4b;color:#f3e4ff;border:0;border-right:1px solid #533f85;padding:8px;font-weight:700}
QTableCornerButton::section {background:#211a4b}
QListView::item:selected,QTreeView::item:selected {background:#6b3cb7}
QGroupBox {background:#111b38;border:1px solid #6145a4;border-radius:12px;margin-top:12px;padding:12px;color:#f8efff;font-weight:700}
QGroupBox::title {subcontrol-origin:margin;subcontrol-position:top left;left:14px;padding:0 5px}
QRadioButton {color:#f0e7ff;spacing:8px}
QRadioButton::indicator {width:15px;height:15px}
QSplitter::handle {background:#603b97}
QStatusBar {background:#101831;color:#cfb9ed;border-top:1px solid #8451c6}
QSlider::groove:horizontal {height:6px;background:#29375f;border-radius:3px}
QSlider::handle:horizontal {background:#a762ff;border:1px solid #ddafff;width:16px;margin:-6px 0;border-radius:8px}
QDialog QTabWidget::pane {background:#111a34;border:1px solid #6541a6}
QCheckBox:focus,QRadioButton:focus {border:1px dotted #bd7aff}
"""

class EnchantedSectionBanner(QWidget):
    """Shared cinematic hero on secondary pages (not a noninteractive screenshot)."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('enchantedSectionBanner')
        self.setMinimumHeight(130)
        self.setMaximumHeight(162)
        self.backdrop = QPixmap(str(ROOT/'assets'/'enchanted_hero.jpg'))
        box=QVBoxLayout(self)
        self.banner_layout=box
        box.setContentsMargins(26,13,160,11)
        box.setSpacing(3)
        self.eyebrow=QLabel('✦  THE ENCHANTED LAUNCHER')
        self.eyebrow.setStyleSheet('color:#dfa9ff;font-size:11px;font-weight:800;background:transparent')
        self.heading=QLabel('MINEVORA')
        self.heading.setStyleSheet('color:#fff;font-size:25px;font-weight:900;background:transparent')
        self.heading.setWordWrap(True)
        self.subtitle=QLabel('Odkrywaj magiczny świat Minecraft.')
        self.subtitle.setStyleSheet('color:#e5ddfb;font-size:12px;background:transparent')
        self.subtitle.setWordWrap(True)
        box.addWidget(self.eyebrow)
        box.addWidget(self.heading)
        box.addWidget(self.subtitle)

    def set_section(self, title, description):
        self.heading.setText(str(title))
        self.subtitle.setText(str(description))
        key=('versions' if 'WERSJE' in title or 'INSTANCJ' in title else
             'skins_highres' if 'EDYTOR SKIN' in title else
             'mods_highres' if 'MODY' in title else
             'marketplace' if 'MARKETPLACE' in title or 'SKLEP' in title else
             'minigames' if 'MINIGRY' in title else
             'pvp' if 'PVP' in title or 'FAIR PLAY' in title else
             'ranking' if 'RANKING' in title or 'STATYSTYK' in title else
             'discord' if 'DISCORD' in title else
             'together' if 'TOGETHER' in title else
             'settings')
        image=QPixmap(str(ROOT/'assets'/('en_'+key+'.jpg')))
        if not image.isNull():self.backdrop=image
        self.update()

    def resizeEvent(self,event):
        super().resizeEvent(event)
        right_margin=max(45,min(220,int(self.width()*.24)))
        self.banner_layout.setContentsMargins(26,13,right_margin,11)

    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing,True)
        rect=self.rect().adjusted(1,1,-2,-2)
        path=QPainterPath();path.addRoundedRect(QRectF(rect),16,16)
        p.setClipPath(path)
        p.fillPath(path,QColor('#151133'))
        if not self.backdrop.isNull():
            # Centre-crop / cover: never distort or stretch cinematic artwork.
            p.setRenderHint(QPainter.SmoothPixmapTransform,True)
            iw,ih=self.backdrop.width(),self.backdrop.height()
            tw,th=rect.width(),rect.height()
            crop_w,crop_h=iw,ih
            if tw/th > iw/ih:crop_h=iw*th/tw
            else:crop_w=ih*tw/th
            source=QRectF((iw-crop_w)/2,(ih-crop_h)/2,crop_w,crop_h)
            p.drawPixmap(QRectF(rect),self.backdrop,source)
        veil=QLinearGradient(rect.left(),rect.top(),rect.right(),rect.top())
        veil.setColorAt(0,QColor(13,13,40,247))
        veil.setColorAt(.48,QColor(18,14,46,210))
        veil.setColorAt(.8,QColor(15,15,48,70))
        veil.setColorAt(1,QColor(19,14,51,90))
        p.fillPath(path,QBrush(veil))
        p.setClipping(False)
        p.setPen(QPen(QColor('#ae69ff'),2))
        p.drawRoundedRect(rect,16,16)
        p.end()
