"""Safe, offline MINEVORA Guard configuration presets.

Only generates a server-admin-reviewed YAML file; never pushes remote configs,
collects player network identifiers or automatically sanctions players.
"""
PRESETS = {
    'safe': {
        'title': 'Ostrożny (polecany) — mniej fałszywych alertów',
        'speed': 1.10, 'hover': 0.055, 'reach': 5.10, 'clicks': 32, 'fastplace': 24,
        'cooldown': 45,
    },
    'normal': {
        'title': 'Standardowy — więcej zdarzeń do analizy',
        'speed': 0.90, 'hover': 0.065, 'reach': 4.85, 'clicks': 27, 'fastplace': 18,
        'cooldown': 30,
    },
}


def render_preset(name='safe', server_name='MINEVORA-Official'):
    if name not in PRESETS:
        raise ValueError('Nieznany profil antycheat.')
    settings = PRESETS[name]
    if not isinstance(server_name, str) or not server_name or len(server_name) > 50 or not all(
        c.isalnum() or c in '-_' for c in server_name):
        raise ValueError('Nazwa serwera: użyj 1–50 znaków A-Z, cyfr, - lub _.')
    return f'''# MINEVORA Guard 1.0 — {settings['title']}
# Powiadomienia dla moderatora, brak automatycznych banów.
# Wysoki ping lub niestandardowy tryb PvP może wymagać dodatkowych testów.
server-name: '{server_name}'
checks:
  speed:
    enabled: true
    max-blocks-per-tick: {settings['speed']:.2f}
  hover:
    enabled: true
    max-y-change: {settings['hover']:.3f}
  reach:
    enabled: true
    max-distance: {settings['reach']:.2f}
  clicks:
    enabled: true
    swings-per-second: {settings['clicks']}
  fastplace:
    enabled: true
    blocks-per-second: {settings['fastplace']}
alerts:
  console: true
  staff-chat: true
  cooldown-seconds: {settings['cooldown']}
evidence:
  retention-days: 30
'''
