MINEVORA 10.4 — Discord Announcement Bot
========================================

1. Uruchom URUCHOM_MINEVORA.bat i otwórz zakładkę Discord.
2. W Discordzie otwórz swój serwer → Ustawienia serwera → Integracje → Webhooki.
   Wymagane uprawnienia do zarządzania webhookami.
3. Utwórz webhook w kanale #aktualizacje i skopiuj jego adres URL.
   Uwaga: adres webhooka to TAJNY link, inny niż zwykłe zaproszenie discord.gg.
4. Wklej adres do pola „Webhook Discord”, uzupełnij numer wersji, listę zmian
   i ewentualnie publiczny link HTTPS do pobrania.
5. Kliknij „Podgląd”, następnie „Opublikuj na Discordzie” i potwierdź.

Adres webhooka nie jest zapisywany przez MINEVORA na dysku.
Historia lokalna zapisuje tylko tytuł, datę, odcisk treści i ID wiadomości.
Wiadomości nie oznaczają @everyone ani żadnych użytkowników.

AUTOMATYCZNE OGŁOSZENIA Z GITHUB RELEASES
----------------------------------------
Jeżeli masz repozytorium GitHub z kodem projektu:
1. Umieść minevora_discord_release_ci.py, minevora_discord_announcements_core.py
   i folder .github/workflows/ w głównym katalogu repozytorium.
2. W GitHub → Settings → Secrets and variables → Actions dodaj tajny sekret
   MINEVORA_DISCORD_WEBHOOK (wartość: skopiowany URL webhooka).
3. Utwórz i OPUBLIKUJ GitHub Release z nowym tagiem wersji, opisem zmian
   i opcjonalnym załącznikiem ZIP.
4. GitHub Actions automatycznie opublikuje ogłoszenie o wydaniu.
   Wersje prerelease i szkice są pomijane.

Webhook jest tajny: nie przesyłaj go w rozmowach, nie publikuj w repozytorium
ani na stronie WWW. Jeżeli wycieknie, usuń i utwórz nowy webhook.

UWAGA: To jest wysyłający webhook Discord, a nie pełny bot czytający wiadomości.
Integracja ręczna wymaga potwierdzenia przed wysłaniem.
Wysyłanie sieciowe wymaga testu z prawdziwym Discordem i dostępem do internetu.
