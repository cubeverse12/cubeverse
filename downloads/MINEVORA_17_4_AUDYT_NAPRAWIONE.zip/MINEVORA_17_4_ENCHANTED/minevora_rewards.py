"""Offline creator progression for MINEVORA's local demonstration marketplace.

No online account validation or real-money rewards. All MVC values are demo credits.
Persist the resulting marketplace state with the launcher's existing atomic writer.
"""
from datetime import datetime, timezone, timedelta

XP_BY_CATEGORY = {'Mapy': 120, 'Budowle': 80, 'Pluginy': 15,
                  'Mody': 15, 'Modpacki': 15, 'Tekstury': 15, 'Schematy': 15,
                  'Rigi Minecraft': 25, 'Modele Blender': 20, 'Modele Blockbench': 20}
DAILY_MVC = 50
WEEKLY_MVC = 100
BOOST_DURATION_SECONDS = 30 * 60
RANKS = (
    {'min_level': 1, 'name': 'Odkrywca', 'icon': 'odkrywca.png', 'color': '#98b6dd'},
    {'min_level': 3, 'name': 'Budowniczy', 'icon': 'budowniczy.png', 'color': '#6dd4c1'},
    {'min_level': 6, 'name': 'Architekt', 'icon': 'architekt.png', 'color': '#a992ff'},
    {'min_level': 10, 'name': 'Mistrz', 'icon': 'mistrz.png', 'color': '#f2bc71'},
    {'min_level': 15, 'name': 'Legenda', 'icon': 'legenda.png', 'color': '#ff829c'},
    {'min_level': 21, 'name': 'Arcymistrz', 'icon': 'arcymistrz.png', 'color': '#a5ecff'},
)


def level_floor(level):
    """Total accumulated experience required to reach a given level."""
    level = max(1, int(level))
    return 50 * (level - 1) * level


def level_of(xp):
    xp = max(0, int(xp))
    # Small bounded loop, avoids floating-point precision / rounding issues.
    lo, hi = 1, 2
    while level_floor(hi) <= xp:
        hi *= 2
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if level_floor(mid) <= xp: lo = mid
        else: hi = mid
    return lo


def rank_of(level):
    return next(r for r in reversed(RANKS) if level >= r['min_level'])


def new_progress():
    return {'xp': 0, 'project_keys': [], 'claimed_levels': [], 'daily_claim': '',
            'project_counts': {'Mapy': 0, 'Budowle': 0, 'Inne': 0},
            'weekly_claim': '', 'boost_inventory': 0, 'boost_until': 0}


def ensure(state):
    """Normalize a progress record inside an existing market state."""
    if not isinstance(state.get('creator_progress'), dict):
        state['creator_progress'] = new_progress()
    p = state['creator_progress']
    for name, default in new_progress().items():
        if name not in p or not isinstance(p[name], type(default)):
            p[name] = default.copy() if isinstance(default, (list, dict)) else default
    p['xp'] = max(0, p['xp']) if type(p['xp']) is int else 0
    p['project_keys'] = [str(v) for v in p['project_keys'] if isinstance(v, str)][:100000]
    p['claimed_levels'] = [x for x in p['claimed_levels'] if type(x) is int and x >= 2]
    p['daily_claim'] = str(p['daily_claim'])[:10]
    p['weekly_claim'] = str(p['weekly_claim'])[:10]
    for field in ('boost_inventory', 'boost_until'):
        if type(p[field]) is not int or p[field] < 0: p[field] = 0
    p['boost_inventory'] = min(12, p['boost_inventory'])
    for category in ('Mapy', 'Budowle', 'Inne'):
        value = p['project_counts'].get(category, 0)
        p['project_counts'][category] = value if type(value) is int and value >= 0 else 0
    return p


def _project_key(listing):
    """A local duplicate check which survives delete/re-add and app restarts.

    It is not fraud prevention: there is no verified publisher backend.
    """
    category = str(listing.get('category', '')).strip().casefold()
    author = str(listing.get('author', '')).strip().casefold()
    title = ' '.join(str(listing.get('title', '')).strip().casefold().split())
    return '|'.join((category, author, title))


def award_project(state, listing, now=None, allow_boost=True):
    """Grant creator XP once per unique locally listed project.

    Returns XP awarded (0 if duplicate, sample listing, or invalid).
    """
    if not isinstance(listing, dict) or not listing.get('local_owner'): return 0
    category = str(listing.get('category', ''))
    if category not in XP_BY_CATEGORY: return 0
    key = _project_key(listing)
    if not all(key.split('|')): return 0
    p = ensure(state)
    if key in p['project_keys']: return 0
    xp = XP_BY_CATEGORY[category] * (2 if allow_boost and boost_remaining(state, now) > 0 else 1)
    p['project_keys'].append(key)
    p['xp'] += xp
    k = category if category in ('Mapy', 'Budowle') else 'Inne'
    p['project_counts'][k] += 1
    return xp


def migrate_projects(state):
    """Credit legacy local projects once when upgrading old marketplace data."""
    gained = 0
    for listing in state.get('listings', []):
        gained += award_project(state, listing, allow_boost=False)
    return gained


def day_utc(now=None):
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None: raise ValueError('datetime must be timezone-aware')
    return now.astimezone(timezone.utc).date().isoformat()


def can_claim_daily(state, now=None):
    return ensure(state)['daily_claim'] != day_utc(now)


def claim_daily(state, now=None):
    """Returns demo MVC added to balance (0 when already claimed today)."""
    p = ensure(state)
    if not can_claim_daily(state, now): return 0
    state['balance'] += DAILY_MVC
    p['daily_claim'] = day_utc(now)
    return DAILY_MVC


def pending_level_rewards(state):
    p = ensure(state)
    claimed = set(p['claimed_levels'])
    return [(level, 40 + level * 20) for level in range(2, level_of(p['xp']) + 1) if level not in claimed]


def claim_levels(state):
    """Credit all unclaimed level milestones once; return (MVC, levels)."""
    rewards = pending_level_rewards(state)
    if not rewards: return 0, []
    p = ensure(state)
    coins = sum(value for _, value in rewards)
    p['claimed_levels'].extend(level for level, _ in rewards)
    state['balance'] += coins
    return coins, [level for level, _ in rewards]


def _utc_now(now=None):
    result = now or datetime.now(timezone.utc)
    if result.tzinfo is None: raise ValueError('datetime must be timezone-aware')
    return result.astimezone(timezone.utc)


def week_utc(now=None):
    """Stable ISO week key e.g. 2026-W43, safe across year boundaries."""
    stamp = _utc_now(now).isocalendar()
    return f'{stamp.year}-W{stamp.week:02d}'


def can_claim_weekly(state, now=None):
    return ensure(state)['weekly_claim'] != week_utc(now)


def claim_weekly(state, now=None):
    """Once per UTC ISO week: 100 demo MVC and one 30-minute 2x XP voucher."""
    p = ensure(state)
    if not can_claim_weekly(state, now): return 0
    if type(state.get('balance')) is not int: raise ValueError('Invalid MVC balance')
    p['weekly_claim'] = week_utc(now)
    state['balance'] += WEEKLY_MVC
    p['boost_inventory'] = min(12, p['boost_inventory'] + 1)
    return WEEKLY_MVC


def boost_remaining(state, now=None):
    return max(0, ensure(state)['boost_until'] - int(_utc_now(now).timestamp()))


def activate_boost(state, now=None):
    """Consumes one voucher. Cannot stack boosts; returns bool."""
    p = ensure(state)
    if p['boost_inventory'] < 1 or boost_remaining(state, now) > 0: return False
    p['boost_inventory'] -= 1
    p['boost_until'] = int(_utc_now(now).timestamp()) + BOOST_DURATION_SECONDS
    return True
