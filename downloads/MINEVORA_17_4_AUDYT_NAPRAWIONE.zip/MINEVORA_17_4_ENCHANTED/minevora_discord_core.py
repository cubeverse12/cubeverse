"""Discord Rich Presence preferences and safe, local-only payload construction.

No account token, private messages, friend list or IP addresses are used.
"""
from urllib.parse import urlsplit
import re

# Oficjalne zaproszenie podane przez właściciela projektu MINEVORA.
OFFICIAL_MINEVORA_DISCORD_INVITE = "https://discord.gg/8teEpYvzRd"


def valid_application_id(value):
    value = str(value or '').strip()
    return value.isascii() and value.isdecimal() and 15 <= len(value) <= 22


def normalize_invite(value):
    """Allow only valid Discord invite links or empty string; reject URL redirections."""
    value = str(value or '').strip()
    if not value:
        return ''
    if any(c.isspace() for c in value):
        raise ValueError('Zaproszenie nie może zawierać spacji.')
    if '://' not in value:
        value = 'https://' + value
    parsed = urlsplit(value)
    host = (parsed.hostname or '').lower()
    if parsed.scheme != 'https' or parsed.username or parsed.password or parsed.port:
        raise ValueError('Dozwolone jest wyłącznie zaproszenie HTTPS do Discorda.')
    bits = [segment for segment in parsed.path.strip('/').split('/') if segment]
    if host in ('discord.gg', 'www.discord.gg'):
        valid = len(bits) == 1
        code = bits[0] if valid else ''
    elif host in ('discord.com', 'www.discord.com', 'discordapp.com'):
        valid = len(bits) == 2 and bits[0] == 'invite'
        code = bits[1] if valid else ''
    else:
        raise ValueError('Podaj link discord.gg/kod lub discord.com/invite/kod.')
    if not valid or not (2 <= len(code) <= 64) or not all(ch.isascii() and (ch.isalnum() or ch in '-_') for ch in code):
        raise ValueError('Niepoprawny kod zaproszenia Discord.')
    return 'https://discord.gg/' + code


def presence_payload(prefs, playing, version=None, started_at=None):
    """Share only generic launcher/game information, never connected server/IP."""
    details = 'Gra w Minecraft Java' if playing else 'Przegląda launcher MINEVORA'
    state = 'MINEVORA'
    if playing and prefs.get('discord_show_version', False) and version:
        # Accept only a short game-version identifier, never arbitrary server text.
        safe_version = str(version).strip()
        if re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9._+\-]{0,39}', safe_version):
            state = 'Minecraft ' + safe_version
    result = {'details': details, 'state': state}
    if playing and isinstance(started_at, int) and started_at > 0:
        result['start'] = started_at
    return result


def should_publish(prefs, playing):
    return bool(prefs.get('discord_enabled')) and bool(prefs.get('discord_app_id')) and (playing or not prefs.get('discord_only_in_game', False))
