@echo off
cd /d "%~dp0"
title MINEVORA - diagnostyka
python minevora_doctor.py
pause
