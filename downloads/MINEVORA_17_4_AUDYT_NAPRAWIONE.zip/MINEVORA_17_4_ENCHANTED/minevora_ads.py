"""MINEVORA Ads Manager desktop interface, local prototype (PySide6)."""
from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices, QPixmap
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFrame, QLabel, QPushButton,
    QLineEdit, QTextEdit, QComboBox, QDialog, QFormLayout, QFileDialog,
    QMessageBox, QScrollArea, QTabWidget, QTreeWidget, QTreeWidgetItem,
    QAbstractItemView, QInputDialog,
)
from minevora_ads_core import (
    SLOTS, TYPES, create_campaign, change_status, validate_campaign,
    save_data, ads_for_slot, record_event, store_image,
)


COLOR = '#c2adef'

def label(text, size=13, muted=False, bold=False):
    obj = QLabel(str(text))
    obj.setTextFormat(Qt.PlainText)
    obj.setWordWrap(True)
    obj.setStyleSheet('background:transparent;color:%s;font-size:%dpx;font-weight:%s;' %
                      ('#bac7e1' if muted else '#f8f4ff', size, 800 if bold else 450))
    return obj


def button(title, callback, primary=False):
    obj = QPushButton(title)
    if primary:
        obj.setObjectName('primary')
    obj.clicked.connect(lambda _checked=False: callback())
    obj.setCursor(Qt.PointingHandCursor)
    return obj


def ad_widget(ad, on_open):
    """Visible, clearly disclosed campaign card for launcher placements."""
    outer = QFrame()
    outer.setObjectName('panel')
    outer.setStyleSheet('QFrame#panel {background:#1a2041;border:1px solid #705ba6;border-radius:14px;}')
    row = QHBoxLayout(outer)
    row.setContentsMargins(13, 10, 13, 10)
    row.setSpacing(12)
    raw_image = str(ad.get('image', ''))
    if raw_image and Path(raw_image).is_file():
        image = QPixmap(raw_image)
        if not image.isNull():
            pic = QLabel()
            pic.setAlignment(Qt.AlignCenter)
            pic.setFixedSize(124, 76)
            pic.setPixmap(image.scaled(124, 76, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            pic.setStyleSheet('background:#131a35;border-radius:8px;')
            row.addWidget(pic)
    content = QVBoxLayout()
    content.setSpacing(3)
    kind = 'SPONSOROWANE' if ad.get('type') == 'sponsored' else 'REKLAMA • MINEVORA'
    tag = label(kind + '  ·  ' + str(ad.get('advertiser', ''))[:55], 10, muted=True, bold=True)
    content.addWidget(tag)
    content.addWidget(label(str(ad.get('title', ''))[:75], 17, bold=True))
    content.addWidget(label(str(ad.get('description', ''))[:180], 11, muted=True))
    row.addLayout(content, 1)
    if ad.get('url'):
        row.addWidget(button('Otwórz  ↗', lambda: on_open(ad)))
    return outer


class CampaignDialog(QDialog):
    def __init__(self, kind, ad=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle('MINEVORA Ads • ' + ('Własny baner' if kind == 'own' else 'Zgłoszenie sponsorowane'))
        self.setMinimumWidth(525)
        self.kind = kind
        self.data = dict(ad or {})
        self.new_image = ''
        root = QVBoxLayout(self)
        root.addWidget(label('✦  NOWA KAMPANIA' if not ad else '✎  EDYCJA KAMPANII', 21, bold=True))
        root.addWidget(label('Banery sponsorowane trafiają do lokalnej kolejki moderacji. Bez opłat i bez publikacji w internecie.', 11, muted=True))
        form = QFormLayout()
        self.title_edit = QLineEdit(str(self.data.get('title', '')))
        self.title_edit.setMaxLength(75)
        form.addRow('Tytuł:', self.title_edit)
        self.advertiser_edit = QLineEdit(str(self.data.get('advertiser', '')))
        self.advertiser_edit.setMaxLength(70)
        form.addRow('Twórca / firma:', self.advertiser_edit)
        self.description_edit = QTextEdit()
        self.description_edit.setFixedHeight(76)
        self.description_edit.setPlainText(str(self.data.get('description', '')))
        form.addRow('Opis:', self.description_edit)
        self.slot_edit = QComboBox()
        self.slot_edit.addItems(list(SLOTS))
        self.slot_edit.setCurrentText(next((k for k, v in SLOTS.items() if v == self.data.get('slot')), 'Strona główna'))
        form.addRow('Miejsce reklamy:', self.slot_edit)
        self.url_edit = QLineEdit(str(self.data.get('url', '')))
        self.url_edit.setPlaceholderText('https://example.com  (opcjonalnie)')
        form.addRow('Adres HTTPS:', self.url_edit)
        self.image_edit = QLineEdit('')
        self.image_edit.setReadOnly(True)
        self.image_edit.setPlaceholderText('Opcjonalna grafika PNG, JPG lub WebP • maks. 5 MB')
        choose = QHBoxLayout()
        choose.addWidget(self.image_edit, 1)
        choose.addWidget(button('Wybierz obraz', self.pick_image))
        form.addRow('Baner:', choose)
        self.start_edit = QLineEdit(str(self.data.get('start', '')))
        self.start_edit.setPlaceholderText('RRRR-MM-DD • puste = od razu')
        form.addRow('Od dnia:', self.start_edit)
        self.end_edit = QLineEdit(str(self.data.get('end', '')))
        self.end_edit.setPlaceholderText('RRRR-MM-DD • puste = bez końca')
        form.addRow('Do dnia:', self.end_edit)
        root.addLayout(form)
        options = QHBoxLayout()
        options.addWidget(button('Anuluj', self.reject))
        options.addWidget(button('Zapisz kampanię', self.validate_and_accept, True))
        root.addLayout(options)

    def pick_image(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Grafika reklamy', '', 'Obrazy (*.png *.jpg *.jpeg *.webp)')
        if path:
            self.new_image = path
            self.image_edit.setText(Path(path).name)

    def fields(self):
        return dict(title=self.title_edit.text(), description=self.description_edit.toPlainText(),
                    advertiser=self.advertiser_edit.text(), url=self.url_edit.text(),
                    slot=SLOTS[self.slot_edit.currentText()], kind=self.kind,
                    start=self.start_edit.text().strip(), end=self.end_edit.text().strip())

    def validate_and_accept(self):
        try:
            validate_campaign(**self.fields())
            if self.new_image:
                src = Path(self.new_image)
                if not src.is_file() or src.stat().st_size > 5 * 1024 * 1024:
                    raise ValueError('Grafika nie istnieje lub jest za duża (maks. 5 MB).')
            self.accept()
        except (ValueError, OSError) as exc:
            QMessageBox.warning(self, 'Sprawdź formularz', str(exc))


class AdsHub(QWidget):
    """A local creator submission flow and operator-only-by-convention admin interface.

    The operator panel is NOT remotely authenticated; for a public application,
    permissions and approvals must be moved server-side.
    """
    def __init__(self, data, changed=None, parent=None):
        super().__init__(parent)
        self.data = data
        self.changed = changed or (lambda: None)
        self._make_ui()
        self.refresh()

    def _make_ui(self):
        outside = QVBoxLayout(self)
        outside.setContentsMargins(20, 17, 20, 18)
        outside.setSpacing(11)
        outside.addWidget(label('📢  MINEVORA ADS MANAGER', 27, bold=True))
        outside.addWidget(label('Własne banery + lokalne zgłoszenia sponsorowane. Wszystkie aktywne reklamy są oznaczone.', 12, muted=True))
        self.tabs = QTabWidget()
        outside.addWidget(self.tabs, 1)
        self.preview_tab = QWidget()
        self.tabs.addTab(self.preview_tab, 'Kampanie')
        pv = QVBoxLayout(self.preview_tab)
        filters = QHBoxLayout()
        self.filter = QComboBox()
        self.filter.addItems(['Wszystkie', 'Aktywne', 'Oczekujące', 'Wstrzymane', 'Odrzucone'])
        self.filter.currentIndexChanged.connect(self.refresh)
        filters.addWidget(label('Pokaż:'))
        filters.addWidget(self.filter)
        filters.addStretch()
        pv.addLayout(filters)
        self.table = QTreeWidget()
        self.table.setHeaderLabels(['Kampania', 'Rodzaj', 'Miejsce', 'Status', 'Odsłony', 'Kliknięcia'])
        self.table.setRootIsDecorated(False)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setMinimumHeight(230)
        self.table.itemDoubleClicked.connect(lambda *_: self.preview_selected())
        pv.addWidget(self.table, 1)
        actions = QHBoxLayout()
        actions.addWidget(button('＋ Własny baner', lambda: self.create('own'), True))
        actions.addWidget(button('＋ Zgłoś sponsorowaną', lambda: self.create('sponsored')))
        actions.addWidget(button('Podgląd', self.preview_selected))
        pv.addLayout(actions)
        self.summary = label('', 11, muted=True)
        pv.addWidget(self.summary)
        self.operator_tab = QWidget()
        self.tabs.addTab(self.operator_tab, 'Panel administratora (lokalny)')
        op = QVBoxLayout(self.operator_tab)
        op.addWidget(label('🛡  MODERACJA KAMPANII', 21, bold=True))
        op.addWidget(label('Panel lokalnego operatora, bez prawdziwego uwierzytelniania administratora. Nie udostępniaj tego interfejsu jako publicznej moderacji.', 11, muted=True))
        self.admin_list = QTreeWidget()
        self.admin_list.setHeaderLabels(['Kampania', 'Rodzaj', 'Status', 'Reklamodawca'])
        self.admin_list.setRootIsDecorated(False)
        self.admin_list.setSelectionMode(QAbstractItemView.SingleSelection)
        op.addWidget(self.admin_list, 1)
        row = QHBoxLayout()
        row.addWidget(button('✓ Zatwierdź', lambda: self.update_status('active'), True))
        row.addWidget(button('⏸ Wstrzymaj', lambda: self.update_status('paused')))
        row.addWidget(button('✕ Odrzuć', lambda: self.update_status('rejected')))
        op.addLayout(row)
        row2 = QHBoxLayout()
        row2.addWidget(button('Edytuj', self.edit_selected))
        row2.addWidget(button('Usuń', self.delete_selected))
        row2.addWidget(button('Podgląd', self.preview_selected_admin))
        op.addLayout(row2)
        op.addWidget(label('Sponsorowane kampanie trafiają do oczekujących. Zatwierdzenie działa tylko w tej kopii launchera; nie jest globalną autoryzacją.', 11, muted=True))
        self.info_tab = QWidget()
        self.tabs.addTab(self.info_tab, 'O systemie')
        info = QVBoxLayout(self.info_tab)
        info.addWidget(label('Jak działają reklamy?', 22, bold=True))
        info.addWidget(label('• Własny baner pojawia się po zapisie, zgodnie z harmonogramem.\n\n'
                             '• Kampania sponsorowana wymaga zatwierdzenia w lokalnym panelu.\n\n'
                             '• Reklamy są pokazywane na stronie głównej, w Marketplace oraz w Serwerach.\n\n'
                             '• Odsłony i kliknięcia są orientacyjnymi licznikami lokalnymi. Nie zbieramy danych osobowych ani identyfikatorów użytkowników.\n\n'
                             '• Nie ma opłat, faktur, portfela, reklam zewnętrznych ani realnego systemu składania zamówień.\n\n'
                             '• Publiczne kampanie, rozliczenia, moderacja i uprawnienia administratorów wymagają backendu.', 13))
        info.addStretch()

    def _commit(self):
        save_data(self.data)
        self.refresh()
        self.changed()

    def refresh(self, *_):
        if not hasattr(self, 'table'):
            return
        selection = self.filter.currentText()
        values = {'Wszystkie': '', 'Aktywne': 'active', 'Oczekujące': 'pending',
                  'Wstrzymane': 'paused', 'Odrzucone': 'rejected'}
        key = values.get(selection, '')
        self.table.clear()
        self.admin_list.clear()
        entries = list(reversed(self.data['ads']))
        statuses = {'active': 'Aktywna', 'pending': 'Oczekuje', 'rejected': 'Odrzucona', 'paused': 'Wstrzymana'}
        for ad in entries:
            slot_label = next((name for name, value in SLOTS.items() if value == ad.get('slot')), ad.get('slot', ''))
            if not key or ad.get('status') == key:
                item = QTreeWidgetItem([str(ad.get('title', '')), 'Sponsorowana' if ad.get('type') == 'sponsored' else 'Własna',
                                       slot_label, statuses.get(ad.get('status'), '?'),
                                       str(ad.get('impressions', 0)), str(ad.get('clicks', 0))])
                item.setData(0, Qt.UserRole, ad.get('id'))
                self.table.addTopLevelItem(item)
            admin = QTreeWidgetItem([str(ad.get('title', '')), 'Sponsorowana' if ad.get('type') == 'sponsored' else 'Własna',
                                     statuses.get(ad.get('status'), '?'), str(ad.get('advertiser', ''))])
            admin.setData(0, Qt.UserRole, ad.get('id'))
            self.admin_list.addTopLevelItem(admin)
        own = sum(1 for ad in entries if ad.get('type') == 'own')
        pending = sum(1 for ad in entries if ad.get('status') == 'pending')
        self.summary.setText('Kampanie: %s  •  Własne: %s  •  Oczekujące: %s  •  Statystyki lokalne (nie sieciowe)' % (len(entries), own, pending))
        for index in range(6):
            self.table.resizeColumnToContents(index)
        for index in range(4):
            self.admin_list.resizeColumnToContents(index)

    def _selected(self, widget):
        selected = widget.selectedItems()
        if not selected:
            QMessageBox.information(self, 'MINEVORA Ads', 'Wybierz kampanię z listy.')
            return None
        identifier = selected[0].data(0, Qt.UserRole)
        return next((a for a in self.data['ads'] if a.get('id') == identifier), None)

    def create(self, kind):
        form = CampaignDialog(kind, parent=self)
        if form.exec() != QDialog.Accepted:
            return
        try:
            image = store_image(form.new_image) if form.new_image else ''
            ad = create_campaign(self.data, form.fields(), image=image)
            self._commit()
        except (ValueError, OSError) as exc:
            QMessageBox.warning(self, 'MINEVORA Ads', str(exc))
            return
        QMessageBox.information(self, 'Zapisano', 'Baner aktywny lokalnie.' if ad['status'] == 'active'
                                else 'Zgłoszenie zostało zapisane lokalnie i czeka na zatwierdzenie.')

    def edit_selected(self):
        ad = self._selected(self.admin_list)
        if not ad:
            return
        form = CampaignDialog(ad['type'], ad=ad, parent=self)
        if form.exec() != QDialog.Accepted:
            return
        try:
            fields = validate_campaign(**form.fields())
            image = store_image(form.new_image) if form.new_image else ad.get('image', '')
            ad.update(fields)
            ad['image'] = image
            if ad['type'] == 'sponsored':
                ad['status'] = 'pending'
            self._commit()
        except (ValueError, OSError) as exc:
            QMessageBox.warning(self, 'MINEVORA Ads', str(exc))

    def update_status(self, status):
        ad = self._selected(self.admin_list)
        if not ad:
            return
        note = ''
        if status == 'rejected':
            note, accepted = QInputDialog.getText(self, 'Powód odrzucenia', 'Powód (opcjonalnie, lokalny):')
            if not accepted:
                return
        try:
            change_status(self.data, ad['id'], status, note)
            self._commit()
        except ValueError as exc:
            QMessageBox.warning(self, 'MINEVORA Ads', str(exc))

    def delete_selected(self):
        ad = self._selected(self.admin_list)
        if not ad:
            return
        if QMessageBox.question(self, 'Usuń kampanię', 'Usunąć kampanię „%s”?' % ad['title']) != QMessageBox.Yes:
            return
        self.data['ads'][:] = [x for x in self.data['ads'] if x.get('id') != ad['id']]
        self._commit()

    def preview_selected(self):
        self._preview(self._selected(self.table))

    def preview_selected_admin(self):
        self._preview(self._selected(self.admin_list))

    def _preview(self, ad):
        if not ad:
            return
        dialog = QDialog(self)
        dialog.setWindowTitle('Podgląd reklamy MINEVORA')
        dialog.resize(620, 300)
        body = QVBoxLayout(dialog)
        body.addWidget(ad_widget(ad, lambda x: self._open(x)))
        body.addWidget(label('Status: %s  |  Odsłony: %s  |  Kliknięcia: %s' %
                             (ad.get('status', '?'), ad.get('impressions', 0), ad.get('clicks', 0)), 11, muted=True))
        body.addWidget(button('Zamknij', dialog.accept))
        dialog.exec()

    def _open(self, ad):
        # A deliberate user click, not an auto-open. Public cards record the click.
        from minevora_ads_core import validate_url
        try:
            url = validate_url(str(ad.get('url', '')))
        except ValueError as exc:
            QMessageBox.warning(self, 'Adres reklamowy', str(exc))
            return
        if not url:
            return
        record_event(self.data, ad['id'], 'click')
        self._commit()
        QDesktopServices.openUrl(QUrl(url))
