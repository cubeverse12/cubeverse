"""MINEVORA Together: local server bookmarks and verified opt-in mod setup.

This does NOT claim to be an independent P2P world-hosting mod. Installing
third-party Essential (after explicit confirmation in the GUI) enables its own
in-game social/hosting features, subject to Essential's terms and compatibility.
"""
from __future__ import annotations

import ipaddress
import json
import re
from pathlib import Path

from minevora_auto_dependencies import (
    DependencyError, _candidate_jar, _download_verified, _get_json,
    _safe_mod_folder, install_missing_dependencies,
)

BOOKMARKS_PATH = Path.home() / '.minevora' / 'together_servers.json'
MAX_BOOKMARKS = 60
HOSTNAME_PATTERN = re.compile(r'(?i)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*\Z')


def normalize_server_address(raw: str) -> str:
    """Normalize Minecraft Java host[:port]. No URLs, credentials, whitespace."""
    val = str(raw or '').strip()
    if not val or len(val) > 255 or any(x in val for x in ('/', '\\', '@', '?', '#', ' ', '\n', '\t')):
        raise ValueError('Wpisz adres serwera, np. play.example.com:25565.')
    if val.startswith('['):
        match = re.fullmatch(r'\[([^]]+)](?::([0-9]{1,5}))?', val)
        if not match: raise ValueError('Nieprawidłowy adres IPv6.')
        try:host = str(ipaddress.IPv6Address(match.group(1)))
        except ValueError as exc:raise ValueError('Nieprawidłowy adres IPv6.') from exc
        canon = f'[{host}]'
        port = match.group(2)
    else:
        if val.count(':') > 1: raise ValueError('IPv6 podaj w nawiasach [adres]:port.')
        host, _, port = val.partition(':')
        if not HOSTNAME_PATTERN.fullmatch(host):
            try:host = str(ipaddress.IPv4Address(host))
            except ValueError as exc: raise ValueError('Nieprawidłowy adres serwera.') from exc
        canon = host.lower()
    if port and not 1 <= int(port) <= 65535:
        raise ValueError('Port musi być w zakresie 1–65535.')
    return canon + ((':' + str(int(port))) if port else '')


def load_bookmarks(path: Path = BOOKMARKS_PATH) -> list[dict[str, str]]:
    try:raw=json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):return []
    if not isinstance(raw, list):return []
    result=[]; seen=set()
    for item in raw[:MAX_BOOKMARKS]:
        if not isinstance(item,dict):continue
        try:address=normalize_server_address(item.get('address',''))
        except ValueError:continue
        if address in seen:continue
        name=str(item.get('name','')).strip()[:48] or address
        result.append({'name':name,'address':address});seen.add(address)
    return result


def save_bookmarks(bookmarks: list[dict], path: Path = BOOKMARKS_PATH) -> None:
    if not isinstance(bookmarks,list) or len(bookmarks)>MAX_BOOKMARKS:
        raise ValueError('Przekroczono limit zapisanych adresów.')
    normalized=[];seen=set()
    for item in bookmarks:
        name=str(item.get('name','')).strip()[:48]
        address=normalize_server_address(item.get('address',''))
        if not name or not address or address in seen:raise ValueError('Niepoprawna nazwa lub powtórzony adres.')
        normalized.append({'name':name,'address':address});seen.add(address)
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.new')
    temp.write_text(json.dumps(normalized,ensure_ascii=False,indent=2),encoding='utf-8')
    temp.replace(path)


def existing_essential_files(game_dir: str | Path) -> list[str]:
    folder=_safe_mod_folder(game_dir)
    if not folder.is_dir():return []
    return sorted(p.name for p in folder.iterdir() if p.is_file() and not p.is_symlink()
                  and p.suffix.lower()=='.jar' and re.match(r'(?i)^essential(?:[-_.]|\d)',p.name))


def get_essential_release(mc_version: str, loader: str, *, opener=None) -> dict:
    if not re.fullmatch(r'1\.\d+(?:\.\d+)?',mc_version or '') or loader not in ('fabric','forge','neoforge'):
        raise DependencyError('Wybierz wersję Minecraft z loaderem Fabric, Forge lub NeoForge.')
    # Official Modrinth project slug. Do not package/modify third-party binaries.
    project=_get_json('/project/essential', opener=opener)
    if not isinstance(project,dict) or project.get('slug')!='essential' or project.get('project_type')!='mod':
        raise DependencyError('Nie udało się potwierdzić projektu Essential w Modrinth.')
    versions=_get_json('/project/essential/version',params={'loaders':json.dumps([loader]),
        'game_versions':json.dumps([mc_version]),'include_changelog':'false'},opener=opener)
    if not isinstance(versions,list):raise DependencyError('Nieprawidłowa lista wersji Essential.')
    chosen=next((v for v in versions if v.get('version_type')=='release' and
                 mc_version in v.get('game_versions',[]) and loader in v.get('loaders',[])),None)
    if chosen is None:
        chosen=next((v for v in versions if mc_version in v.get('game_versions',[]) and loader in v.get('loaders',[])),None)
    if chosen is None:raise DependencyError(f'Essential nie ma zgodnego wydania dla Minecraft {mc_version} / {loader}.')
    if chosen.get('project_id')!=project.get('id'):
        raise DependencyError('Niezgodny identyfikator projektu w odpowiedzi Modrinth.')
    return _candidate_jar(chosen)


def install_essential(game_dir: str | Path, mc_version: str, loader: str,
                      *, opener=None, progress=None) -> dict:
    """Install official release once, verified. Never overwrite existing files.

    Note: network and filesystem writes MUST be called only after GUI consent.
    """
    existing=existing_essential_files(game_dir)
    if existing:return {'status':'already_installed','files':existing,'dependencies':[]}
    if progress:progress('Sprawdzam oficjalną wersję Essential na Modrinth…')
    item=get_essential_release(mc_version,loader,opener=opener)
    folder=_safe_mod_folder(game_dir)
    if folder.exists() and not folder.is_dir():raise DependencyError('Nieprawidłowy katalog mods.')
    folder.mkdir(parents=True,exist_ok=True)
    dest=folder/item['filename']
    if dest.exists() or dest.is_symlink():raise DependencyError('Plik już istnieje: '+dest.name)
    if progress:progress('Pobieram i weryfikuję SHA-512: '+item['filename'])
    temp=_download_verified(item,folder,opener=opener)
    created=False
    try:
        with dest.open('xb') as out, temp.open('rb') as src:
            created=True
            for chunk in iter(lambda:src.read(1024*1024),b''):out.write(chunk)
        if progress:progress('Sprawdzam wymagane biblioteki…')
        deps=install_missing_dependencies(game_dir,mc_version,loader,opener=opener,progress=progress)
        return {'status':'installed','files':[dest.name], 'dependencies':deps['installed']}
    except Exception:
        if created:dest.unlink(missing_ok=True)
        raise
    finally:temp.unlink(missing_ok=True)
