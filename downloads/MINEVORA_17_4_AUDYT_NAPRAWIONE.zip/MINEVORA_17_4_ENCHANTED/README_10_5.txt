MINEVORA 10.5 — Polski / English + Mod Updates + Discord Channels
==================================================================

LAUNCHER
1. Rozpakuj cały ZIP do osobnego folderu.
2. Uruchom INSTALUJ_ZALEZNOSCI.bat oraz URUCHOM_MINEVORA.bat.
3. W górnym prawym rogu ustaw PL albo EN. Ten sam wybór jest w Ustawieniach.
   Tłumaczenie obejmuje menu, ekran startowy, główne opcje i katalog Modrinth.
   Rozbudowane narzędzia z wcześniejszych wersji mogą zawierać jeszcze teksty PL.

AUTOMATYCZNE AKTUALIZACJE MODÓW
1. Otwórz Mody -> Modrinth -> Sprawdź aktualizacje modów.
2. Podaj dokładną wersję Minecraft (np. 1.21.1) i wybierz loader
   Fabric, Forge, NeoForge lub Quilt. Niewłaściwy loader może zepsuć zestaw modów.
3. Kliknij Sprawdź aktualizacje; zobaczysz zmiany i możesz je zaznaczyć.
4. Kliknij Zaktualizuj zaznaczone. Program sprawdzi SHA-512, zachowa oryginały
   w %USERPROFILE%\.minevora\mod_backups i zamieni pliki .jar.
5. Jeśli chcesz AUTOMATYCZNE działanie: włącz przełącznik w Ustawieniach
   albo w oknie aktualizacji. Przy kolejnym otwarciu Mody (gdy wybrana jest
   instancja z rozpoznanym loaderem) skan i aktualizacja ruszą automatycznie.
   Nie aktualizuj modów przy uruchomionym Minecraft.

UWAGI MODRINTH
- Do aktualizacji kwalifikują się wyłącznie rozpoznane przez Modrinth pliki .jar.
- Sprawdzane są najnowsze stabilne wydania zgodne z wybraną wersją i loaderem.
- Nieznane mody pozostają nietknięte.
- Zależności modów należy sprawdzić osobno; pliki modpacków mogą wymagać
  konkretnej wersji, więc dla modpacków wyłącz automatyczne aktualizacje.
- W razie awarii odtwórz stary plik z folderu mod_backups.
- Aktualizator nie działa w tle, gdy launcher jest zamknięty.
- Pliki pobierane są przez HTTPS z cdn.modrinth.com z kontrolą SHA-512.

DISCORD — JĘZYK KANAŁÓW
1. Folder DISCORD_SETUP zawiera INSTALUJ.bat oraz UTWORZ_KANALY.bat.
2. Pierwsza konfiguracja: uruchom UTWORZ_KANALY.bat. Wybierz PL albo EN.
   Program tworzy brakujące kategorie, kanały oraz role z uprawnieniami.
3. Późniejsza zmiana nazw kanałów: ZMIEN_JEZYK_KANALOW.bat.
   Skrypt zmieni nazwy istniejących, rozpoznanych kanałów PL <-> EN.
   Nie tworzy nowych kanałów w tym trybie, nie usuwa wiadomości,
   nie resetuje uprawnień i nie zmienia kanałów niepowiązanych z MINEVORA.
4. Potrzebne uprawnienia bota: Manage Channels. Do pierwszej instalacji
   potrzebne także Manage Roles. Token wpisz tylko w lokalnym oknie.
5. Nazwy na Discordzie są wspólne dla serwera, a nie oddzielne dla każdego
   użytkownika. Wiadomości i treści wcześniej wysłane nie są tłumaczone.
   Zawsze sprawdź kanały i uprawnienia po zmianie nazw.

Wszystkie trzy funkcje działają na komputerze Windows.
