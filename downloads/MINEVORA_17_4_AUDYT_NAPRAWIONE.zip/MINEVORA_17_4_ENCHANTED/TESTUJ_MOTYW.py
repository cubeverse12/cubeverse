"""Testy bez GUI: spójność nowego motywu, odnośników i plików.
Uruchom: python TESTUJ_MOTYW.py
"""
import ast
from pathlib import Path

ROOT=Path(__file__).resolve().parent
required=['minevora_start.py','minevora_qt.py','minevora_visual_skin.py',
'minevora_enchanted_theme.py','minevora_minigames_qt.py','minevora_pvp.py',
'minevora_discord.py','minevora_together_qt.py','minevora_leaderboard_qt.py',
'URUCHOM_MINEVORA.bat','assets/minevora_home_reference.jpg',
'assets/minevora_section_portal.jpg']
for name in required:
 assert (ROOT/name).is_file(),f'Brakuje: {name}'
for p in ROOT.glob('*.py'):
 ast.parse(p.read_text(encoding='utf-8'),filename=p.name)
source=(ROOT/'minevora_qt.py').read_text(encoding='utf-8')
tree=ast.parse(source)
window=next(obj for obj in tree.body if isinstance(obj,ast.ClassDef) and obj.name=='Window')
methods={m.name for m in window.body if isinstance(m,ast.FunctionDef)}
for method in ['home','instances','mods','market','minigames','pvp','leaderboard',
               'discord_page','settings','together','play','update_enchanted_banner',
               'highlight_nav','on_reference_page_changed']:
 assert method in methods,f'Brak funkcji: {method}'
ui=['minevora_minigames_qt.py','minevora_discord.py','minevora_pvp.py',
    'minevora_together_qt.py','minevora_leaderboard_qt.py']
for filename in ui:
 assert (ROOT/filename).stat().st_size>1000,filename
qss=(ROOT/'minevora_enchanted_theme.py').read_text(encoding='utf-8')
for needle in ['QPushButton#nav','QPushButton#primary','QFrame#panel',
               'QFrame#sidebar','QFrame#footer','QFrame#chatSidebar']:
 assert needle in qss,needle
for needle in ['GRAJ / WERSJE','MARKETPLACE','PVP CENTER','MINIGRY',
               'RANKING','DISCORD • MINEVORA','MINEVORA TOGETHER',
               "('USTAWIENIA MINEVORA'", "('MODY I DODATKI'", "('EDYTOR SKINÓW'"]:
 assert needle in source,needle
assert 'ENCHANTED_QSS' in source
print('OK — motyw, 10 sekcji, przyciski, moduły i składnia plików. Test GUI wymaga Windows/PySide6.')
