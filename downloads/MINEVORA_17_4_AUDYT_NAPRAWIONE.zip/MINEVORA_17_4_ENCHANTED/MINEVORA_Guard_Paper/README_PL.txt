MINEVORA Guard — Paper 1.21.4 + Java 21

Instalacja: skopiuj MINEVORAGuard.jar do plugins/ serwera Paper i zrestartuj serwer.
Panel moderatora: /mg help, /mg status, /mg inspect <nick>, /mg alerts, /mg reload.
Dane: plugins/MINEVORAGuard/evidence.jsonl — zaimportuj do panelu Fair Play w MINEVORA 9.5.
Domyślnie: tylko alerty, nigdy automatyczny ban.
Maven: mvn clean package (przy połączeniu z repozytorium PaperMC).

UWAGA: Dystrybuowany JAR skompilowano przy użyciu minimalnych sygnatur API.
Test jednostkowy kodu wykonano, ale działania na realnym Paper jeszcze nie przetestowano.
Najlepiej przed produkcją zbudować ponownie przez Maven i przetestować na serwerze testowym.
