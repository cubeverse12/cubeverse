package pl.minevora.guard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BoundingBox;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Server-side, evidence-first Paper anti-cheat. No IP collection or automatic bans. */
public final class MinevoraGuardPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, State> states = new HashMap<>();
    private final Set<UUID> mutedAlerts = new java.util.HashSet<>();
    private Path evidencePath;
    private long serverTicks = 0;
    private static final long GRACE_TICKS = 80;

    private static final class State {
        Location lastLocation;
        long lastSampleMs;
        long exemptUntilTick;
        int speedBuffer;
        int hoverBuffer;
        int reachBuffer;
        int clickBuffer;
        int placeBuffer;
        int totalAlerts;
        long lastFightMs;
        final Deque<Long> swings = new ArrayDeque<>();
        final Deque<Long> placements = new ArrayDeque<>();
        final Map<String, Long> lastAlerts = new HashMap<>();
        final Map<String, Integer> categories = new HashMap<>();
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        evidencePath = getDataFolder().toPath().resolve("evidence.jsonl");
        try { Files.createDirectories(getDataFolder().toPath()); }
        catch (IOException e) { getLogger().severe("Nie można utworzyć folderu logów: " + e.getMessage()); }
        pruneOldEvidence();
        Bukkit.getPluginManager().registerEvents(this, this);
        if (getCommand("minevoraguard") != null) getCommand("minevoraguard").setExecutor(this);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            serverTicks += 5;
            for (Player player : Bukkit.getOnlinePlayers()) sample(player);
        }, 20L, 5L);
        getLogger().info("MINEVORA Guard aktywny. Tryb: ALERTY / dowody. Automatyczne bany wyłączone.");
    }

    @Override
    public void onDisable() { states.clear(); mutedAlerts.clear(); }

    private State state(Player p) { return states.computeIfAbsent(p.getUniqueId(), ignored -> new State()); }

    private boolean enabled(String check) { return getConfig().getBoolean("checks." + check + ".enabled", true); }
    private double limit(String path, double fallback) { return getConfig().getDouble(path, fallback); }

    private void exempt(Player p, long ticks) {
        State s = state(p);
        s.exemptUntilTick = Math.max(s.exemptUntilTick, serverTicks + ticks);
        s.lastLocation = null;
        s.speedBuffer = 0;
        s.hoverBuffer = 0;
        s.reachBuffer = 0;
    }

    @EventHandler public void join(PlayerJoinEvent event) { exempt(event.getPlayer(), GRACE_TICKS); }
    @EventHandler public void quit(PlayerQuitEvent event) { states.remove(event.getPlayer().getUniqueId()); mutedAlerts.remove(event.getPlayer().getUniqueId()); }
    @EventHandler(ignoreCancelled = true) public void teleport(PlayerTeleportEvent event) { exempt(event.getPlayer(), GRACE_TICKS); }
    @EventHandler public void worldChanged(PlayerChangedWorldEvent event) { exempt(event.getPlayer(), GRACE_TICKS); }
    @EventHandler(ignoreCancelled = true) public void velocity(PlayerVelocityEvent event) { exempt(event.getPlayer(), 35); }
    @EventHandler(ignoreCancelled = true) public void damageGrace(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player p) exempt(p, 25);
    }

    private boolean invalidEnvironment(Player p) {
        if (p.getGameMode() != GameMode.SURVIVAL && p.getGameMode() != GameMode.ADVENTURE) return true;
        if (p.hasPermission("minevora.guard.bypass") || p.getAllowFlight() || p.isFlying() || p.isGliding() || p.isSwimming() || p.isInsideVehicle()
                || p.isRiptiding() || p.isInWater() || p.isClimbing()) return true;
        // Abilities and potion effects can legitimately produce abnormal movement.
        return p.getActivePotionEffects().stream().anyMatch(e -> {
            String name = e.getType().getName().toUpperCase(Locale.ROOT);
            return name.contains("LEVITATION") || name.contains("SLOW_FALLING")
                    || name.contains("DOLPHINS_GRACE") || name.contains("JUMP_BOOST");
        });
    }

    private boolean slippery(Location loc) {
        for (int dy = -2; dy <= 0; dy++) {
            Material material = loc.clone().add(0, dy, 0).getBlock().getType();
            String n = material.name();
            if (n.contains("ICE") || n.contains("SLIME") || n.contains("HONEY") || n.contains("WEB")
                    || n.contains("SOUL_SAND") || n.contains("POWDER_SNOW") || n.contains("BUBBLE_COLUMN")) return true;
        }
        return false;
    }

    private boolean clearBelow(Location loc, int depth) {
        World world = loc.getWorld();
        if (world == null || loc.getBlockY() - depth <= world.getMinHeight()) return false;
        // Include player hitbox corners: standing on a narrow edge must not be marked as flight.
        double[] offsets = {-0.29, 0.29};
        for (int i = 1; i <= depth; i++) {
            for (double dx : offsets) for (double dz : offsets) {
                Block block = loc.clone().add(dx, -i, dz).getBlock();
                if (block.getType().isSolid() || block.isLiquid()) return false;
            }
        }
        return true;
    }

    private int speedAmplifier(Player p) {
        return p.getActivePotionEffects().stream()
                .filter(e -> e.getType().getName().equalsIgnoreCase("SPEED"))
                .mapToInt(e -> e.getAmplifier() + 1).max().orElse(0);
    }

    private void sample(Player p) {
        State s = state(p);
        Location loc = p.getLocation();
        long now = System.currentTimeMillis();
        if (s.lastLocation == null || !loc.getWorld().equals(s.lastLocation.getWorld())) {
            s.lastLocation = loc; s.lastSampleMs = now; return;
        }
        Location previous = s.lastLocation;
        double elapsedMs = now - s.lastSampleMs;
        s.lastLocation = loc;
        s.lastSampleMs = now;
        if (elapsedMs < 150 || elapsedMs > 2500 || s.exemptUntilTick > serverTicks || invalidEnvironment(p)) {
            s.speedBuffer = Math.max(0, s.speedBuffer - 1);
            s.hoverBuffer = Math.max(0, s.hoverBuffer - 1);
            return;
        }

        if (enabled("speed")) {
            double speed = GuardMath.horizontalSpeed(previous.getX(), previous.getZ(), loc.getX(), loc.getZ(), elapsedMs);
            double maximum = limit("checks.speed.max-blocks-per-tick", 0.90) + speedAmplifier(p) * 0.22;
            if (slippery(loc) || slippery(previous)) maximum = Math.max(maximum, 1.55);
            if (speed > maximum && loc.distanceSquared(previous) < 180.0) {
                if (++s.speedBuffer >= 3) {
                    flag(p, "SPEED", String.format(Locale.ROOT, "speed=%.2f b/t; limit=%.2f b/t; ping=%dms", speed, maximum, p.getPing()));
                    s.speedBuffer = 1;
                }
            } else s.speedBuffer = Math.max(0, s.speedBuffer - 1);
        }

        if (enabled("hover")) {
            double vertical = Math.abs(loc.getY() - previous.getY());
            boolean suspended = clearBelow(loc, 4) && !slippery(loc);
            if (suspended && vertical < limit("checks.hover.max-y-change", 0.065)) {
                if (++s.hoverBuffer >= 8) {
                    flag(p, "HOVER", "sustained-airborne; small vertical displacement over multiple checks; ping=" + p.getPing() + "ms");
                    s.hoverBuffer = 3;
                }
            } else s.hoverBuffer = Math.max(0, s.hoverBuffer - 2);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player p) || !(event.getEntity() instanceof Player victim)) return;
        State s = state(p);
        s.lastFightMs = System.currentTimeMillis();
        if (!enabled("reach") || invalidEnvironment(p) || s.exemptUntilTick > serverTicks
                || victim.getWorld() != p.getWorld() || state(victim).exemptUntilTick > serverTicks
                || p.getPing() > 250 || victim.getPing() > 250) return;
        BoundingBox box = victim.getBoundingBox();
        Location eye = p.getEyeLocation();
        double distance = GuardMath.pointToBox(eye.getX(), eye.getY(), eye.getZ(),
                box.getMinX(), box.getMinY(), box.getMinZ(), box.getMaxX(), box.getMaxY(), box.getMaxZ());
        double maximum = limit("checks.reach.max-distance", 4.85);
        if (distance > maximum) {
            if (++s.reachBuffer >= 3) {
                flag(p, "REACH", String.format(Locale.ROOT, "eye-to-hitbox=%.2fm; threshold=%.2fm; attacker_ping=%dms; victim_ping=%dms",
                        distance, maximum, p.getPing(), victim.getPing()));
                s.reachBuffer = 1;
            }
        } else s.reachBuffer = Math.max(0, s.reachBuffer - 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void swing(PlayerAnimationEvent event) {
        Player p = event.getPlayer();
        if (!enabled("clicks") || invalidEnvironment(p)) return;
        State s = state(p);
        long now = System.currentTimeMillis();
        if (now - s.lastFightMs > 3500) { s.swings.clear(); s.clickBuffer = 0; return; }
        s.swings.addLast(now);
        while (!s.swings.isEmpty() && now - s.swings.peekFirst() > 1000) s.swings.removeFirst();
        if (s.swings.size() >= (int) limit("checks.clicks.swings-per-second", 27)) {
            if (++s.clickBuffer >= 4) {
                flag(p, "FAST_SWING", "arm-swings-in-last-second=" + s.swings.size() + "; not proof of autoclicker");
                s.clickBuffer = 0;
            }
        } else s.clickBuffer = Math.max(0, s.clickBuffer - 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void place(BlockPlaceEvent event) {
        Player p = event.getPlayer();
        if (!enabled("fastplace") || invalidEnvironment(p)) return;
        State s = state(p);
        long now = System.currentTimeMillis();
        s.placements.addLast(now);
        while (!s.placements.isEmpty() && now - s.placements.peekFirst() > 1000) s.placements.removeFirst();
        if (s.placements.size() >= (int) limit("checks.fastplace.blocks-per-second", 18)) {
            if (++s.placeBuffer >= 4) {
                flag(p, "FAST_PLACE", "blocks-placed-in-last-second=" + s.placements.size() + "; requires manual review");
                s.placeBuffer = 0;
            }
        } else s.placeBuffer = Math.max(0, s.placeBuffer - 1);
    }

    private void pruneOldEvidence() {
        int retentionDays = Math.max(1, getConfig().getInt("evidence.retention-days", 30));
        long limitMs = System.currentTimeMillis() - Duration.ofDays(retentionDays).toMillis();
        try (var files = Files.list(getDataFolder().toPath())) {
            files.filter(path -> path.getFileName().toString().matches("evidence-[0-9-]+\\.jsonl"))
                 .forEach(path -> {
                     try {
                         if (Files.getLastModifiedTime(path).toMillis() < limitMs) Files.deleteIfExists(path);
                     } catch (IOException error) { getLogger().warning("Pruning: " + error.getMessage()); }
                 });
        } catch (IOException error) { getLogger().warning("Pruning: " + error.getMessage()); }
    }

    private void flag(Player player, String check, String evidence) {
        State s = state(player);
        long now = System.currentTimeMillis();
        long cooldown = (long) limit("alerts.cooldown-seconds", 30) * 1000L;
        if (now - s.lastAlerts.getOrDefault(check, 0L) < cooldown) return;
        s.lastAlerts.put(check, now);
        s.totalAlerts++;
        s.categories.merge(check, 1, Integer::sum);
        String serverName = getConfig().getString("server-name", "MINEVORA-Official");
        String timestamp = Instant.now().toString();
        String reportId = UUID.randomUUID().toString();
        String payload = "{"
                + "\"schema\":\"minevora.guard.v1\","
                + "\"event_id\":" + GuardMath.json(reportId) + ","
                + "\"timestamp\":" + GuardMath.json(timestamp) + ","
                + "\"server\":" + GuardMath.json(serverName) + ","
                + "\"player_name\":" + GuardMath.json(player.getName()) + ","
                + "\"player_uuid\":" + GuardMath.json(player.getUniqueId().toString()) + ","
                + "\"check\":" + GuardMath.json(check) + ","
                + "\"evidence\":" + GuardMath.json(evidence) + ","
                + "\"classification\":\"UNVERIFIED_SIGNAL\"}"
                + System.lineSeparator();
        try {
            // A short line is appended on the main thread; rotate before a file becomes large.
            if (Files.exists(evidencePath) && Files.size(evidencePath) >= 4_000_000L) {
                Path rotated = evidencePath.resolveSibling("evidence-" + LocalDate.now() + "-" + System.currentTimeMillis() + ".jsonl");
                Files.move(evidencePath, rotated);
            }
            Files.writeString(evidencePath, payload, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ex) {
            getLogger().warning("Nie udało się zapisać zdarzenia: " + ex.getMessage());
        }
        if (getConfig().getBoolean("alerts.console", true)) {
            getLogger().warning("[" + check + "] " + player.getName() + " | " + evidence + " | id=" + reportId);
        }
        if (getConfig().getBoolean("alerts.staff-chat", true)) {
            for (Player mod : Bukkit.getOnlinePlayers()) {
                if (mod.hasPermission("minevora.guard.alerts") && !mutedAlerts.contains(mod.getUniqueId())) {
                    mod.sendMessage(ChatColor.DARK_PURPLE + "[MINEVORA Guard] " + ChatColor.YELLOW + player.getName()
                            + ChatColor.GRAY + " • " + check + " • sprawdź /mg inspect " + player.getName());
                }
            }
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("minevora.guard.admin")) {
            sender.sendMessage(ChatColor.RED + "Brak uprawnień minevora.guard.admin"); return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(ChatColor.LIGHT_PURPLE + "MINEVORA Guard: /mg status | inspect <nick> | alerts | reload | evidence");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "status" -> sender.sendMessage(ChatColor.GREEN + "MINEVORA Guard aktywny • online=" + Bukkit.getOnlinePlayers().size()
                    + " • dowody: plugins/MINEVORAGuard/evidence.jsonl • tryb alert-only");
            case "inspect" -> {
                if (args.length < 2) { sender.sendMessage("Użycie: /mg inspect <nick>"); return true; }
                Player p = Bukkit.getPlayerExact(args[1]);
                if (p == null) { sender.sendMessage("Gracz jest offline. Dane szczegółowe są w evidence.jsonl."); return true; }
                State state = state(p);
                sender.sendMessage(ChatColor.AQUA + p.getName() + " • sygnały od restartu: " + state.totalAlerts);
                if (state.categories.isEmpty()) sender.sendMessage("Nie zapisano sygnałów. To nie potwierdza uczciwości gracza.");
                for (Map.Entry<String, Integer> entry : state.categories.entrySet()) {
                    sender.sendMessage(ChatColor.GRAY + entry.getKey() + ": " + entry.getValue());
                }
            }
            case "alerts" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("Ta opcja jest dostępna w grze."); return true; }
                if (!mutedAlerts.add(p.getUniqueId())) { mutedAlerts.remove(p.getUniqueId()); sender.sendMessage("Alerty włączone."); }
                else sender.sendMessage("Alerty wyciszone dla Ciebie.");
            }
            case "reload" -> { reloadConfig(); sender.sendMessage(ChatColor.GREEN + "Konfiguracja MINEVORA Guard odświeżona."); }
            case "evidence" -> sender.sendMessage("Log: plugins/MINEVORAGuard/evidence.jsonl (import w launcherze Fair Play)");
            default -> sender.sendMessage("Nieznana komenda. /mg help");
        }
        return true;
    }
}
