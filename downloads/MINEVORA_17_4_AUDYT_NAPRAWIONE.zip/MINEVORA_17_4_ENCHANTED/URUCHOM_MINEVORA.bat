@echo off
setlocal
cd /d "%~dp0"
title MINEVORA 17.4 - THE ENCHANTED LAUNCHER
if exist "%LOCALAPPDATA%\Programs\Python\Python315\python.exe" (
  "%LOCALAPPDATA%\Programs\Python\Python315\python.exe" minevora_start.py
  goto check
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3.15 -c "import PySide6, minecraft_launcher_lib" >nul 2>nul
  if not errorlevel 1 (
    py -3.15 minevora_start.py
    goto check
  )
)
python minevora_start.py
:check
if errorlevel 1 (
  echo.
  echo MINEVORA napotkala blad. Sprawdz folder %%USERPROFILE%%\.minevora
  pause
)
endlocal
