"""Interactive, screenshot-faithful MINEVORA home skin.

Reference image provided by the project owner. Real, keyboard-focusable Qt
buttons sit above the artwork and call existing launcher actions. Non-live
placeholder data from the mock-up is covered with the real local launcher state.
"""
from pathlib import Path
from PySide6.QtCore import Qt, QRect, QEvent
from PySide6.QtGui import QPainter, QColor, QFont, QLinearGradient, QPixmap
from PySide6.QtWidgets import QWidget, QPushButton, QMenu

ROOT = Path(__file__).resolve().parent
W, H = 1536, 864
# Input zones match the supplied reference, which is exactly 1536 x 864.
# name: (x, y, width, height, tooltip)
ZONES = {
 'home': (15, 200, 218, 47, 'Strona główna'),
 'versions': (15, 247, 218, 43, 'Wersje i profile Minecraft'),
 'mods': (15, 290, 218, 42, 'Mody i dodatki'),
 'market': (15, 333, 218, 44, 'Marketplace'),
 'minigames_nav': (15, 376, 218, 41, 'Wybierz jedną z siedmiu minigier'),
 'pvp_nav': (15, 418, 218, 41, 'PvP Center'),
 'ranking_nav': (15, 460, 218, 43, 'Ranking'),
 'discord_nav': (15, 532, 218, 43, 'Discord'),
 'settings_nav': (15, 574, 218, 43, 'Ustawienia'),
 'together_nav': (15, 616, 218, 45, 'Together'),
 'discord_join': (16, 677, 214, 49, 'Dołącz do Discord MINEVORA'),
 'account': (16, 756, 216, 53, 'Konto Microsoft'),
 'refresh': (814, 18, 58, 55, 'Odśwież'),
 'search': (880, 17, 213, 57, 'Wyszukiwarka funkcji'),
 'profile': (1098, 17, 166, 57, 'Profil gracza'),
 'chat': (1268, 17, 124, 58, 'Czat'),
 'hero_play': (302, 296, 273, 59, 'Uruchom Minecraft'),
 'hero_install': (581, 296, 210, 59, 'Zainstaluj wybraną wersję'),
 'card_minigames': (267, 390, 406, 176, 'Minigry: BedWars, SkyWars i inne'),
 'card_pvp': (685, 390, 416, 176, 'PvP Center'),
 'card_ranking': (1111, 390, 407, 176, 'Ranking graczy'),
 'step_login': (284, 620, 390, 63, 'Zaloguj Microsoft'),
 'step_version': (709, 620, 398, 63, 'Wybierz wersję Minecraft'),
 'step_launch': (1110, 620, 406, 63, 'Uruchom Minecraft'),
 'fav_versions': (265, 720, 300, 69, 'Wersje Minecraft'),
 'fav_mods': (576, 720, 301, 69, 'Modrinth i CurseForge'),
 'fav_market': (885, 720, 310, 69, 'Marketplace'),
 'fav_settings': (1207, 720, 310, 69, 'Ustawienia'),
 'ram': (1166, 805, 111, 56, 'Zmień przydział RAM'),
 'bottom_play': (1292, 797, 228, 65, 'Wejdź do gry'),
 'minimize': (1410, 4, 42, 72, 'Minimalizuj'),
 'maximize': (1453, 4, 43, 72, 'Maksymalizuj lub przywróć'),
 'close': (1497, 4, 38, 72, 'Zamknij MINEVORA'),
}

class ReferenceHomeSkin(QWidget):
 def __init__(self, launcher, actions, parent=None):
  super().__init__(parent)
  self.launcher = launcher
  self.source = QPixmap(str(ROOT/'assets'/'minevora_home_reference.jpg'))
  if self.source.isNull():
   raise FileNotFoundError('Brakuje obrazu assets/minevora_home_reference.jpg')
  self.setObjectName('minevoraReferenceHome')
  self.setFocusPolicy(Qt.StrongFocus)
  self.buttons = {}
  for key, (x,y,w,h,hint) in ZONES.items():
   b = QPushButton('',self)
   b.setObjectName('skinHitArea')
   b.setAccessibleName(hint)
   b.setToolTip(hint)
   b.setCursor(Qt.PointingHandCursor)
   b.setFocusPolicy(Qt.StrongFocus)
   b.setStyleSheet("""QPushButton#skinHitArea{background:transparent;border:1px solid transparent;border-radius:9px;padding:0}
      QPushButton#skinHitArea:hover{background:rgba(169,93,255,0.11);border:1px solid rgba(205,166,255,0.65)}
      QPushButton#skinHitArea:focus{border:2px solid #d9b5ff;background:rgba(151,71,255,0.17)}""")
   handler=actions.get(key)
   if handler is not None:
    b.clicked.connect(lambda checked=False, f=handler:f())
   self.buttons[key]=b
  self.buttons['ram'].clicked.connect(self.choose_ram)
  self._position_buttons()

 def _sx(self, value): return int(round(value*self.width()/W))
 def _sy(self, value): return int(round(value*self.height()/H))
 def _scaled(self,x,y,w,h): return QRect(self._sx(x),self._sy(y),max(1,self._sx(w)),max(1,self._sy(h)))

 def _position_buttons(self):
  for key,(x,y,w,h,_) in ZONES.items():
   self.buttons[key].setGeometry(self._scaled(x,y,w,h))

 def resizeEvent(self,event):
  super().resizeEvent(event)
  self._position_buttons()

 def draw_text(self, painter, x,y,content,size=13,color='#f8f7ff',weight=600):
  font=QFont('Segoe UI',max(9,self._sy(size)))
  font.setBold(weight >= 600)
  painter.setFont(font);painter.setPen(QColor(color))
  painter.drawText(self._sx(x),self._sy(y),str(content))

 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.SmoothPixmapTransform,True)
  p.drawPixmap(self.rect(),self.source)
  # The supplied visual contains SAMPLE player name and SAMPLE server status.
  # We deliberately never pass them off as actual online/session information.
  p.fillRect(self._scaled(17,754,214,54), QColor('#101d35'))
  p.setPen(QColor('#3b5c91'))
  p.drawRoundedRect(self._scaled(20,760,208,46),9,9)
  session=getattr(self.launcher,'session',None)
  logged=isinstance(session,dict) and bool(session.get('access_token'))
  name=str(session.get('name','')) if logged else 'Zaloguj Microsoft'
  if len(name)>19:name=name[:18]+'…'
  self.draw_text(p,37,785,name,13,'#f6f5ff',700)
  self.draw_text(p,37,801,'Konto połączone' if logged else 'Brak połączenia',10,'#62e2af' if logged else '#a8b6d4',400)
  # Replace all fake game-status data in the mock-up with actual installed version.
  p.fillRect(self._scaled(265,795,836,69),QColor('#0f1b32'))
  self.draw_text(p,285,817,'✦  AKTYWNA INSTANCJA',11,'#c6a7fb',700)
  chosen=getattr(self.launcher,'current_version',None)
  profile=getattr(self.launcher,'active_profile',None)
  title= (str(profile.get('name','Minecraft'))+'  •  '+str(chosen)) if isinstance(profile,dict) and chosen else (str(chosen) if chosen else 'Brak zainstalowanej wersji Minecraft')
  self.draw_text(p,320,841,title[:49],15,'#ffffff',700)
  ready=bool(chosen and logged)
  p.fillRect(self._scaled(675,813,210,38),QColor('#122640'))
  self.draw_text(p,683,838,'● Gotowa do gry' if ready else '● Wymaga konfiguracji',12,'#56e7a4' if ready else '#e6b85f',700)
  # RAM in the sample artwork was 4 GB; show the live selector value.
  if hasattr(self.launcher,'ram'):
   current=self.launcher.ram.currentText()
   p.fillRect(self._scaled(1185,818,64,28),QColor('#101e38'))
   self.draw_text(p,1190,838,current,13,'#faf8ff',700)
  # Version label: the picture's 1.14.1 value is only artwork.
  p.fillRect(self._scaled(17,80,199,27),QColor('#0d172c'))
  self.draw_text(p,19,99,'MINEVORA 13.0  •  ENCHANTED',10,'#b6c6e8',500)
  p.fillRect(self._scaled(16,819,210,42),QColor('#0d172c'))
  self.draw_text(p,18,836,'MINEVORA 13.0',10,'#b9c7e6',500)
  self.draw_text(p,18,855,'Java Edition',10,'#b9c7e6',500)
  p.end()

 def choose_ram(self):
  menu=QMenu(self)
  combo=self.launcher.ram
  for val in ['2 GB','4 GB','6 GB','8 GB','12 GB','16 GB']:
   a=menu.addAction(val)
   a.setCheckable(True);a.setChecked(val==combo.currentText())
   a.triggered.connect(lambda checked=False, ram=val: (combo.setCurrentText(ram), self.update()))
  menu.exec(self.buttons['ram'].mapToGlobal(self.buttons['ram'].rect().bottomLeft()))

