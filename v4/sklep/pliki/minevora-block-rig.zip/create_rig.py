import bpy
from mathutils import Vector

collection = bpy.data.collections.new("MINEVORA Block Rig")
bpy.context.scene.collection.children.link(collection)
arm = bpy.data.armatures.new("Block Skeleton")
rig = bpy.data.objects.new("MINEVORA Rig", arm)
collection.objects.link(rig)
if bpy.context.object and bpy.context.object.mode != 'OBJECT':
    bpy.ops.object.mode_set(mode='OBJECT')
bpy.ops.object.select_all(action='DESELECT')
rig.select_set(True)
bpy.context.view_layer.objects.active = rig
bpy.ops.object.mode_set(mode='EDIT')
spec = [
    ("body",(0,0,1.0),(0,0,1.7),None),
    ("head",(0,0,1.7),(0,0,2.25),"body"),
    ("arm.L",(0.45,0,1.65),(0.45,0,1.0),"body"),
    ("arm.R",(-0.45,0,1.65),(-0.45,0,1.0),"body"),
    ("leg.L",(0.18,0,1.0),(0.18,0,0.25),"body"),
    ("leg.R",(-0.18,0,1.0),(-0.18,0,0.25),"body"),
]
for name,head,tail,parent in spec:
    bone=arm.edit_bones.new(name)
    bone.head=head
    bone.tail=tail
    if parent:
        bone.parent=arm.edit_bones[parent]
bpy.ops.object.mode_set(mode='OBJECT')
rig.show_in_front=True
parts=[
    ("body",(0,0,1.35),(0.65,0.38,0.7),(0.14,0.35,0.25,1)),
    ("head",(0,0,2.0),(0.6,0.6,0.6),(0.64,0.47,0.32,1)),
    ("arm.L",(0.49,0,1.33),(0.27,0.35,0.64),(0.14,0.35,0.25,1)),
    ("arm.R",(-0.49,0,1.33),(0.27,0.35,0.64),(0.14,0.35,0.25,1)),
    ("leg.L",(0.18,0,0.62),(0.32,0.35,0.76),(0.12,0.18,0.26,1)),
    ("leg.R",(-0.18,0,0.62),(0.32,0.35,0.76),(0.12,0.18,0.26,1)),
]
for name,loc,size,color in parts:
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    obj=bpy.context.object
    obj.name="Block "+name
    obj.scale=size
    for old in list(obj.users_collection):
        old.objects.unlink(obj)
    collection.objects.link(obj)
    mat=bpy.data.materials.new("Block "+name)
    mat.diffuse_color=color
    obj.data.materials.append(mat)
    bpy.context.view_layer.update()
    world=obj.matrix_world.copy()
    obj.parent=rig
    obj.parent_type='BONE'
    obj.parent_bone=name
    bpy.context.view_layer.update()
    obj.matrix_world=world
bpy.ops.object.select_all(action='DESELECT')
rig.select_set(True)
bpy.context.view_layer.objects.active=rig
