BLOCK CHARACTER RIG / MINEVORA
PL: Blender 4.x > Scripting > Open > create_rig.py > Run Script. Skrypt tworzy nowa kolekcje w aktualnej scenie, nie usuwa obiektow. Zaznacz armature i przejdz do Pose Mode, aby animowac. Zapisz .blend samodzielnie. Skrypt nie byl uruchamiany w Blenderze w tym wydaniu.
EN: Open create_rig.py in Blender Scripting and run it. A new collection is added; select the armature and enter Pose Mode. Save your .blend manually. Blender runtime not tested.
