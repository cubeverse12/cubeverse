MINEVORA WELCOME
PL: Zainstaluj JDK 21 i Maven, w katalogu pom.xml uruchom mvn package. Po pomyslnej kompilacji skopiuj target/minevora-welcome-1.0.0.jar do plugins na testowym serwerze Paper 1.21.4 i zrestartuj serwer. Nie dolaczono JAR. Kompilacja i dzialanie na serwerze nie zostaly sprawdzone.
EN: Run mvn package with JDK 21 and Maven. After a successful build copy the JAR to plugins on a test Paper server. No prebuilt JAR is included; build and server execution are untested.
